name = "local/independent_public021"
version = "0.0.0"
license = "Apache-2.0"

import {
  "HhWw96/moontxnwitness@0.2.1",
}
