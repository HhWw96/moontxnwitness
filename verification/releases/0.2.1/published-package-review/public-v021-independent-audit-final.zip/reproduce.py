from pathlib import Path
import sys,json,hashlib,subprocess
root=Path(__file__).resolve().parent
m=json.loads((root/'manifest.json').read_text(encoding='utf8'))
for item in m['files']:
 p=root/item['file'];raw=p.read_bytes();assert len(raw)==item['bytes'] and hashlib.sha256(raw).hexdigest()==item['sha256'],item['file']
node=sys.argv[1] if len(sys.argv)>1 else 'node'
out=root/'reproduction-new';out.mkdir()
results=[]
for folder in ['portable/MoonTxnWitness-v0.2.1','source/MoonTxnWitness-v0.2.1']:
 consumer=root/folder
 for script,expected,receipt,failures in [('independent-public-review.mjs',1,'independent-first-receipt.json',2),('independent-contract-supplement.mjs',1,'supplement-first-receipt.json',2),('independent-contract-boundaries.mjs',0,'contract-boundaries-first-receipt.json',0)]:
  dest=out/(folder.split('/')[0]+'-'+script.removesuffix('.mjs'))
  prior=[] if script=='independent-public-review.mjs' else [str(out/(folder.split('/')[0]+('-independent-public-review' if script=='independent-contract-supplement.mjs' else '-independent-contract-supplement')))]; p=subprocess.run([node,str(root/script),str(consumer),*prior,str(dest)],capture_output=True,timeout=180)
  (out/(dest.name+'.stdout')).write_bytes(p.stdout);(out/(dest.name+'.stderr')).write_bytes(p.stderr)
  assert p.returncode==expected,(script,p.returncode,p.stderr.decode(errors='replace'))
  r=json.loads((dest/receipt).read_text(encoding='utf8'));assert sum(not x['passed'] for x in r['cases'])==failures
  results.append({'consumer':folder,'runner':script,'expectedExit':expected,'actualExit':p.returncode,'expectedFailedGroups':failures})
 for script in ['v020-compatibility-test.mjs','v020-invalid-compatibility-test.mjs']:
  p=subprocess.run([node,str(consumer/'scripts'/script)],capture_output=True,timeout=180)
  (out/(folder.split('/')[0]+'-'+script+'.stdout')).write_bytes(p.stdout)
  (out/(folder.split('/')[0]+'-'+script+'.stderr')).write_bytes(p.stderr)
  assert p.returncode==0,(script,p.returncode,p.stderr.decode(errors='replace'))
  results.append({'consumer':folder,'runner':script,'passed':True})
(out/'receipt.json').write_text(json.dumps({'passed':True,'allFileHashesVerified':True,'originalFailedHarnessExpectationsRetained':True,'executions':results},indent=2),encoding='utf8')
print('Recorded contract outcomes reproduced; original failed harness expectations remain failed.')
