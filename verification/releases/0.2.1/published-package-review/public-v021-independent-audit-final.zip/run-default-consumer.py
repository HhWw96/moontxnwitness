import pathlib,os,subprocess,json,hashlib,time,shutil
b=pathlib.Path(r'D:\CodexScratch\MoonTxnWitness-public021-independent-20261023-8da7e3f5')
c=b/'registry-consumer-default'; h=b/'moon-home-default'
assert not c.exists() and not h.exists()
c.mkdir(); h.mkdir()
for name in ['moon.mod','moon.pkg','consumer.mbt','consumer_wbtest.mbt']: shutil.copyfile(b/'registry-consumer'/name,c/name)
for name,dest in [('bin','moon-bin'),('lib','moon-lib')]:
 subprocess.run(['cmd','/c','mklink','/J',str(h/name),str(pathlib.Path(r'D:\CodexScratch\MoonTxnWitness-v011-20261020')/dest)],check=True,capture_output=True)
e=os.environ.copy(); e.pop('MOONCAKES_REGISTRY',None); e.update(MOON_HOME=str(h),TEMP=str(b/'scratch'),TMP=str(b/'scratch'),PYTHONDONTWRITEBYTECODE='1');e['PATH']=r'D:\nodejs;'+e['PATH']
moon=h/'bin'/'moon.exe'; out={'schema':1,'passed':False,'configuration':'fresh default registry; MOONCAKES_REGISTRY removed','consumer':c.name,'moonHome':h.name,'testsExecuted':[],'steps':[]}
assert not (h/'credentials.json').exists()
def run(label,args,limit):
 t=time.time()
 try:
  p=subprocess.run([str(moon),*args],cwd=c,env=e,capture_output=True,timeout=limit)
  code=p.returncode; so=p.stdout; se=p.stderr
 except subprocess.TimeoutExpired as ex: code='timeout'; so=ex.stdout or b'';se=ex.stderr or b''
 for suffix,data in [('stdout',so),('stderr',se)]: (b/'evidence'/('registry-default-'+label+'.'+suffix)).write_bytes(data)
 r={'step':label,'args':args,'exitCode':code,'seconds':round(time.time()-t,3),'stdoutSha256':hashlib.sha256(so).hexdigest(),'stderrSha256':hashlib.sha256(se).hexdigest()};out['steps'].append(r); print(json.dumps(r),flush=True); (b/'evidence'/'registry-consumer-default-first.json').write_text(json.dumps(out,indent=2),encoding='utf-8');return code==0
if run('add-first',['add','HhWw96/moontxnwitness@0.2.1'],180):
 caches=list((h/'registry'/'cache').rglob('0.2.1.zip'))
 out['cacheArchiveChecks']=[{'path':str(x.relative_to(h)),'bytes':x.stat().st_size,'sha256':hashlib.sha256(x.read_bytes()).hexdigest()} for x in caches]
 out['addManifest']=(c/'moon.mod').read_text(encoding='utf-8')
 ok=True
 for target in ['js','wasm-gc']:
  r=run('test-'+target+'-first',['test','--target',target],180);out['testsExecuted'].append({'target':target,'passed':r});ok=ok and r
 out['passed']=ok
out['credentialsPresent']=(h/'credentials.json').exists()
(b/'evidence'/'registry-consumer-default-first.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
print(json.dumps(out),flush=True)
