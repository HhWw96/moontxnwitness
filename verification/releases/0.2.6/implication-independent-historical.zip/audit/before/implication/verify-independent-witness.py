from pathlib import Path
import json,itertools,hashlib
B=Path(__file__).resolve().parent;source=json.loads((B/'input.json').read_bytes());events=source['events'];assert [e['seq']for e in events]==list(range(1,len(events)+1));initial=events[0]['initial'];versions={v:None for v in initial.values()};writes={};committed=set()
for e in events:
 if e['kind']=='write':assert e['version']not in versions;versions[e['version']]=e;writes[e['version']]=e
 if e['kind']=='commit_ok':committed.add(e['tx'])
assert committed==set('ABCDEF')
edges=[];successor={}
for e in writes.values():
 pred=e['predecessor'];assert pred in versions and pred not in successor;successor[pred]=e
 prior=versions[pred]
 if prior is not None:
  assert prior['key']==e['key']and prior['seq']<e['seq'];edges.append((prior['tx'],e['tx'],'ww',e['key'],prior['seq'],e['seq']))
for read in events:
 if read['kind']!='read':continue
 assert read['version']==initial[read['key']]
 cursor=read['version']
 while cursor in successor:
  item=successor[cursor];assert item['key']==read['key'];edges.append((read['tx'],item['tx'],'rw',read['key'],read['seq'],item['seq']));cursor=item['version']
expected={('B','C','ww'),('B','D','ww'),('B','E','ww'),('C','F','ww'),('F','A','ww'),('A','B','rw')};assert {(a,b,k)for a,b,k,*_ in edges}==expected
by_pair={}
for e in edges:by_pair.setdefault(e[:2],[]).append(e)
cycles=[]
for length in range(2,len(committed)+1):
 for vertices in itertools.permutations(sorted(committed),length):
  if vertices[0]!=min(vertices):continue
  options=[by_pair.get((vertices[i],vertices[(i+1)%length]),[])for i in range(length)]
  if not all(options):continue
  for cycle in itertools.product(*options):
   kinds=[e[2]for e in cycle];rw=[k=='rw'for k in kinds];cycles.append({'vertices':list(vertices),'edges':[list(e)for e in cycle],'G2':any(rw),'Gnonadjacent':any(rw)and not any(rw[i]and rw[(i+1)%length]for i in range(length))})
assert len(cycles)==1 and cycles[0]['vertices']==['A','B','C','F']and cycles[0]['Gnonadjacent']and cycles[0]['G2']
proof_rows=[]
for p in sorted((B/'outputs').glob('*.report.json')):
 report=json.loads(p.read_bytes());r=report['result'];assert r['normalized']['status']=='ready'and r['dependencyGraphComplete'];actual={(e['from'],e['to'],e['kind'])for e in r['dependencies']};assert actual==expected
 witness=r['rules']['G-nonadjacent']['evidence'];raws=witness['edges'];path=[x['edge']for x in raws];assert len(path)==4
 for i,proof in enumerate(raws):
  edge=proof['edge'];assert edge['to']==path[(i+1)%len(path)]['from'];match=next(e for e in edges if e[:4]==(edge['from'],edge['to'],edge['kind'],edge['key']));assert proof['fromObservationSeq']==[match[4]]and proof['toObservationSeq']==[match[5]]
  chain=[initial[edge['key']]];cursor=chain[0]
  while cursor in successor:cursor=successor[cursor]['version'];chain.append(cursor)
  assert proof['capturedVersionOrder']==chain
  assert (edge['fromVersion'],edge['toVersion'])==((events[match[4]-1]['version']),(events[match[5]-1]['version']))
 rw=[e['kind']=='rw'for e in path];assert any(rw)and not any(rw[i]and rw[(i+1)%len(rw)]for i in range(len(rw)))
 proof_rows.append({'report':p.relative_to(B).as_posix(),'exactFactEdges':True,'closedSimpleCycle':True,'hasRW':True,'ringAdjacentRWAbsent':True,'allObservationSeqAndCapturedVersionChainsVerified':True})
result={'format':'independent-v026-source-fact-cycle-oracle/v1','oraclePassed':True,'productionSemanticFailureNotHidden':True,'candidateExecutedByThisOracle':False,'independentMethod':'Derive the six WW/RW relations from frozen predecessor/write/read facts, then exhaustively enumerate all simple vertex permutations and edge alternatives. Validate supplied witness edges, sources, exact observation sequences and original same-key predecessor chains. No production search code copied.','inputSha256':hashlib.sha256((B/'input.json').read_bytes()).hexdigest(),'factEdges':[list(e)for e in edges],'allSimpleCycles':cycles,'witnessReports':proof_rows,'formalConclusion':'This source-checked nonadjacent cycle has an item RW, hence is a G2-item counterexample and refutes PL2.99, PL3 and strict PL-SS regardless of the separate direct G2 search budget.','source':'https://jepsen.io/consistency/phenomena/g-nonadjacent','actualStable26Runtime':False};(B/'independent-witness-oracle.json').write_bytes((json.dumps(result,indent=2)+'\n').encode());print(json.dumps({'oraclePassed':True,'factEdges':len(edges),'simpleCycles':len(cycles),'witnessReportsVerified':len(proof_rows),'inputSha256':result['inputSha256']}))
