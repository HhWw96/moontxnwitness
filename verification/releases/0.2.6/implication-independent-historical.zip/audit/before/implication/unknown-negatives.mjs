import {readFileSync,writeFileSync,mkdirSync}from'node:fs';
import assert from'node:assert/strict';
import {classifyModelsV3}from'./runtime/classification-models.mjs';
const output=new URL('./supplement-outputs/',import.meta.url);mkdirSync(output,{recursive:false});const rows=[],plans=[
{name:'PL299-reliable-proof-state3',file:'input.json',models:['adya-pl-2.99-v1'],maxStates:3,maxEdgeChecks:100,expect:'refuted'},
{name:'strict-reliable-ordinary-proof-state3',file:'input.json',models:['strict-pl-ss-v1'],maxStates:3,maxEdgeChecks:100,expect:'refuted'},
{name:'unknown-no-state',file:'input.json',models:['adya-pl-3-v1'],maxStates:0,maxEdgeChecks:100,expect:'inconclusive'},
{name:'unknown-no-edge',file:'input.json',models:['adya-pl-3-v1'],maxStates:100,maxEdgeChecks:0,expect:'inconclusive'},
{name:'acyclic-limited',file:'negative-acyclic.json',models:['adya-pl-3-v1'],maxStates:3,maxEdgeChecks:100,expect:'inconclusive'},
{name:'acyclic-complete',file:'negative-acyclic.json',models:['adya-pl-3-v1'],maxStates:100,maxEdgeChecks:100,expect:'checked-compatible'},
{name:'acyclic-strict-no-intervals',file:'negative-acyclic.json',models:['strict-pl-ss-v1'],maxStates:100,maxEdgeChecks:100,expect:'inconclusive'}];
for(const p of plans){const source=readFileSync(new URL(p.file,import.meta.url),'utf8'),options={models:p.models,maxStates:p.maxStates,maxEdgeChecks:p.maxEdgeChecks},r=classifyModelsV3(source,options);writeFileSync(new URL(p.name+'.report.json',output),JSON.stringify(r,null,2)+'\n',{flag:'wx'});const row={name:p.name,input:p.file,options,expected:p.expect,observed:r.status,G2:r.result.rules['G2-item'].status,nonadjacent:r.result.rules['G-nonadjacent'].status};try{assert.equal(r.status,p.expect);assert.equal(r.result.normalized.status,'ready');assert.equal(r.result.dependencyGraphComplete,true);if(p.name.startsWith('unknown-')||p.name==='acyclic-limited'){assert.equal(row.G2,'unknown');assert.equal(row.nonadjacent,'unknown');}row.passed=true;}catch(e){row.passed=false;row.error=e.message;}rows.push(row);}
const receipt={format:'independent-historical-v026-implication-negatives/v1',checks:rows.length,passed:rows.every(x=>x.passed),cases:rows,actualStable26Runtime:false,productionChanged:false,databaseExecuted:false,compilerExecuted:false,formalPerformanceMeasurement:false};writeFileSync(new URL('./supplement-receipt.json',import.meta.url),JSON.stringify(receipt,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(receipt));process.exitCode=receipt.passed?0:1;
