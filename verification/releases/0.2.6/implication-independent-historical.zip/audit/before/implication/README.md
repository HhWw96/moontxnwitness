# Independent actual historical candidate failure

The actual archived historical candidate runtime (version 0.2.0, original core 89986b19...) was copied byte-for-byte into this new directory. This is not an actual v0.2.6 build or public release, and no compiler/database/performance run occurred.

`node reproduce.mjs` runs four frozen independent cases and intentionally exits 1 on the original candidate: two cases fail because the PL3 model loses an already proven nonadjacent/G2 refutation when a separate BFS uses its budget. `node unknown-negatives.mjs` adds PL2.99/strict and five unknown/acyclic controls, with two failures on that same original candidate. Both original receipts and every full report remain unchanged. Use a new exclusive directory for any repaired runtime; never replace the originals here.

`python -B verify-independent-witness.py` validates all original graph edges from predecessor/read/write facts, independently enumerates simple cycles and checks exact observation sequences and captured chains. The unique cycle A-rw-B-ww-C-ww-F-ww-A proves G2; this oracle does not copy the production search or use replay validity as its semantic answer.

All eleven original cases preserve their expected outcomes: four actual model-aggregation failures, seven passing controls. A repair must retain G2's true unknown state/counters while using the specific reliable witness in model proof implication. No unknown negative may become a completed check simply because a label appears.

The origin source references, three producer runtime files, original trace, negative trace, full reports and self-written runners are included. Reference: https://jepsen.io/consistency/phenomena/g-nonadjacent .
