import re
FORMAT_LOCATION_FILES={'changed-clock-domain.report.json','reused-call-identity.report.json','wrong-connection.report.json'}
def comparable_result(value,name):
 result={k:v for k,v in value.items()if k not in ['models','status','version']}
 if name in FORMAT_LOCATION_FILES:
  assert value['status']=='invalid'
  match=re.fullmatch(r'Failure\(src/classification_intervals_v3\.mbt:(\d+:\d+-\d+:\d+)@HhWw96/moontxnwitness FAILED: (.*)\)',result['error'])
  assert match,('Unexpected diagnostic format',name)
  result['error']={'module':'src/classification_intervals_v3.mbt','message':match.group(2)}
 return result
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1];B=ROOT/'models';old=ROOT/'history/original';oldstrict=ROOT/'history/original-strict';rows=[];proofs=0
for newdir,olddir in [(B/'semantics/outputs',old/'outputs'),(B/'semantics/supplement-outputs',old/'supplement-outputs'),(B/'strict/outputs',oldstrict/'outputs')]:
 for newfile in sorted(newdir.glob('*.report.json')):
  oldfile=olddir/newfile.name;before=json.loads(oldfile.read_bytes());after=json.loads(newfile.read_bytes());a=before['result'];b=after['result'];assert a['version']=='0.2.0' and b['version']=='0.2.6';assert comparable_result(a,newfile.name)==comparable_result(b,newfile.name),('changed direct result',newfile.name)
  for k in ['sourceBindings','requestOptionsText','coreOptionsText','originalSourceText','budgets','scope','verificationPasses']:assert before[k]==after[k],('changed host evidence',newfile.name,k)
  for model,value in b.get('models',{}).items():
   prior=a['models'][model];assert value['requiredRules']==prior['requiredRules']and value['incompleteRules']==prior['incompleteRules']and value['unsupportedRules']==prior['unsupportedRules']and value['internalValidity']==prior['internalValidity']
   witnesses=value['refutationWitnesses'];assert set(value['refutedBy'])=={w['provedBy']for w in witnesses}
   for witness in witnesses:
    source=witness['provedBy'];target=witness['requiredRule'];assert target in value['requiredRules'];assert witness['sourceEvidencePath']==['rules',source,'evidence'];rule=b['rules'][source];assert rule['status']=='refuted'and rule['evidence']is not None;assert witness['sourceRuleStatus']=='refuted'and witness['requiredRuleStatus']==b['rules'][target]['status'];assert target in witness['impliedAnomalies']
    if source=='G-nonadjacent':assert witness['specificAnomaly']=='G-nonadjacent-item'and target in ['G-nonadjacent','G2-item'];edges=[x['edge']for x in rule['evidence']['edges']];rw=[x['kind']=='rw'for x in edges];assert any(rw)and not any(rw[i]and rw[(i+1)%len(rw)]for i in range(len(rw)))and all(e['kind']!='rt'for e in edges)
    if source.startswith('SSG'):assert target==source,'RT-only proof was used for ordinary G2'
    proofs+=1
   if not witnesses:assert value['refutedBy']==[]
  rows.append({'file':newfile.relative_to(B).as_posix(),'allNonModelResultFieldsExactBeforeAfter':True,'allSourceOptionsBudgetFieldsExact':True,'unknownCountersAndEvidenceUnchanged':True,'allProofPathsAndActualSourceStatusesChecked':True})
assert len(rows)==24
for file in [B/'semantics/receipt.json',B/'semantics/supplement-receipt.json',B/'strict/receipt.json']:assert json.loads(file.read_bytes())['passed']
result={'format':'independent-v026-fix-provenance-and-nonmodel-delta/v1','passed':True,'reportsCompared':len(rows),'refutationWitnessMappingsChecked':proofs,'reports':rows,'originalFourFailuresNowPass':True,'originalExpectationsChanged':False,'actualIntegratedRuntimeVersion':'0.2.6','phase':'final integrated26 actual runtime independent technical review','coreRulesNotFalselyCompleted':True,'explicitFormattedDiagnosticLocationsOnly':sorted(FORMAT_LOCATION_FILES),'compilerExecuted':False,'databaseExecuted':False,'formalPerformanceMeasured':False};(B/'proof-delta-receipt.json').write_bytes((json.dumps(result,indent=2)+'\n').encode());print(json.dumps({'passed':True,'reportsCompared':len(rows),'proofMappings':proofs,'sourceAndDirectRulesUnchanged':True}))
