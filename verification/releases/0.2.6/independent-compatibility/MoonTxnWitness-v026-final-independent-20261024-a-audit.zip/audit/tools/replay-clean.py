"""Actual clean-archive replay. No author workspace, compiler, DB or timing run."""
from pathlib import Path
import argparse,json,hashlib,subprocess,os,shutil
p=argparse.ArgumentParser();p.add_argument('--node24',required=True);p.add_argument('--node20',required=True);p.add_argument('--output',required=True);a=p.parse_args()
B=Path(__file__).resolve().parents[1];O=Path(a.output).resolve();O.mkdir(exist_ok=False);(O/'tmp').mkdir()
sha=lambda raw:hashlib.sha256(raw).hexdigest();manifest=json.loads((B/'ARCHIVE-MANIFEST.json').read_bytes())
def verify():
 for name,b in manifest['files'].items():
  q=B/name;assert not q.is_symlink() and q.is_file(),name;raw=q.read_bytes();assert len(raw)==b['bytes'] and sha(raw)==b['sha256'],name
verify();runs=[];env=os.environ.copy();env.update(PYTHONDONTWRITEBYTECODE='1',TEMP=str(O/'tmp'),TMP=str(O/'tmp'));env.pop('MTW_PG_DSN',None);env.pop('MTW_PG_CONNECTION_FILE',None)
def run(name,args):
 r=subprocess.run([str(x) for x in args],cwd=B,env=env,capture_output=True,timeout=360);(O/(name+'.stdout.log')).write_bytes(r.stdout);(O/(name+'.stderr.log')).write_bytes(r.stderr);row={'name':name,'exitCode':r.returncode,'stdoutSha256':sha(r.stdout),'stderrSha256':sha(r.stderr)};runs.append(row);print(json.dumps(row),flush=True);assert r.returncode==0,('Actual clean replay failed',name)
def copy(p,q):q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(p.read_bytes())
M=O/'models'
for d,names in [('semantics',['reproduce.mjs','unknown-negatives.mjs','verify-independent-witness.py','input.json','negative-acyclic.json']),('strict',['probe-strict.mjs','original-strict-envelope.json'])]:
 for name in names:copy(B/'models'/d/name,M/d/name)
 for name in ['core.mjs','classification-models.mjs']:copy(B/'runtime'/name,M/d/'runtime'/name)
copy(B/'models/probe-rt-no-ordinary-inference.mjs',M/'probe-rt-no-ordinary-inference.mjs')
for tag,node in [('node24',a.node24),('node20',a.node20)]:
 run('compat-'+tag,[node,B/'tools/compat-v025-test.mjs',B/'runtime',B/'fixtures',O/('compat-'+tag)])
 run('extra-'+tag,[node,B/'extra-security-output-option.mjs',O/('extra-'+tag+'.receipt.json')])
run('model-original4',[a.node24,M/'semantics/reproduce.mjs']);run('model-original7',[a.node24,M/'semantics/unknown-negatives.mjs']);run('strict-original13',[a.node24,M/'strict/probe-strict.mjs']);run('RT-no-inference-original3',[a.node24,M/'probe-rt-no-ordinary-inference.mjs']);run('independent-fact-cycle-oracle',[os.sys.executable,'-B',M/'semantics/verify-independent-witness.py'])
run('proof-provenance',[os.sys.executable,'-B',B/'tools/verify-proof-provenance-workspace.py',M]);run('direct-core-original108',[a.node24,B/'direct-core/test-public25-compat.mjs',B/'direct-core',B/'runtime/core.mjs',O/'direct-core-original108'])
G=O/'package-gate/scripts'
for name in ['test_public025_package_gate.py','package_release.py']:copy(B/'tools'/name,G/name)
run('package-gate-original4',[os.sys.executable,'-B',G/'test_public025_package_gate.py'])
verify()
receipts={}
for tag in ['node24','node20']:
 c=json.loads((O/('compat-'+tag)/'receipt.json').read_bytes());e=json.loads((O/('extra-'+tag+'.receipt.json')).read_bytes());assert c['passed'] and c['checkCount']==173 and c['normalAnalysisHistoricalWorkersStarted']==0 and c['inProcessObservedHistoricalWorkerLaunches']==143;assert e['passed'] and e['checks']==14;receipts[tag]={'compatChecks':173,'extraSecurityChecks':14,'node':c['node'],'normalHistoricalWorkerLaunches':0,'genuineProducerFamilies':21}
for q,count in [(M/'semantics/receipt.json',4),(M/'semantics/supplement-receipt.json',7),(M/'strict/receipt.json',13),(M/'rt-no-ordinary-inference-receipt.json',3),(O/'direct-core-original108/receipt.json',108)]:
 c=json.loads(q.read_bytes());assert c['passed'] and c['checks']==count
proof=json.loads((M/'proof-delta-receipt.json').read_bytes());assert proof['passed'] and proof['reportsCompared']==24 and proof['refutationWitnessMappingsChecked']==8
result={'format':'independent-final-v026-clean-archive-replay/v1','passed':True,'archiveManifestSha256':sha((B/'ARCHIVE-MANIFEST.json').read_bytes()),'scope':'Independent AI technical execution from a newly extracted exact audit ZIP only. No author workspace or unpublished external runtime borrowed; no compiler/DB/formal performance/public26 download. Historic0.2.0 helper labels preserved unchanged; actual engine is current0.2.6.','buildManifest':manifest['buildManifest'],'namedChecks':513,'checksByNode':receipts,'modelOriginalChecks':27,'directCoreOriginalChecks':108,'purePackageGateChecks':4,'additionalEvidenceValidation':{'historicalReportsCompared':24,'proofMappings':8,'factDerivedCycleReports':4},'executedCommands':runs,'archiveBytesAfterReplayUnchanged':True,'rootModified':False,'compilerExecuted':False,'databaseExecuted':False,'formalPerformanceMeasured':False,'actualPublic26DownloadsVerified':False,'independentAIReview':True,'humanAcceptance':False,'productionAdoption':False,'competitionApproval':False};(O/'receipt.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'passed':True,'namedChecks':513,'commands':len(runs),'scope':'actual clean archive replay'}))
