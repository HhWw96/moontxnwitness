# v0.2.6 直接验证旧 v0.2.5 类别报告：独立目录候选

产品补丁仅修改 `src/classification_v3.mbt`。旧版本边界严格为 version=0.2.5 且 algorithm=v3-register-category-1；其余引擎/未知算法不增加支持。公共classify仍按现有v26默认行为分派，新模型报告只接受当前引擎。旧25重放通过allow_models=false保留原类别选项语义，包含models/未知选项的旧错误诊断也必须逐字段相同。

验证只把重算结果最外层version替换为明确旧25，随后比较完整JSON，包括原sourceTraceText、normalized、依赖、规则、证据、预算、计数和error全文。没有去掉/弱化SourceLoc坐标比较，也没有删除模型/来源缺口。normalized本身没有engine版本字段。主线原732项测试声明与其余原源码字节保留。

`fixtures/manifest.json`为实际匿名公开25 producer manifest，SHA ad6b09408dd4bec42c5bad3777d90ff20e454906f531072beb65dac74cdabbf9，public25 core SHA bc61fd865a732137d7b85cc9916bbe64652684fc73a99766689536fdd77b0c81。6份原类别report（包含reduction内嵌report、0budget、missing source）先在公开25 core全部selfverify=true，在修复前26 core全部false，原首收据在 `verification/first-rejection/`。额外8份诊断由同一公开25 core新生成，单独标记，不冒充原producer新输出。

新Moon定向16项通过；Node冻结输入/期待108检查全部通过，覆盖所有原报告、完整字段篡改、错误全文篡改、未知engine/algorithm、旧25不能重标新models、当前类别/模型输出与修前26保持、原完整reduction对象继续unsupported。精确原SourceLoc错误可以重演的范围受源位置/规则保持约束；不能泛称未来所有invalid报告都兼容。已有完整reduction对象旧API本来不支持，本补丁也不增加，内嵌report可以单独重放。

`verification/launcher-first/`保留配置JSON默认GBK读取造成的启动器首败（未启动Moon）；`verification/moon-first/`保留新增测试误用@test命名空间的首编译诊断和首测试源码；修正仅使用项目已有assert_true/assert_eq表达原相同期待。原first收据和原冻结期待没有回写。

本包包含精确源码快照、3个完整核心、全部所需输入/报告、固定runner、patch、原首失败与后续结果。没有.git祖先、工具链二进制、数据库数据或认证信息。源码构建需要相同MoonBit v0.10.14+7d59c7ec9 / moon0.1.20260920，设置自己的MOON_HOME，在repo中执行 `moon test --target js --deny-warn --jobs 1 --filter 'released25*'` 和 `moon build --target js --release --deny-warn --jobs 1`。源码快照来自未发布26候选，不称公开26成绩。

复核编译后的固定108检查：`node test-public25-compat.mjs <本包根目录> <本包根目录>/runtimes/candidate-after/core.mjs <新建输出目录>`。runner不修改固定输入/期待；重跑使用新目录保留首结果。

这是作者在独立目录开发的兼容补丁与作者验证，不是独立验收签署。仅证明给定声明事实下的计算重放，不认证数据库或采集真实性，没有运行数据库/正式性能/全目标回归，等待另一验证线独立审核。
