"""Independent pre-construction parameter guard cases; no database or optional deps."""
from pathlib import Path
import sys,json,inspect,traceback,hashlib
ROOT=Path(__file__).resolve().parent
subject=Path(sys.argv[1]).resolve();out=Path(sys.argv[2]).resolve();out.mkdir(parents=True,exist_ok=False)
sys.path.insert(0,str(subject))
from moontxnwitness_capture.instrumentation import instrument_psycopg
checks=0;cases=[]
def ck(x,msg):
 global checks
 assert x,msg;checks+=1

def run(name,fn):
 try:fn();cases.append({'name':name,'passed':True})
 except BaseException as e:cases.append({'name':name,'passed':False,'message':str(e),'stack':traceback.format_exc()})

bad_factories=[None,0,False,'driver.connect',object(),[],{}]
for index,factory in enumerate(bad_factories):
 for flag in [False,True]:
  def check_invalid_factory(factory=factory,flag=flag,index=index):
   dest=out/f'bad-factory-{index}-{flag}'
   try:instrument_psycopg(factory,dest,asynchronous=flag)
   except ValueError:ck(True,'invalid factory rejected')
   else:raise AssertionError('invalid factory accepted')
   ck(not dest.exists(),'observer created output for invalid factory')
  run(f'noncallable factory #{index} / async={flag} rejected before directory construction',check_invalid_factory)
for index,flag in enumerate([None,0,1,'false',object(),[],{}]):
 def check_invalid_flag(flag=flag,index=index):
  dest=out/f'bad-flag-{index}'
  try:instrument_psycopg(lambda:None,dest,asynchronous=flag)
  except ValueError:ck(True,'invalid async flag rejected')
  else:raise AssertionError('non-bool async flag accepted')
  ck(not dest.exists(),'observer created output for invalid async flag')
 run(f'non-bool asynchronous #{index} rejected before directory construction',check_invalid_flag)
class ExplodingPath:
 def __fspath__(self):raise RuntimeError('Path must not be evaluated on invalid parameters')
def path_order():
 try:instrument_psycopg(None,ExplodingPath())
 except ValueError:ck(True,'guard precedes path evaluation')
 else:raise AssertionError('invalid factory accepted')
run('invalid factory checked before evaluating user path',path_order)
for flag in [False,True]:
 def valid(flag=flag):
  dest=out/f'valid-{flag}';calls=[]
  def f():calls.append('unexpected');return None
  observer,wrapped=instrument_psycopg(f,dest,asynchronous=flag)
  ck(inspect.iscoroutinefunction(wrapped)==flag,'wrong wrapper kind');ck(not calls,'factory invoked while installing');observer.close();r=json.loads((dest/'instrumentation.json').read_text(encoding='utf8'));ck(r['diagnosticOnly'] and not r['completeAnalysisCoverage'],'installation granted full analysis coverage')
 run(f'valid callable / async={flag} keeps lazy local diagnostic wrapper',valid)
r={'schema':1,'passed':all(c['passed'] for c in cases),'checks':checks,'groups':len(cases),'cases':cases,'sourceSha256':hashlib.sha256((subject/'moontxnwitness_capture/instrumentation.py').read_bytes()).hexdigest(),'scope':'Independent constructor validation only; no optional packages or DB executed'}
(out/'receipt.json').write_text(json.dumps(r,indent=2)+'\n',encoding='utf8');print(json.dumps(r));sys.exit(0 if r['passed'] else 1)
