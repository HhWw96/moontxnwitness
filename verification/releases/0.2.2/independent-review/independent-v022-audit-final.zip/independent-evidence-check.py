from pathlib import Path
import sys,json,hashlib,traceback,shutil
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT/'subject'))
from moontxnwitness_capture import instrumentation as m
from moontxnwitness_capture.journal_v3 import JournalReader
OUT=ROOT/'evidence-check-first';OUT.mkdir();cases=[];assertions=0

def check(x,msg):
 global assertions
 assert x,msg;assertions+=1

def case(name,f):
 try:f();cases.append({'name':name,'passed':True})
 except BaseException as e:cases.append({'name':name,'passed':False,'exception':type(e).__name__,'message':str(e),'stack':traceback.format_exc()})

def metadata():
 o=m.Instrumentation(OUT/'explicit-sidecar-failure');o.lifecycle.file.close();o.note('explicit-diagnostic-write');check('instrumentation_metadata_missing' in {g['code'] for g in o.gaps},'attempted lifecycle write lacks gap');o.close();r=json.loads((o.output/'instrumentation.json').read_text());check(r['lifecycle']['sealed'] is False,'failed lifecycle falsely sealed');check(r['completeAnalysisCoverage'] is False,'failure promoted coverage')
case('explicit lifecycle IO attempt produces a gap and close marks unsealed',metadata)

e=ROOT/'original-integrated-evidence';adoption=json.loads((e/'adoption.json').read_text(encoding='utf8'));receipt=json.loads((e/'receipt.json').read_text(encoding='utf8'))

def provenance():
 check(adoption['cases']==6 and receipt['passed'] and receipt['actualDatabaseExecution'],'outer integration metadata differs')
 for i in adoption['files']:
  raw=(e/i['file']).read_bytes();check(len(raw)==i['bytes'] and hashlib.sha256(raw).hexdigest()==i['sha256'],i['file'])
 for name,sha in adoption['sourceBindings'].items():check(hashlib.sha256((ROOT/'bound-source'/name).read_bytes()).hexdigest()==sha,name)
 check(len(receipt['cases'])==6 and all(c['passed'] for c in receipt['cases']),'actual six cases missing')
case('all 37 adopted evidence files and six implementation bindings are exact',provenance)

for name in ['native-sync','native-async','engine-sync','engine-async','lost-commit-sync','lost-commit-async']:
 def verify(name=name):
  p=e/name;r=json.loads((p/'instrumentation.json').read_text(encoding='utf8'));raw=(p/'lifecycle.jsonl').read_bytes();lines=raw.splitlines(keepends=True);notes=[json.loads(l) for l in lines];seal=notes[-1]
  check(r['diagnosticOnly'] and r['completeAnalysisCoverage'] is False,'coverage claim');check(r['lifecycle']['sealed'] and r['lifecycle']['sha256']==hashlib.sha256(raw).hexdigest(),'lifecycle bytes not bound');check(seal['kind']=='seal' and seal['prefixSha256']==hashlib.sha256(b''.join(lines[:-1])).hexdigest(),'seal prefix mismatch');check(seal['records']==len(lines)-1 and r['lifecycle']['records']==len(lines),'record count');check([n['seq'] for n in notes]==list(range(1,len(notes)+1)),'lifecycle sequence')
  status=JournalReader(p/'journal').verify();check(status.valid and not status.complete,'journal valid/partial');trace=json.loads((p/'trace.json').read_text(encoding='utf8'));check(trace['scope']['exclusiveWriters'] is False and len(trace['gaps'])>0,'missing diagnostic coverage gaps');check(not any(x['kind'] in ('read','write','condition') for x in trace['events']),'unproved modeled fact');check(trace['events'][0]['consistent'] is False,'initial snapshot falsely complete')
  if name.startswith('lost-commit'):
   kinds=[x['kind'] for x in trace['events']];check(kinds.count('commit_request')==1 and kinds.count('disconnect')==1 and 'commit_ok' not in kinds and 'rollback_ok' not in kinds,'lost COMMIT status changed');check(any(g['code']=='commit_unknown' for g in trace['gaps']),'lost ack unknown gap missing');detail=next(x['detail'] for x in receipt['cases'] if x['name']==name);check(detail['collectorOutcome']=='unknown','outer stored/observed distinction')
  else:check(any(x['kind']=='commit_ok' for x in trace['events']),'normal scenario lacks native confirmed commit')
 case('retained actual PostgreSQL diagnostic '+name,verify)

def corrupt():
 src=e/'native-sync'/'journal';dst=OUT/'corrupted-journal';shutil.copytree(src,dst);seg=next(dst.glob('segment-*.jsonl'));raw=seg.read_bytes();seg.write_bytes(raw[:-1]);check(JournalReader(dst).verify().valid is False,'truncated source accepted')
case('truncated retained journal is not valid storage',corrupt)
r={'schema':1,'version':'0.2.2','passed':all(c['passed'] for c in cases),'groups':len(cases),'assertions':assertions,'cases':cases,'actualDatabaseExecutionByReviewer':False,'retainedRealDatabaseCasesIndependentlyInspected':6,'originalChallengeFailureRetained':True}
(OUT/'receipt.json').write_text(json.dumps(r,indent=2)+'\n',encoding='utf8');print(json.dumps(r));sys.exit(0 if r['passed'] else 1)
