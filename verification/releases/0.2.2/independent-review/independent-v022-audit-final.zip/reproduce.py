"""Reproduce recorded contract results using only this extracted audit directory."""
from pathlib import Path
import sys,hashlib,json,shutil,subprocess
r=Path(__file__).resolve().parent
m=json.loads((r/'manifest.json').read_text(encoding='utf8'))
for i in m['files']:
 z=(r/i['file']).read_bytes();assert len(z)==i['bytes'] and hashlib.sha256(z).hexdigest()==i['sha256'],i['file']
node=sys.argv[1] if len(sys.argv)>1 else 'node';out=r/'reproduction-new';out.mkdir();results=[]
for folder in ['subject','runtime','original-integrated-evidence','bound-source','actual-public21']:
 shutil.copytree(r/folder,out/folder)
for name in ['independent-challenge.py','independent-evidence-check.py','independent-pool-hook.py','independent-core-check.mjs','independent-public21-compat.mjs','independent-parameter-validation.py']:
 shutil.copyfile(r/name,out/name)

def run(label,args,expected,receipt,failed=0):
 p=subprocess.run(args,cwd=out,capture_output=True,timeout=120)
 (out/(label+'.stdout')).write_bytes(p.stdout);(out/(label+'.stderr')).write_bytes(p.stderr)
 assert p.returncode==expected,(label,p.returncode,p.stderr.decode(errors='replace'))
 x=json.loads((out/receipt).read_text(encoding='utf8'));cases=x['cases'];assert sum(not c['passed'] for c in cases)==failed,(label,x)
 results.append({'label':label,'actualExit':p.returncode,'expectedFailedGroups':failed,'checks':x.get('checks',x.get('assertions'))})
run('original-challenge',[sys.executable,'-B',str(out/'independent-challenge.py')],1,'challenge-first/receipt.json',1)
run('original-evidence',[sys.executable,'-B',str(out/'independent-evidence-check.py')],0,'evidence-check-first/receipt.json')
run('original-pool',[sys.executable,'-B',str(out/'independent-pool-hook.py')],0,'pool-hook-first/receipt.json')
run('original-core',[node,str(out/'independent-core-check.mjs')],0,'core-check-first/receipt.json')
run('actual21-capsules',[node,str(out/'independent-public21-compat.mjs')],0,'public21-compat-first/receipt.json')
post=out/'post-guard';post.mkdir()
for folder in ['subject','runtime','original-integrated-evidence','bound-source']:
 shutil.copytree(r/'post-guard'/folder,post/folder)
for name in ['independent-evidence-check.py','independent-core-check.mjs']:
 shutil.copyfile(r/name,post/name)
run('new-guard',[sys.executable,'-B',str(out/'independent-parameter-validation.py'),str(post/'subject'),str(post/'parameter-first')],0,'post-guard/parameter-first/receipt.json')
run('new-bound-evidence',[sys.executable,'-B',str(post/'independent-evidence-check.py')],0,'post-guard/evidence-check-first/receipt.json')
run('new-core',[node,str(post/'independent-core-check.mjs')],0,'post-guard/core-check-first/receipt.json')
result={'schema':1,'passed':True,'allHashesVerified':True,'sourceWorkspaceUsed':False,'databaseExecuted':False,'originalReviewerAssertionFailureRetained':True,'results':results}
(out/'receipt.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8');print(json.dumps(result))
