"""Independent diagnostic contracts; all drivers here are reviewer-written fakes."""
from pathlib import Path
import sys,json,types,hashlib,asyncio,traceback,importlib.abc
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'subject'))
class NoOptional(importlib.abc.MetaPathFinder):
 def find_spec(self,fullname,path,target=None):
  if fullname.split('.')[0] in ('psycopg','sqlalchemy'):raise ModuleNotFoundError('Optional packages deliberately absent: '+fullname)
sys.meta_path.insert(0,NoOptional())
from moontxnwitness_capture import instrumentation as m
from moontxnwitness_capture.journal_v3 import JournalReader
OUT=ROOT/'challenge-first';OUT.mkdir()
CASES=[];assertions=0

def check(cond,message):
 global assertions
 assert cond,message;assertions+=1

def test(name,f):
 try:f();CASES.append({'name':name,'passed':True})
 except BaseException as e:CASES.append({'name':name,'passed':False,'exception':type(e).__name__,'message':str(e),'stack':traceback.format_exc()})

class DriverError(Exception):sqlstate='XX099'
class Driver:
 def __init__(self):
  self.info=types.SimpleNamespace(transaction_status=0,encoding='utf-8');self.autocommit=False;self.closed=False;self.executions=[];self.returned=[('实际',7),('0.2.0',9)];self.fetchCalls=0;self.failure=None;self.batchConsumed=[];self.commitValue=object()
 def cursor(self,*a,**kw):return Cursor(self)
 def commit(self):self.info.transaction_status=0;return self.commitValue
 def rollback(self):self.info.transaction_status=0
 def close(self):self.closed=True
 def __enter__(self):return self
class Cursor:
 def __init__(self,conn):
  self.conn=conn;self.description=None;self.pgresult=None;self.row_factory=None;self.rowcount=-1;self.rownumber=0;self.arraysize=1;self.rows=[];self.closed=False
 def execute(self,sql,params=None,**kw):
  self.conn.executions.append((sql,params,kw));self.conn.info.transaction_status=2
  if self.conn.failure:raise self.conn.failure
  self.rows=list(self.conn.returned) if sql.startswith('SELECT') else [];self.rownumber=0;self.rowcount=len(self.rows);self.description=[types.SimpleNamespace(name='x',type_code=25)] if self.rows else None;self.pgresult=types.SimpleNamespace(status=2 if self.rows else 1);return self
 def fetchone(self):
  self.conn.fetchCalls+=1
  if self.rownumber==len(self.rows):return None
  x=self.rows[self.rownumber];self.rownumber+=1;return x
 def fetchmany(self,size=None):
  self.conn.fetchCalls+=1;n=self.arraysize if size is None else size;r=self.rows[self.rownumber:self.rownumber+n];self.rownumber+=len(r);return r
 def fetchall(self):self.conn.fetchCalls+=1;r=self.rows[self.rownumber:];self.rownumber=len(self.rows);return r
 def executemany(self,sql,values,**kw):
  self.conn.info.transaction_status=2
  for v in values:
   self.conn.batchConsumed.append(v)
   if v==('FAIL',):raise self.conn.failure
  self.description=None;self.rowcount=len(self.conn.batchConsumed);return None
 def close(self):self.closed=True
class AsyncDriver(Driver):
 def cursor(self,*a,**kw):return AsyncCursor(self)
 async def commit(self):return super().commit()
 async def rollback(self):return super().rollback()
 async def close(self):return super().close()
 async def __aenter__(self):return self
class AsyncCursor(Cursor):
 async def execute(self,*a,**kw):return super().execute(*a,**kw)
 async def fetchone(self):return super().fetchone()
 async def fetchmany(self,*a):return super().fetchmany(*a)
 async def fetchall(self):return super().fetchall()
 async def executemany(self,*a,**kw):return super().executemany(*a,**kw)
 async def close(self):return super().close()
 def _close(self):return Cursor.close(self)
 async def __aenter__(self):return self

def observer(name,**kw):return m.Instrumentation(OUT/name,**kw)
def events(o):
 o.flush();return [json.loads(line) for p in sorted((o.output/'journal').glob('segment-*.jsonl')) for line in p.read_text(encoding='utf8').splitlines()]
def codes(o):return {g['code'] for g in o.gaps}

def no_dependencies():
 o=observer('no-dependencies');check('psycopg' not in sys.modules and 'sqlalchemy' not in sys.modules,'optional modules imported');o.close();r=json.loads((o.output/'instrumentation.json').read_text());check(r['diagnosticOnly'] and not r['completeAnalysisCoverage'],'false complete claim')
test('native import and initialization require no optional driver or ORM',no_dependencies)

def factory():
 raw=Driver();calls=[]
 def creator(*a,**kw):calls.append((a,kw));return raw
 o,connect=m.instrument_psycopg(creator,OUT/'local-factory');c=connect('SECRET_DSN',password='SECRET_VALUE');check(c._raw is raw,'original raw connection changed');check(calls==[(('SECRET_DSN',),{'password':'SECRET_VALUE'})],'factory arguments changed');check(creator is not connect,'not local wrapper');o.close();text=(o.output/'lifecycle.jsonl').read_text(encoding='utf8');check('SECRET_' not in text,'connection credentials in lifecycle');check(not raw.closed,'capture closed business connection')
test('local factory forwards arguments and omits connection credentials',factory)

def delivery():
 o=observer('delivery');raw=Driver();c=o.wrap(raw);cursor=c.execute('SELECT original',('参数',));check(raw.fetchCalls==0,'prefetched rows');check(raw.executions==[('SELECT original',('参数',),{})],'SQL changed');first=cursor.fetchone();check(first is raw.returned[0],'row identity changed');rest=cursor.fetchall();check(rest==raw.returned[1:],'remaining rows changed');e=events(o);rows=[x for x in e if x['kind']=='rows'];check(len(rows)==2 and rows[0]['rows']==[['实际',7]] and rows[1]['rows']==[['0.2.0',9]],'delivered rows differ');check(not any(x['kind'] in ('read','write','condition') for x in e),'invented modeled facts');o.close()
test('actual delivery is observed without prefetch or invented model facts',delivery)

def failure():
 o=observer('execute-failure');raw=Driver();err=DriverError('exact-business-error');raw.failure=err;c=o.wrap(raw)
 try:c.execute('SELECT failure')
 except DriverError as got:check(got is err,'exception identity changed')
 else:raise AssertionError('business exception swallowed')
 check(any(x['kind']=='rows' and x.get('error',{}).get('sqlstate')=='XX099' for x in events(o)),'SQLSTATE observation missing');o.close()
test('original statement exception and SQLSTATE survive',failure)

def batch():
 o=observer('lazy-batch');raw=Driver();raw.failure=DriverError('stop-middle');c=o.wrap(raw);produced=[]
 def rows():
  for item in [('first',),('FAIL',),('tail',)]:produced.append(item);yield item
 g=rows();cur=c.cursor();check(not produced,'generator consumed early')
 try:cur.executemany('INSERT unchanged',g)
 except DriverError as got:check(got is raw.failure,'batch exception changed')
 else:raise AssertionError('batch failure swallowed')
 check(produced==[('first',),('FAIL',)],'unconsumed tail drained');check(next(g)==('tail',),'generator tail changed');o.close();notes=[json.loads(x) for x in (o.output/'lifecycle.jsonl').read_text(encoding='utf8').splitlines()];p=[x for x in notes if x['kind']=='executemany-parameters'];check([x['parameters'] for x in p]==[['first'],['FAIL']],'consumed batch parameters differ')
test('executemany lazy partial failure does not consume the business tail',batch)

def commit_unknown():
 o=observer('idle-without-tag');raw=Driver();c=o.wrap(raw);c.execute('UPDATE unchanged');check(c.commit() is raw.commitValue,'commit return changed');e=events(o);check(any(x['kind']=='commit_request' for x in e),'request missing');check(not any(x['kind']=='commit_ok' for x in e),'idle manufactured successful COMMIT');check(any(x['kind']=='disconnect' for x in e),'unknown outcome not recorded');o.close()
test('normal idle return without native tag remains unknown',commit_unknown)

def savepoint():
 o=observer('savepoint-identity');c=o.wrap(Driver());c.execute('SAVEPOINT nested');c.execute('SAVEPOINT nested');c.execute('ROLLBACK TO SAVEPOINT nested');c.execute('RELEASE SAVEPOINT nested');e=events(o);s=[x for x in e if x['kind']=='savepoint'];check(len(s)==2 and s[0]['instance']!=s[1]['instance'],'savepoint identities collapsed');check([x for x in e if x['kind']=='rollback_to'][-1]['instance']==s[1]['instance'],'wrong duplicate target');check(not any(x['kind']=='commit_ok' for x in e),'release became commit');o.close()
test('duplicate savepoint names preserve instance identity',savepoint)

def diagnostic():
 o=observer('source-close-cannot-promote');raw=Driver();c=o.wrap(raw);cur=c.execute('SELECT unread');o.close(source_closed=True);check(not raw.closed,'close killed business connection');r=json.loads((o.output/'instrumentation.json').read_text());check(r['completeAnalysisCoverage'] is False,'source close promoted coverage');o.export_diagnostic(o.output/'trace.json');t=json.loads((o.output/'trace.json').read_text(encoding='utf8'));check(len(t['gaps'])>0,'diagnostic gaps missing');check(cur.fetchone()==('实际',7),'post-close business fetch broken')
 try:o.export(o.output/'forbidden.json')
 except ValueError:check(True,'expected refusal')
 else:raise AssertionError('complete export allowed')
test('close keeps business live and explicit source flag cannot promote diagnostics',diagnostic)

def metadata_failure():
 o=observer('metadata-failure');raw=Driver();c=o.wrap(raw);o.lifecycle.file.close();cur=c.execute('SELECT still-runs');check(cur.fetchall()==raw.returned,'metadata failure changed rows');check('instrumentation_metadata_missing' in codes(o),'metadata failure lacks gap');o.close();r=json.loads((o.output/'instrumentation.json').read_text());check(r['lifecycle']['sealed'] is False,'closed-file metadata falsely sealed')
test('lifecycle storage failure preserves business execution and visible gaps',metadata_failure)

def reconnect():
 o=observer('retry-identities');a=o.wrap(Driver());a.execute('UPDATE one');a.commit();a.execute('UPDATE retry');b=o.wrap(Driver());b.execute('UPDATE reconnect');e=events(o);begins=[x for x in e if x['kind']=='begin'];check(len({x['tx'] for x in begins})==3,'transaction identities reused');check(begins[0]['connection']==begins[1]['connection']!=begins[2]['connection'],'connection identities wrong');o.close()
test('new transaction retry and reconnect create distinct identities',reconnect)

async def async_case():
 o=observer('async-delivery');raw=AsyncDriver()
 async def factory():return raw
 c=await o.psycopg_factory(factory,asynchronous=True)();cur=await c.execute('SELECT async');check(raw.fetchCalls==0,'async prefetch');r=await cur.fetchone();check(r==('实际',7),'async row changed');check(await c.commit() is raw.commitValue,'async commit return changed');e=events(o);check(not any(x['kind']=='commit_ok' for x in e),'async unsupported tag manufactured commit');o.close();check(not raw.closed,'observer closed async business connection')
test('async factory no-prefetch and unobserved COMMIT remain diagnostic',lambda:asyncio.run(async_case()))

# Non-gating API misuse probe: reports cleanup behavior, without inventing a promised contract.
probe={}
p=OUT/'invalid-factory-probe'
try:m.instrument_psycopg(None,p)
except BaseException as e:probe={'exception':type(e).__name__,'directoryCreated':p.exists(),'sealedReceiptExists':(p/'instrumentation.json').exists(),'diagnostic':'Invalid non-callable factory is rejected after constructing observer; no cleanup receipt observed. Non-gating misuse observation, not a release claim failure.'}
result={'schema':1,'version':'0.2.2','scope':'Independent reviewer fakes, optional dependencies deliberately unavailable; no real DB execution','passed':all(c['passed'] for c in CASES),'groups':len(CASES),'assertions':assertions,'cases':CASES,'apiMisuseProbe':probe,'originalExpectationsUnmodified':True}
(OUT/'receipt.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n',encoding='utf8');print(json.dumps(result,ensure_ascii=False));sys.exit(0 if result['passed'] else 1)
