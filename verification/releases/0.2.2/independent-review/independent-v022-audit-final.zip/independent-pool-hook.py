from pathlib import Path
import json,sys,types,traceback
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT/'subject'))
from moontxnwitness_capture import instrumentation as m
OUT=ROOT/'pool-hook-first';OUT.mkdir();registered=[];cases=[];checks=0
class Events:
 @staticmethod
 def listen(target,name,callback):registered.append((target,name,callback))
 @staticmethod
 def remove(target,name,callback):registered.remove((target,name,callback))
sys.modules['sqlalchemy']=types.SimpleNamespace(__version__='2.0.55',event=Events)
def ck(x,msg):
 global checks
 assert x,msg;checks+=1

def test(name,f):
 try:f();cases.append({'name':name,'passed':True})
 except BaseException as e:cases.append({'name':name,'passed':False,'message':str(e),'stack':traceback.format_exc()})

def pool():
 one=types.SimpleNamespace(dialect=types.SimpleNamespace(name='postgresql',driver='psycopg',is_async=False));two=types.SimpleNamespace(dialect=one.dialect)
 o=m.Instrumentation(OUT/'scoped-engine');o.attach_engine(one);ck(len(registered)==7,'pool hooks missing');ck(all(t is one for t,n,f in registered),'registered on another engine');hooks={name:cb for t,name,cb in registered}
 raw=types.SimpleNamespace(info=types.SimpleNamespace(transaction_status=0),autocommit=False,closed=False)
 record=types.SimpleNamespace(dbapi_connection=raw);hooks['checkout'](raw,record,object());ck(record.dbapi_connection is raw,'pre-existing connection replaced');ck('late_engine_attachment' in {g['code'] for g in o.gaps},'late borrowed connection lost gap')
 hooks['connect'](raw,record);observed=record.dbapi_connection;ck(isinstance(observed,m.DiagnosticConnection),'new connection not wrapped');hooks['checkout'](observed,record,object());ck(observed._identity in o._borrowed,'borrow not tracked');observed._tx='reviewer-unresolved-pool-tx';hooks['invalidate'](observed,record,RuntimeError('pool lost connection'));ck(observed._tx is None,'invalidated transaction retained as known');ck('pool_connection_invalidated' in {g['code'] for g in o.gaps},'invalidation lost gap');hooks['checkin'](None,record)
 state=types.SimpleNamespace(transaction_was_reset=True,terminate_only=False,asyncio_safe=True);hooks['reset'](observed,record,state);hooks['close'](observed,record);o.detach();ck(not registered,'listeners survived detach');ck(raw.closed is False,'engine detach closed business connection');o.close()
 notes=[json.loads(l) for l in (o.output/'lifecycle.jsonl').read_text(encoding='utf8').splitlines()];ck({'pool-checkout','pool-connect','pool-invalidate','pool-checkin','pool-reset','pool-close'}<={n['kind'] for n in notes},'pool lifecycle omitted')
 testevents=[json.loads(l) for p in (o.output/'journal').glob('segment-*.jsonl') for l in p.read_text(encoding='utf8').splitlines()];ck(any(x['kind']=='disconnect' and x['tx']=='reviewer-unresolved-pool-tx' for x in testevents),'invalidation did not retain unknown disconnect');ck(not any(x['kind']=='commit_ok' for x in testevents),'pool lifecycle manufactured COMMIT')
test('specified engine only, late checkout, invalidation and detach preserve scope',pool)

def rejected():
 o=m.Instrumentation(OUT/'unsupported-dialect');target=types.SimpleNamespace(dialect=types.SimpleNamespace(name='sqlite',driver='pysqlite'))
 try:o.attach_engine(target)
 except ValueError:ck(True,'expected wrong dialect rejection')
 else:raise AssertionError('unsupported dialect accepted')
 ck(not registered,'wrong dialect installed hooks');o.close()
test('unsupported dialect rejected before event attachment',rejected)
r={'schema':1,'passed':all(x['passed'] for x in cases),'checks':checks,'cases':cases,'scope':'Independent fake SQLAlchemy event dispatcher only; real engine behavior belongs to separately retained PG cases','actualDatabaseExecution':False};(OUT/'receipt.json').write_text(json.dumps(r,indent=2)+'\n',encoding='utf8');print(json.dumps(r));sys.exit(0 if r['passed'] else 1)
