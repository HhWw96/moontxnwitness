from pathlib import Path
import json,subprocess,os,hashlib,sys
base=Path(__file__).resolve().parent;repo=base/'integrated';node=sys.argv[1]if len(sys.argv)>1 else 'node';env=os.environ.copy();env['PYTHONDONTWRITEBYTECODE']='1';env['TEMP']=str(base);env['TMP']=str(base);env.pop('MTW_PG_DSN',None);env.pop('MTW_PG_CONNECTION_FILE',None)
jobs=[('public24-node24-first',['scripts/compat-v024-test.mjs','dist','fixtures/compat-v024','outputs/public24-node24-first']),('original50-first',['scripts/orm-profile-sdk-test.mjs','--repository',str(repo),'--runtime',str(repo/'dist'),'--output-root','outputs/original50-first']),('classification-demo-first',['examples/classification-roundtrip.mjs','--out-root','outputs/classification-demo-first'])]
(repo/'outputs').mkdir();rows=[]
for name,args in jobs:
 r=subprocess.run([node,*args],cwd=repo,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=180)
 (base/(name+'.stdout')).write_bytes(r.stdout);(base/(name+'.stderr')).write_bytes(r.stderr)
 rows.append({'name':name,'exitCode':r.returncode,'stdoutSha256':hashlib.sha256(r.stdout).hexdigest(),'stderrSha256':hashlib.sha256(r.stderr).hexdigest()})
 print(json.dumps({'name':name,'exitCode':r.returncode,'stdout':r.stdout.decode('utf8',errors='replace'),'stderr':r.stderr.decode('utf8',errors='replace')}),flush=True)
(base/'current-first-execution.json').write_bytes((json.dumps({'passed':all(x['exitCode']==0 for x in rows),'jobs':rows},indent=2)+'\n').encode())
raise SystemExit(0 if all(x['exitCode']==0 for x in rows)else 1)
