# Lazy replay of actual public v0.2.4 ORM evidence

The current SDK loads the original public24 ORM core only when an explicit old
ORM capsule or report requires it. New analysis and new capsule creation keep
the current engine. Generic v1/v2/v3 replay uses the current core's explicitly
reviewed recorded-version rules; observed execution diagnostics add exactly
0.2.4 to their existing supported-engine list.

`cmd/legacy/v024` retains the original public `core.mjs` and `orm-profile.mjs`
unchanged, with licenses and the original build/provenance manifest. A fixed
build helper changes only the known ESM import/export outer syntax into strict
CommonJS module wrappers, whose separate hashes are bound in manifest.json.
The body is not a generic transpilation input: the actual public24 fixture
manifest and original module hashes are pinned before conversion. Unknown
imports/exports or bindings are refused. No user capsule supplies a module,
source string or path to the loader.

The small current `legacy-v024.mjs` loader checks the hard-pinned manifest and
all eight fixed data/executable files before requiring a fixed local path.
Only the old ORM branch calls it. CommonJS lazy loading preserves the existing
synchronous API on Node20 without requiring newer require(ESM) support. Normal
SDK import and new generic/configured-profile analysis plus verification loaded
zero old CommonJS modules; old ORM replay then loaded exactly the two required
modules.

Against the immutable actual-public24 fifteen-family inputs and outputs, actual
Node24.13.0 and official SHA-checked Node20.20.2 each passed107 checks using the
current compiled v0.2.5 core bc61fd865a732137d7b85cc9916bbe64652684fc73a99766689536fdd77b0c81.
The checks include two real-source packets, synthetic closed reduction and zero
budget, unsupported/mismatched facts, all original SDK formats, exact old ORM
report/capsule replay, three actual current CLI replays, and tamper refusal.
This is automated development evidence, not a new database run, formal timing,
independent execution acceptance or a completed source/portable package run.

The first control correctly exposed the intentional v1/v2 verification receipt
currentEngine change from24 to25. Its source, failure and original expectations
remain. Only that single top-level verification-response field is compared with
the current sdk.version(); recordedEngine must stay24 and all other fields are
identical. No nested version, business value, report or capsule is rewritten.
After the two107 runs, only existing receipt fields were added to console output
for release integration; the actually executed test source is retained separately.

The build validates/copies all nine frozen files and the small loader. CJS files
participate in verificationFingerprint. Packaging verifies source and shipped
bytes, requires the frozen runtime and original producer closure, and runs the
same107 controls in both fresh source and portable consumers. These final
consumer runs are mandatory at integration; they were not executed by this
isolated host slice.

Current consumer command:

    node scripts/compat-v024-test.mjs dist fixtures/compat-v024 NEW_OUTPUT

The result is suitable for `publicV024CompatibilityTests` in the main test
summary. All fields needed by release validation are exposed in console JSON.
The two new exact package check labels are `source actual public24 fifteen-family
SDK/CLI and synchronous lazy ORM replay` and the corresponding `portable` label.

Integration ownership: this slice changes .gitattributes, cmd/orm-profile.mjs,
cmd/sdk.mjs, scripts/build.mjs, verification-fingerprint.mjs,
distribution_manifest.py, package_release.py and test_distribution.py. It adds
the two small helpers, current compatibility test and fixed runtime. It does not
change scripts/test.mjs, scripts/release.py, MoonBit core files or version
metadata. Preserve the integration branch's existing wrapper/export list: for
cmd/sdk.mjs only add the explicit recorded0.2.4 engine; do not copy later model
exports from this developer checkout. shared-minimal.patch is the actual diff,
not a placeholder patch. Root owns the main summary/release and full regression.
