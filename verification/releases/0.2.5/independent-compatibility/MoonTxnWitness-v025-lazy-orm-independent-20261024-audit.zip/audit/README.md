# Independent technical candidate review

This archive preserves frozen v0.2.5 source/runtime, original public v0.2.4 capsules, original and additional checks, complete first outputs and the original 48/50 snapshot-omission failure. The unchanged original ORM50 checks pass after four existing raw fixtures are included. This is independent AI technical review; public release, human use and organizer acceptance are separate.

Run `python -B replay-clean.py --out NEW_EMPTY_DIRECTORY --node NODE24 --node20 NODE20` from this extracted directory. Python standard library and supplied official Node runtimes are the only external tools. The runner copies the frozen closure to another new directory; it neither borrows the author working tree nor compiles MoonBit or starts a database.

`integrated-freeze.json` plus `snapshot-fixture-supplement.json` bind all root-relative source files. `review-summary.json` records executed scope and preserved first failure. Additional work runtime is a byte-identical clone used for destructive missing-file/tamper challenges and restored after each check.

The first receipts are immutable. A separate clean extraction replay receipt records the actual ZIP extraction run. This archive does not claim a newly published v0.2.5 download or performance benefit.
