from pathlib import Path
import argparse,shutil,subprocess,json,hashlib,os,sys
ap=argparse.ArgumentParser();ap.add_argument('--out',type=Path,required=True);ap.add_argument('--node',default='node');ap.add_argument('--node20');args=ap.parse_args();source=Path(__file__).resolve().parent;out=args.out.resolve();out.mkdir(exist_ok=False);repo=out/'integrated'
shutil.copytree(source/'integrated',repo,ignore=lambda directory,names:['outputs']if Path(directory)==source/'integrated'and'outputs'in names else [])
for name in ['additional-replay.py','additional-worker.mjs']:shutil.copyfile(source/name,out/name)
sha=lambda b:hashlib.sha256(b).hexdigest();records=json.loads((source/'integrated-freeze.json').read_bytes())['sourceFiles']+json.loads((source/'snapshot-fixture-supplement.json').read_bytes())['sourceFiles']
for row in records:assert sha((repo/row['file']).read_bytes())==row['sha256']
(repo/'outputs').mkdir();env=os.environ.copy();env['TEMP']=str(out);env['TMP']=str(out);env.pop('MTW_PG_DSN',None);env.pop('MTW_PG_CONNECTION_FILE',None)
jobs=[('public24-clean',[args.node,'scripts/compat-v024-test.mjs','dist','fixtures/compat-v024','outputs/public24-clean']),('original50-clean',[args.node,'scripts/orm-profile-sdk-test.mjs','--repository',str(repo),'--runtime',str(repo/'dist'),'--output-root','outputs/original50-clean']),('classification-demo-clean',[args.node,'examples/classification-roundtrip.mjs','--out-root','outputs/classification-demo-clean'])]
if args.node20:jobs.append(('public24-node20-clean',[args.node20,'scripts/compat-v024-test.mjs','dist','fixtures/compat-v024','outputs/public24-node20-clean']))
rows=[]
for name,cmd in jobs:
 r=subprocess.run(cmd,cwd=repo,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=180);(out/(name+'.stdout')).write_bytes(r.stdout);(out/(name+'.stderr')).write_bytes(r.stderr)
 detail=json.loads(r.stdout);expected=107 if name.startswith('public24')else 50 if name=='original50-clean'else None
 assert r.returncode==0 and detail['passed']and(expected is None or detail['checks']==expected),(name,r.returncode,detail)
 rows.append({'name':name,'passed':True,'checks':detail.get('checks'),'stdoutSha256':sha(r.stdout),'stderrSha256':sha(r.stderr)})
 if name=='classification-demo-clean':
  first=json.loads((source/'classification-demo-first.stdout').read_bytes());assert all(row['sha256']==sha((repo/'outputs/classification-demo-clean'/detail['outputDirectory']/row['file']).read_bytes())for row in first['files'])
r=subprocess.run([sys.executable,'-B','additional-replay.py',args.node],cwd=out,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=180);(out/'additional-clean.stdout').write_bytes(r.stdout);(out/'additional-clean.stderr').write_bytes(r.stderr);extra=json.loads(r.stdout);assert r.returncode==0 and extra['passed']and extra['checks']==13
rows.append({'name':'additional13-clean','passed':True,'checks':13,'stdoutSha256':sha(r.stdout),'stderrSha256':sha(r.stderr)})
assert all(sha((repo/row['file']).read_bytes())==row['sha256']for row in records)
result={'format':'independent-v025-clean-audit-archive-replay/v1','passed':True,'checks':rows,'sourceFilesUnchanged':True,'newDatabaseExecution':False,'moonCompilation':False,'formalPerformanceMeasurement':False,'classificationDemoFourOutputsByteIdenticalToFirst':True,'scope':'Original 107 public24 controls on supplied Node24 and optional supplied Node20, unchanged ORM50 with full frozen source/raw fixtures, new category example and independent13 lazy/tamper checks. No old238 rerun and no public025 download claim.'};(out/'clean-replay-receipt.json').write_bytes((json.dumps(result,indent=2)+'\n').encode());print(json.dumps(result))
