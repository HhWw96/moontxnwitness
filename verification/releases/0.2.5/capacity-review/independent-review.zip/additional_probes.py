"""Independent capacity denial checks; small files and SQLite index only, no DB."""
from pathlib import Path
import importlib.util,json,hashlib,os,sqlite3,subprocess,sys,unittest
from unittest import mock
import types
BASE=Path(__file__).resolve().parent
SOURCE=BASE/'source'
sys.path.insert(0,str(SOURCE/'integrations/python'));sys.path.insert(0,str(SOURCE/'experiments/provenance'))
from moontxnwitness_capture._experimental_budget import PROFILE,LIMITS
from moontxnwitness_capture.source_sink import GroupedSourceSink,SourceSinkError,verify_grouped_source
from moontxnwitness_capture.instrumentation import Instrumentation,verify_lifecycle_storage
from moontxnwitness_capture.journal_v3 import SegmentedJournal,JournalReader,_Identities,_json,INDEX,JournalError
import full_capture_cost as harness
RAW=BASE/'additional-raw';RAW.mkdir(exist_ok=False)

def rewrite(path,change):
    item=json.loads(path.read_bytes());item.pop('indexSha256');change(item);item['indexSha256']=hashlib.sha256(_json(item)).hexdigest();path.write_bytes(_json(item)+b'\n')

class Tests(unittest.TestCase):
    def setUp(self):self.home=RAW/self._testMethodName;self.home.mkdir()
    def journal(self,**kw):
        obj=SegmentedJournal(self.home/'journal',**kw)
        assert obj.append({'seq':1,'time':0,'kind':'snapshot','initial':{},'consistent':True}).accepted
        assert obj.close(source_closed=True).complete
        return obj
    def test_unknown_profiles_reject_before_creating_storage(self):
        for n,value in enumerate([True,False,0,{},PROFILE+'-unknown']):
            for label,constructor in [('source',GroupedSourceSink),('journal',SegmentedJournal),('lifecycle',Instrumentation)]:
                target=self.home/(label+'-'+str(n))
                with self.subTest(value=value,label=label),self.assertRaises(ValueError):constructor(target,experimental_budget=value)
                self.assertFalse(target.exists())
    def test_disk_marker_does_not_authorize_default_source_reader(self):
        sink=GroupedSourceSink(self.home/'source');sink.close()
        rewrite(sink.index,lambda x:x.update(experimentalBudget=PROFILE))
        with self.assertRaises(ValueError):verify_grouped_source(sink.path)
    def test_resigned_source_byte_ceiling_cannot_authorize_itself(self):
        sink=GroupedSourceSink(self.home/'source',experimental_budget=PROFILE);sink.close()
        rewrite(sink.index,lambda x:x['limits'].update(totalBytes=LIMITS['sourceBytes']+1))
        with self.assertRaises(SourceSinkError):verify_grouped_source(sink.path,experimental_budget=PROFILE)
    def test_resigned_source_boolean_count_refused(self):
        sink=GroupedSourceSink(self.home/'source',experimental_budget=PROFILE);sink.close()
        rewrite(sink.index,lambda x:x['limits'].update(records=True))
        with self.assertRaises(SourceSinkError):verify_grouped_source(sink.path,experimental_budget=PROFILE)
    def test_disk_marker_does_not_authorize_default_journal_reader(self):
        journal=self.journal()
        rewrite(journal.path/INDEX,lambda x:(x.update(experimentalBudget=PROFILE),x['transactionIndex'].update(maxBytes=65536)))
        result=JournalReader(journal.path).verify();self.assertFalse(result.valid);self.assertFalse(result.complete)
    def test_resigned_journal_sqlite_overcap_refused(self):
        journal=self.journal(experimental_budget=PROFILE,transaction_index_bytes=65536)
        rewrite(journal.path/INDEX,lambda x:x['transactionIndex'].update(maxBytes=LIMITS['transactionIndexBytes']+4096))
        result=JournalReader(journal.path,experimental_budget=PROFILE).verify();self.assertFalse(result.valid);self.assertFalse(result.complete)
    def test_resigned_journal_boolean_sqlite_budget_refused(self):
        journal=self.journal(experimental_budget=PROFILE,transaction_index_bytes=65536)
        rewrite(journal.path/INDEX,lambda x:x['transactionIndex'].update(maxBytes=True))
        self.assertFalse(JournalReader(journal.path,experimental_budget=PROFILE).verify().valid)
    def test_lifecycle_overcap_metadata_does_not_authorize_reader(self):
        observer=Instrumentation(self.home/'capture',experimental_budget=PROFILE);observer.note('original',value='0.2.4/Unicode');observer.close()
        expected=json.loads((observer.output/'instrumentation.json').read_bytes())['lifecycle']
        expected['limits']['bytes']=LIMITS['lifecycleBytes']+1
        with self.assertRaises(ValueError):verify_lifecycle_storage(observer.output/'lifecycle.jsonl',expected,experimental_budget=PROFILE)
    def test_existing_sqlite_above_new_cap_refused_without_growth_or_row_loss(self):
        path=self.home/'existing.sqlite3';index=_Identities(path,byte_limit=65536)
        try:
            for i in range(120):self.assertTrue(index.add('transaction-'+str(i)+'x'*100,i+1))
            index.commit()
        finally:index.close()
        size=path.stat().st_size;self.assertGreater(size,8192)
        with self.assertRaises(JournalError):_Identities(path,existing=True,byte_limit=8192)
        self.assertEqual(path.stat().st_size,size)
        connection=sqlite3.connect('file:'+path.as_posix()+'?mode=ro',uri=True)
        try:self.assertEqual(connection.execute('SELECT count(*) FROM transactions').fetchone()[0],120)
        finally:connection.close()
    def test_scratch_refusal_never_connects_and_remains_ineligible(self):
        args=types.SimpleNamespace(quick=False,workload='all',profile='column',seed=20261023,archive_cells=True,max_cells=None,experimental_budget=PROFILE)
        config=harness.plan(args)['cells'][0]
        calls=[]
        def connect(**kw):calls.append(kw);raise AssertionError('Real DB must not be reached')
        target=self.home/'cell';target.mkdir()
        with mock.patch.object(harness,'preparation',return_value={'eligibleToStart':True}),mock.patch.object(harness,'scratch_preparation',return_value={'eligibleToStart':False,'reason':'verification_scratch_missing'}):
            result=harness.run_cell(config,target,connect)
        self.assertEqual(calls,[]);self.assertFalse(result['actualDatabaseExecution']);self.assertFalse(result['formalProtocolCompleted'])
        self.assertEqual(result['errorClass'],'CapacityPreflightRefused');self.assertTrue(harness.target_eligibility_reasons(result))
    def test_every_capacity_stop_reason_is_ineligible(self):
        for label in ['StorageReserveReached','DatabaseAndWalBudgetExhausted','AttemptLogBudgetExhausted','WarmupAttemptBudgetExhausted']:
            receipt={'formalProtocolCompleted':True,'failures':0,'warmupFailures':0,'protocolFailures':[{'errorClass':label,'sqlstate':None}],'endToEndCommittedTps':1,'allAttemptP95Ns':1}
            with self.subTest(label=label):self.assertIn('protocol_failures',harness.target_eligibility_reasons(receipt))
    def test_default_source_wire_matches_frozen_bf281_producer_exactly(self):
        rows=[]
        for label,root in [('legacy',BASE/'legacy-bf281'),('candidate',SOURCE)]:
            target=self.home/(label+'.jsonl')
            q=subprocess.run([sys.executable,'-B',str(BASE/'produce_default_wire.py'),str(root),str(target)],capture_output=True,timeout=15)
            (self.home/(label+'.stdout')).write_bytes(q.stdout);(self.home/(label+'.stderr')).write_bytes(q.stderr)
            self.assertEqual(q.returncode,0,q.stderr.decode());rows.append(json.loads(q.stdout))
        self.assertEqual(rows[0],rows[1]);self.assertFalse(rows[0]['experimentalMarkerPresent'])
        self.assertEqual((self.home/'legacy.jsonl').read_bytes(),(self.home/'candidate.jsonl').read_bytes())

if __name__=='__main__':
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Tests))
    print(json.dumps({'kind':'independent-capacity-denial-probes','passed':result.wasSuccessful(),'testsRun':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'skipped':len(result.skipped),'actualDatabaseExecution':False,'formalPerformanceMeasured':False}))
    raise SystemExit(0 if result.wasSuccessful() else 1)
