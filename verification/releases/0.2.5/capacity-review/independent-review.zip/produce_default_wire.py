from pathlib import Path
import json,sys,hashlib
sys.path.insert(0,str(Path(sys.argv[1])/'integrations/python'))
from moontxnwitness_capture.source_sink import GroupedSourceSink
sink=GroupedSourceSink(Path(sys.argv[2]),flush_interval=60)
assert sink.append({'kind':'source-batch','value':'0.2.4/独立字节','zero':0}).accepted
assert sink.append({'kind':'source-batch','value':'second','flag':False}).accepted
result=sink.close();assert result['storageSealed']
raw=sink.path.read_bytes();index=json.loads(sink.index.read_bytes())
print(json.dumps({'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw),'experimentalMarkerPresent':'experimentalBudget' in index,'limits':index['limits']}))
