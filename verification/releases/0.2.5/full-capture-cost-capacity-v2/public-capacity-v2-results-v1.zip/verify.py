import collections,hashlib,json,math,pathlib,zlib

def require(v,m):
 if not v:raise RuntimeError(m)
def sha(b):return hashlib.sha256(b).hexdigest()
def main():
 b=pathlib.Path(__file__).resolve().parent
 def raw(n):return (b/n).read_bytes()
 def obj(n):return json.loads(raw(n))
 m=obj('MANIFEST.json');files=m['files'];actual={p.relative_to(b).as_posix() for p in b.rglob('*') if p.is_file()}
 require(actual==set(files)|{'MANIFEST.json'},'unexpected/missing package files')
 for n,v in files.items():
  p=pathlib.PurePosixPath(n);require(not p.is_absolute() and '..' not in p.parts and '\\' not in n,'unsafe manifest path')
  z=raw(n);require(len(z)==v['bytes'] and sha(z)==v['sha256'],'manifest mismatch '+n)
 summary=obj('summary.json');snap=obj('source-snapshot/bindings.json');count=0;report={}
 for profile in ['column','sidecar']:
  pre=f'original/{profile}/';ex=obj(pre+'outer-extraction-receipt.json');ix=obj(pre+'cell-extraction-receipt.json');central={x['path']:x for x in obj(pre+'outer-zip-central-directory.json')}
  require(ex['passed'] and ix['passed'] and not ex['wholeArtifactDigestVerifiedLocally'] and not ix['wholeArtifactDigestVerifiedLocally'],'extraction scope changed')
  for selected in ex['selectedMembers']:
   z=raw(pre+'artifact-selected/'+selected['path']);require(len(z)==selected['bytes'] and sha(z)==selected['sha256'],'selected SHA mismatch')
   require(zlib.crc32(z)&0xffffffff==central[selected['path']]['crc32'],'selected outer CRC mismatch')
  old=obj(pre+'artifact-selected/full-capture-cost/measured/receipt.json');planraw=raw(pre+'artifact-selected/full-capture-cost/preregistered/plan.json');plan=json.loads(planraw)
  require(planraw==raw(pre+'artifact-selected/full-capture-cost/measured/plan.json'),'plan mismatch');require(sha(planraw)==summary['profiles'][profile]['planSha256'],'plan binding mismatch')
  rows=[]
  require(len(ix['cells'])==36 and len(old['cellArchives'])==36,'expected 36 cells')
  for i in range(36):
   z=raw(pre+f'cells/cell-{i}/receipt.json');mraw=raw(pre+f'cells/cell-{i}/archive-manifest.json');d=json.loads(z);cm=json.loads(mraw);p=old['cellArchives'][i];bind=ix['cells'][i]
   require(sha(z)==p['originalReceiptSha256']==cm['receiptSha256']==cm['files']['receipt.json']['sha256']==bind['receiptSha256'],'nested receipt binding')
   require(sha(mraw)==p['manifestSha256']==bind['manifestSha256'],'nested manifest binding');require(len(z)==cm['files']['receipt.json']['bytes'],'nested receipt length')
   require(d['configuration']==plan['cells'][i],'cell config drift');require(d['sourceBindings']==snap['files'] and d['sourceUnchangedAfterCell'],'source drift')
   require(math.isclose(d['endToEndCommittedTps'],d['commits']/(d['endToEndWallNs']/1e9),rel_tol=1e-12),'end-to-end TPS mismatch')
   generated=summary['profiles'][profile]['cells'][i]
   for k,v in generated.items():
    if k in d:require(d[k]==v,'generated cell data differs '+k)
   require(generated['receiptSha256']==sha(z) and generated['manifestSha256']==sha(mraw),'generated cell binding differs');rows.append(d);count+=1
  for wl in ['serial','parallel','hot','crud']:
   rr=[r for r in rows if r['configuration']['workload']==wl];require(len(rr)==9,'workload cell count');ratios=collections.defaultdict(list)
   for batch in range(3):
    mm={r['configuration']['mode']:r for r in rr if r['configuration']['batch']==batch};require(set(mm)==set('ABC'),'duplicate/missing pair');A,B,C=[mm[k] for k in 'ABC']
    values={'throughputBOverA':B['endToEndCommittedTps']/A['endToEndCommittedTps'],'throughputCOverB':C['endToEndCommittedTps']/B['endToEndCommittedTps'],'throughputCOverA':C['endToEndCommittedTps']/A['endToEndCommittedTps'],'p95BOverA':B['allAttemptP95Ns']/A['allAttemptP95Ns'],'p95COverB':C['allAttemptP95Ns']/B['allAttemptP95Ns'],'p95COverA':C['allAttemptP95Ns']/A['allAttemptP95Ns']}
    for k,v in values.items():ratios[k].append(v)
   derived={k:math.exp(sum(map(math.log,v))/len(v)) for k,v in ratios.items()};target=summary['profiles'][profile]['comparison'][wl]
   for k,v in derived.items():require(math.isclose(v,target[k],rel_tol=1e-12),'derived ratio differs')
   require(math.isclose(derived['throughputCOverA'],old['comparison'][wl]['fullCaptureThroughputCOverA'],rel_tol=1e-12),'old TPS differs');require(math.isclose(derived['p95COverA'],old['comparison'][wl]['fullCaptureP95COverA'],rel_tol=1e-12),'old P95 differs')
   eligible=all(r['eligibleForTargets'] for r in rr);require(eligible==target['eligibleForTargets'],'eligibility differs')
   passed=eligible and derived['throughputCOverA']>=.90 and derived['p95COverA']<=1.15;require(passed==target['performanceTargetsPassed']==old['comparison'][wl]['performanceTargetsPassed'],'target status differs')
  states=collections.Counter();warm=collections.Counter()
  for r in rows:states.update(r['sqlstateCounts']);warm.update(r['warmupSqlstateCounts'])
  require(dict(states)==summary['profiles'][profile]['measuredSqlstateCounts'] and dict(warm)==summary['profiles'][profile]['warmupSqlstateCounts'],'SQLSTATE aggregate differs')
  report[profile]={'cells':len(rows),'eligible':sum(r['eligibleForTargets'] for r in rows),'formalProtocolCompleted':old['formalProtocolCompleted'],'performanceTargetsPassed':old['performanceTargetsPassed'],'sqlstateCounts':dict(states),'warmupSqlstateCounts':dict(warm)}
 for n,v in snap['files'].items():require(sha(raw('source-snapshot/'+n))==v,'source snapshot mismatch')
 print(json.dumps({'passed':True,'manifestedFiles':len(files),'originalCells':count,'sourceBindings':len(snap['files']),'profiles':report,'wholeArtifactDigestVerifiedLocally':False,'wholeCellArchiveShasVerifiedLocally':False,'rawLogStreamsIndependentlyVerifiedLocally':False,'measurementRerun':False},indent=2))
if __name__=='__main__':main()
