# Verify the ZIP against its own pinned manifest and optional external SHA; no SDK/timing.
from pathlib import Path,PurePosixPath
import argparse,hashlib,json,os,stat,zipfile
FORMAT='moontxnwitness-flat-formal-public-evidence/v1'
def h(raw):return hashlib.sha256(raw).hexdigest()
def path(name):
 p=PurePosixPath(name)
 if not name or p.is_absolute()or any(x in['.','..','.git']for x in p.parts)or'\\'in name or':'in name:raise ValueError('Unsafe archive member')
 return p
parser=argparse.ArgumentParser();parser.add_argument('archive');parser.add_argument('--sha256');parser.add_argument('--restore');args=parser.parse_args()
archive=Path(args.archive);raw=archive.read_bytes()
if len(raw)>24*1024**2:raise ValueError('Public ZIP size limit')
if args.sha256 and h(raw)!=args.sha256:raise ValueError('External ZIP SHA mismatch')
with zipfile.ZipFile(archive)as z:
 infos=z.infolist();names=[i.filename for i in infos]
 if len(names)!=len(set(names))or len(names)>4096 or sum(i.file_size for i in infos)>32*1024**2:raise ValueError('Archive member budget')
 for i in infos:
  path(i.filename)
  if i.is_dir()or stat.S_ISLNK(i.external_attr>>16):raise ValueError('Unexpected directory/symlink')
 if z.testzip()is not None:raise ValueError('ZIP CRC mismatch')
 manifest=json.loads(z.read('manifest.json'))
 if manifest['format']!=FORMAT:raise ValueError('Unknown manifest')
 entries={v['path']:v for v in manifest['files']}
 if len(entries)!=len(manifest['files'])or set(names)!=set(entries)|{'manifest.json'}:raise ValueError('Manifest file-set mismatch')
 for name,record in entries.items():
  value=z.read(name)
  if len(value)!=record['bytes']or h(value)!=record['sha256']:raise ValueError('Member SHA mismatch: '+name)
 if args.restore:
  output=Path(args.restore).absolute()
  if output.exists():raise ValueError('Restore output must not exist')
  for parent in output.parents:
   if parent.exists():
    info=parent.lstat()
    if parent.is_symlink()or getattr(info,'st_file_attributes',0)&getattr(stat,'FILE_ATTRIBUTE_REPARSE_POINT',0):raise ValueError('Reparse restore ancestor')
  output.mkdir(parents=False,exist_ok=False)
  for name in names:
   target=output.joinpath(*path(name).parts);target.parent.mkdir(parents=True,exist_ok=True)
   with target.open('xb')as f:f.write(z.read(name))
  for name,record in entries.items():
   if h(output.joinpath(*path(name).parts).read_bytes())!=record['sha256']:raise ValueError('Restored SHA mismatch')
 print(json.dumps({'verified':True,'zipBytes':len(raw),'zipSha256':h(raw),'manifestSha256':h(z.read('manifest.json')),'members':len(names),'originalEvidenceFiles':manifest['originalEvidenceFileCount'],'originalEvidenceBytes':manifest['originalEvidenceBytes'],'restored':bool(args.restore),'newPerformanceMeasurement':False}))
