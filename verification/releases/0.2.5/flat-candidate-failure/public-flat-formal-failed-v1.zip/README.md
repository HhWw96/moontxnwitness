# Flat SDK formal experiment: retained performance failure

This is a lossless evidence package for an experimental candidate containing future v0.2.5/v0.2.6/v0.2.7 dependencies. The default was not enabled. The formal performance controls failed. This package is not a stable-release performance claim or competition approval.

Scope: all 2,078 original formal files and all 16 independent-review files, plus the 102 exact frozen input/runtime bindings, the unchanged plan, original runner and fixture generator. Original bytes are unchanged. The package excludes Git history, Git bundles, unbound old logs and source-build dependencies. It does not claim MoonBit source-build reproduction.

There are 519 archived final complete output objects, one per worker, and all 15,570 timing sample values (519 workers x 30 samples). It does NOT contain complete output objects from every timed call. The final output gzip payloads expand to 219,477,813 bytes; their original compressed bytes are retained. Five warmups, 30 timed samples and three batches are the frozen plan. No new benchmark or SDK call was performed to create this package.

The original independent review recorded 13 failures among 120 actual control comparisons, involving seven unique fixtures. The frozen receipt has performanceAccepted=false/defaultEnabled=false. These failures and all original pass/fail statements remain unchanged. Static notes do not prove the cause of P95 regressions.

## Verify and restore

Keep the external ZIP SHA-256 from the handoff receipt. Use Python 3 and run:

    python verify_public_package.py public-flat-formal-failed-v1.zip --sha256 THE_EXTERNAL_ZIP_SHA256

For an empty new destination (its parent must exist):

    python verify_public_package.py public-flat-formal-failed-v1.zip --sha256 THE_EXTERNAL_ZIP_SHA256 --restore restored-new

The verifier checks exact member sets, ZIP CRC, each member's full SHA and size, the external ZIP SHA when supplied, and every restored file. It refuses an existing output or a reparse ancestor. manifest.json maps public paths to unchanged original roles/names. The project LICENSE comes from immutable public metadata commit e1ecd62864af115db733f1efa329ed353c2bd27b. Third-party notices are the unchanged member of the exact original public v0.2.4 portable ZIP; its whole-ZIP SHA and member SHA are bound in manifest.json. The exact public020 notices are also retained in the 102 original bindings.

## Recompute the existing evidence

The original independent scripts are unchanged under evidence/independent/. Create fresh empty output directories before passing them as the final argument. Statistics can be recomputed without invoking an SDK or timer:

    python evidence/independent/audit_statistics.py evidence/formal project/protocol/plan.json new-statistics

The unchanged original Node output audit additionally asserts the exact original Windows Node v24.13.0 binary SHA-256:

    d14ba95cdce1ef7dc9ad3ac74949ca5db38b27378ee30f30a23cf26f9e875a11

With that exact binary, its original command shape is:

    node evidence/independent/audit_outputs.mjs evidence/formal project/protocol/plan.json new-output-audit

That binary check has not been removed or relaxed for portability. This archive does not include the Node binary. The archived original audits and their original outputs already document the completed review; the package verifier is a separate byte-integrity tool and does not substitute for those assertions.

No original file was moved, deleted, redacted or overwritten. Readable and compressed contents were scanned for private home-path prefixes and credential-shaped strings; no matches were found in this selected closure. Pattern scanning is not a guarantee against every type of sensitive content. No Git ancestor or unbound log is included.
