// Full SDK experiment. Preparation/semantic checks do not execute timings.
// --run requires a separately granted exclusive-host measurement window.
import assert from 'node:assert/strict';
import {mkdirSync,readFileSync,writeFileSync,copyFileSync,readdirSync} from 'node:fs';
import {resolve,dirname,relative} from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
import {spawnSync} from 'node:child_process';
import {gzipSync,gunzipSync} from 'node:zlib';
import {performance} from 'node:perf_hooks';
import {platform,release,arch,cpus} from 'node:os';
import {performanceFixturesV020} from '../experiments/graph_flat_candidate/performance-v020-fixtures.mjs';
const root=resolve(dirname(fileURLToPath(import.meta.url)),'..');
const sha=v=>createHash('sha256').update(v).digest('hex'),json=v=>JSON.stringify(v,null,2)+'\n';
const load=p=>JSON.parse(readFileSync(p,'utf8'));
const immutable=(p,v)=>writeFileSync(p,typeof v==='string'||Buffer.isBuffer(v)?v:json(v),{flag:'wx'});
const fixtureSource='experiments/graph_flat_candidate/performance-v020-fixtures.mjs';
const FIXTURE_SHA='7bae8ab986eedbc3674ca37c36a7dabe2b6d864fbc8f4ca80a7fcd1bbd8c547e';
const BASE_MANIFEST_SHA='0b764ff214e1a5cf6732a7c783899c4bbfeec2dd13b7c0ecbeb0732757f68503';
const median=a=>[...a].sort((x,y)=>x-y)[Math.floor(a.length/2)];
const p95=a=>[...a].sort((x,y)=>x-y)[Math.ceil(a.length*.95)-1];
const geomean=a=>Math.exp(a.reduce((s,v)=>s+Math.log(v),0)/a.length);
function bindingTree(folder){
  const files={};
  function visit(path){for(const entry of readdirSync(path,{withFileTypes:true})){
    const name=resolve(path,entry.name);if(entry.isDirectory())visit(name);
    else files[relative(folder,name).split('\\').join('/')]=sha(readFileSync(name));
  }}visit(folder);return files;
}
function copyRuntime(source,target){
  mkdirSync(target,{recursive:true});
  for(const name of readdirSync(source))if(name.endsWith('.mjs')||name==='build-manifest.json')
    copyFileSync(resolve(source,name),resolve(target,name));
}
function invoke(sdk,f,text){
  if(f.method)return sdk[f.method](text,f.options??{});
  const name={normalize:'normalizeCaptureV3',analyze:'analyzeV3',reduce:'reduceV3',legacy:'analyzeWithOptions','legacy-reduce':'shrinkWithOptions'}[f.phase];
  assert.ok(name,'Unknown fixed fixture phase');return sdk[name](text);
}
function comparable(value,f,variant){
  const x=structuredClone(value),report=['reduce','legacy-reduce'].includes(f.phase)?x.report:x;
  if(f.phase==='legacy-reduce'){assert.equal(x.version,variant.version);x.version='<validated-engine-version>';}
  if(f.phase==='normalize')return x;
  if(f.method){
    assert.equal(x.engine.version,variant.version);assert.equal(x.engine.coreSha256,variant.coreSha256);
    assert.equal(x.engine.hostSha256,variant.hostSha256[f.method]);
    x.engine.version='<validated-engine-version>';x.engine.coreSha256='<validated-actual-core-sha256>';
    assert.equal(x.result.version,variant.version);x.result.version='<validated-engine-version>';
    return x;
  }
  assert.equal(report.version,variant.version);report.version='<validated-engine-version>';
  if(['analyze','reduce'].includes(f.phase)&&report.evidence?.tool==='MoonTxnWitness'&&report.evidence.schemaVersion===2){
    assert.equal(report.evidence.version,variant.version);report.evidence.version='<validated-engine-version>';
  }
  return x;
}
function verifyInputs(planPath){
  const plan=load(planPath),base=dirname(resolve(planPath));
  assert.equal(plan.format,'moontxnwitness-flat-sdk-performance-plan/v1');
  assert.equal(plan.formalPerformanceMeasured,false);
  for(const[name,hash]of Object.entries(plan.bindings))assert.equal(sha(readFileSync(resolve(base,name))),hash,'Prepared input changed: '+name);
  assert.equal(sha(readFileSync(resolve(root,fixtureSource))),FIXTURE_SHA);
  assert.equal(sha(readFileSync(fileURLToPath(import.meta.url))),plan.runnerSha256,'Runner changed after plan freeze');
  return {plan,base};
}
function prepare(args){
  const [generatedArg,publicArg,controlsArg,outArg,...extra]=args;
  assert.ok(generatedArg&&publicArg&&controlsArg&&outArg&&!extra.length,
    'Usage: --prepare GENERATED_ROOT PUBLIC_REPOSITORY PASSED_CONTROLS NEW_DIRECTORY');
  const generated=resolve(generatedArg),publicRoot=resolve(publicArg),out=resolve(outArg);
  mkdirSync(out,{recursive:false});
  assert.equal(sha(readFileSync(resolve(root,fixtureSource))),FIXTURE_SHA);
  const generation=load(resolve(generated,'generation.json')),controls=load(resolve(controlsArg,'receipt.json'));
  assert.equal(controls.passed,true);assert.equal(controls.generatedManifestSha256,sha(readFileSync(resolve(generated,'generation.json'))));
  assert.equal(controls.measurementCountersDisabled,true);
  const manifestText=readFileSync(resolve(publicRoot,'verification/baselines/0.2.0/manifest.json'));
  assert.equal(sha(manifestText),BASE_MANIFEST_SHA);const pinned=JSON.parse(manifestText);
  assert.equal(pinned.publicArchiveSha256,'92ffd79314841e09b7ba13209c7678d4626265d74c3c12dba2726089e9b490a3');
  const download=readFileSync(resolve(publicRoot,pinned.anonymousDownloadReviewReceipt));
  assert.equal(sha(download),pinned.anonymousDownloadReviewReceiptSha256);assert.equal(JSON.parse(download).passed,true);
  mkdirSync(resolve(out,'public020'));
  for(const[name,info]of Object.entries(pinned.files)){
    const raw=readFileSync(resolve(publicRoot,pinned.provider,name));
    assert.equal(raw.length,info.bytes);assert.equal(sha(raw),info.sha256);
    immutable(resolve(out,'public020',name),raw);
  }
  immutable(resolve(out,'public020-baseline-manifest.json'),manifestText);
  immutable(resolve(out,'public020-download-receipt.json'),download);
  for(const variant of ['legacy','flat']){
    copyRuntime(resolve(generated,variant,'dist'),resolve(out,variant,'dist'));
    for(const[name,hash]of Object.entries(controls.runtimeHashes[variant]))
      assert.equal(sha(readFileSync(resolve(out,variant,'dist',name))),hash,'Control/runtime mismatch');
  }
  for(const name of ['flat-sdk.mjs','legacy-replay.mjs']){
    const raw=readFileSync(resolve(generated,name));assert.equal(sha(raw),generation.facades[name]);immutable(resolve(out,name),raw);
  }
  immutable(resolve(out,'generation.json'),readFileSync(resolve(generated,'generation.json')));
  immutable(resolve(out,'complete-sdk-controls.json'),readFileSync(resolve(controlsArg,'receipt.json')));
  const publicFixtures=performanceFixturesV020(publicRoot);assert.equal(publicFixtures.length,41);
  const fixtures=publicFixtures.map(f=>({...f,variants:['public020','legacy','flat'],comparison:'public-common'}));
  for(const name of ['g0','g1c','source-closed-noisy-g2','missing-source','unknown-sql','competing-categories']){
    const input=load(resolve(root,'fixtures/classification-v3',name+'.json'));
    fixtures.push({name:'category-'+name,phase:'category',method:'classifyV3',input,options:{},expectedStatus:null,
      group:'category-complete-sdk',variants:['legacy','flat'],comparison:'same-source'});
  }
  const modelManifest=load(resolve(root,'fixtures/classification-models-v3/manifest.json'));
  for(const name of [...Object.keys(modelManifest.syntheticCases),...Object.keys(modelManifest.retainedCollectorCases),...Object.keys(modelManifest.frozenG1bCases)])
    fixtures.push({name:'model-'+name.replaceAll('/','-'),phase:'models',method:'classifyModelsV3',
      input:load(resolve(root,'fixtures/classification-models-v3',name+'.json')),options:{},expectedStatus:null,
      group:'models-complete-sdk',variants:['legacy','flat'],comparison:'same-source'});
  mkdirSync(resolve(out,'fixtures'));
  for(const f of fixtures)immutable(resolve(out,'fixtures',f.name+'-'+f.phase+'.json'),f);
  const variants={};
  for(const [variant,sdk]of [['public020','public020/sdk.mjs'],['legacy','legacy/dist/sdk.mjs'],['flat','flat-sdk.mjs']]){
    const folder=variant==='public020'?resolve(out,'public020'):resolve(out,variant,'dist');
    const manifest=load(resolve(folder,'build-manifest.json'));assert.deepEqual(manifest.toolchain,pinned.buildManifest.toolchain);
    variants[variant]={sdk,version:manifest.version,coreSha256:sha(readFileSync(resolve(folder,'core.mjs'))),
      hostSha256:variant==='public020'?{}:{classifyV3:sha(readFileSync(resolve(folder,'classification.mjs'))),
        classifyModelsV3:sha(readFileSync(resolve(folder,'classification-models.mjs')))}};
  }
  const plan={format:'moontxnwitness-flat-sdk-performance-plan/v1',experiment:generation.experiment,
    prepared:true,formalPerformanceMeasured:false,defaultEnabled:false,performanceImprovementClaimed:false,
    warmups:5,samples:30,batches:3,independentProcessPerVariantFixtureBatch:true,
    archiveAfterSamplesAndRss:true,wholeSdkTimed:true,summaryOutputUsed:false,proofCountersIncluded:false,
    coldMeasurements:['moduleImportMs','firstFullCallMs','processAgeAtFirstResultMs'],memory:'process.resourceUsage().maxRSS KiB',
    protocol:'public020 original 41 full SDK loads including unchanged 20 control fixtures; 25 new complete category/model calls only compare with same-source legacy',
    variants,fixtures:fixtures.map(f=>({path:'fixtures/'+f.name+'-'+f.phase+'.json',name:f.name,phase:f.phase,group:f.group,variants:f.variants})),
    gate:{controlP95RegressionLimit:'max(10 percent, 2 milliseconds)',existingGraphSuiteTargetsUnchanged:true,
      graphMedianSpeedup:1.3,graphPeakRssRatio:.8,formalOriginalGraphSuiteStillRequired:true,
      noAutomaticDefaultEnablement:true},
    beforeMeasurement:'Stop other compilation, database suites, download/unpack, packaging, hashing and compression; obtain an exclusive host window.',
    runnerSha256:sha(readFileSync(fileURLToPath(import.meta.url))),fixtureGeneratorSha256:FIXTURE_SHA,
    publicArchiveSha256:pinned.publicArchiveSha256,publicManifestSha256:BASE_MANIFEST_SHA,
    bindings:bindingTree(out)};
  immutable(resolve(out,'plan.json'),plan);
  console.log(JSON.stringify({prepared:true,publicCases:41,nonTargetControls:20,newSameSourceCases:fixtures.length-41,
    workers:fixtures.reduce((n,f)=>n+f.variants.length,0)*3,formalPerformanceMeasured:false}));
}
async function semantic(planPath,outArg){
  const {plan,base}=verifyInputs(planPath),out=resolve(outArg);mkdirSync(out,{recursive:false});
  const sdks={};for(const[name,v]of Object.entries(plan.variants))sdks[name]=await import(pathToFileURL(resolve(base,v.sdk)).href);
  const checks=[];
  for(const fixture of plan.fixtures){
    const f=load(resolve(base,fixture.path)),text=JSON.stringify(f.input),values={};
    for(const which of f.variants){
      const value=invoke(sdks[which],f,text);
      if(f.expectedStatus!==null)assert.equal(value.status,f.expectedStatus);
      const raw=Buffer.from(json(value)),packed=gzipSync(raw,{mtime:0});
      immutable(resolve(out,f.name+'-'+f.phase+'-'+which+'.json.gz'),packed);
      values[which]=comparable(value,f,plan.variants[which]);
    }
    for(const which of f.variants)assert.deepEqual(values[which],values[f.variants[0]],f.name+' '+f.phase+' complete SDK disagreement');
    checks.push({name:f.name,phase:f.phase,variants:f.variants,completeOutputAgreement:true});
  }
  const receipt={passed:true,kind:'complete-sdk-semantic-preflight',checks,caseCount:checks.length,
    planSha256:sha(readFileSync(planPath)),formalPerformanceMeasured:false,performanceImprovementClaimed:false};
  immutable(resolve(out,'receipt.json'),receipt);console.log(JSON.stringify({passed:true,caseCount:checks.length,formalPerformanceMeasured:false}));
}
async function worker(args){
  const [planPath,fixtureIndexText,which,outArg]=args;
  // The controller binds every prepared byte before and after the run. Do not
  // hash/read all other runtimes in a worker: that would contaminate cold/RSS.
  const plan=load(planPath),base=dirname(resolve(planPath));
  assert.equal(plan.format,'moontxnwitness-flat-sdk-performance-plan/v1');
  const f=load(resolve(base,plan.fixtures[Number(fixtureIndexText)].path)),text=JSON.stringify(f.input),v=plan.variants[which];
  const startLoad=performance.now(),sdk=await import(pathToFileURL(resolve(base,v.sdk)).href);
  const moduleImportMs=performance.now()-startLoad;assert.equal(sdk.version(),v.version);
  const startCold=performance.now();let output=invoke(sdk,f,text);const firstFullCallMs=performance.now()-startCold;
  const processAgeAtFirstResultMs=performance.now();
  for(let i=0;i<plan.warmups;i++)invoke(sdk,f,text);
  const timesMs=[];
  for(let i=0;i<plan.samples;i++){const start=performance.now();output=invoke(sdk,f,text);timesMs.push(performance.now()-start);}
  const peakRssKiB=process.resourceUsage().maxRSS;
  if(which==='flat')assert.deepEqual(sdk.experimentalFlatUsage(),{proofCountersEnabled:false,counts:[0,0,0,0,0,0]});
  if(f.expectedStatus!==null)assert.equal(output.status,f.expectedStatus);
  const raw=Buffer.from(json(output)),packed=gzipSync(raw,{mtime:0});immutable(resolve(outArg),packed);
  console.log(JSON.stringify({which,name:f.name,phase:f.phase,group:f.group,inputSha256:sha(text),moduleImportMs,firstFullCallMs,processAgeAtFirstResultMs,
    timesMs,medianMs:median(timesMs),p95Ms:p95(timesMs),peakRssKiB,
    fullOutput:{jsonBytes:raw.length,jsonSha256:sha(raw),gzipSha256:sha(packed),
      comparisonSha256:sha(json(comparable(output,f,v)))}}));
}
function measure(planPath,outArg,exclusive){
  assert.equal(exclusive,'--exclusive-host','A separately granted exclusive host window is required');
  const {plan,base}=verifyInputs(planPath),out=resolve(outArg);mkdirSync(out,{recursive:false});
  const rows=[],pairs=[],receipt={kind:'experimental-flat-complete-sdk-formal',formalPerformanceMeasured:true,
    defaultEnabled:false,completed:false,performanceAccepted:false,independentAcceptance:false,
    planSha256:sha(readFileSync(planPath)),node:process.version,nodeSha256:sha(readFileSync(process.execPath)),
    machine:{platform:platform(),release:release(),arch:arch(),cpus:cpus().map(c=>c.model)},rows,pairs};
  immutable(resolve(out,'started.json'),receipt);
  try{
    for(let batch=0;batch<plan.batches;batch++)for(let i=0;i<plan.fixtures.length;i++){
      const f=load(resolve(base,plan.fixtures[i].path)),pair={};
      const order=batch===0?f.variants:batch===1?[...f.variants.slice(1),f.variants[0]]:[f.variants.at(-1),...f.variants.slice(0,-1)];
      for(const which of order){
        const prefix='batch-'+(batch+1)+'-'+f.name+'-'+f.phase+'-'+which,output=resolve(out,prefix+'.output.json.gz');
        const child=spawnSync(process.execPath,[fileURLToPath(import.meta.url),'--worker',resolve(planPath),String(i),which,output],
          {encoding:'utf8',windowsHide:true,maxBuffer:4*1024*1024,timeout:300000});
        immutable(resolve(out,prefix+'.stdout.log'),child.stdout||'');immutable(resolve(out,prefix+'.stderr.log'),child.stderr||'');
        if(child.error)throw child.error;assert.equal(child.status,0,'Worker failed: '+prefix);
        const row=JSON.parse(child.stdout.trim()),packed=readFileSync(output);assert.equal(sha(packed),row.fullOutput.gzipSha256);
        const raw=gunzipSync(packed);assert.equal(sha(raw),row.fullOutput.jsonSha256);
        assert.equal(sha(json(comparable(JSON.parse(raw),f,plan.variants[which]))),row.fullOutput.comparisonSha256);
        pair[which]=row;rows.push({...row,batch:batch+1});immutable(resolve(out,prefix+'.samples.json'),rows.at(-1));
      }
      for(const baseline of f.variants.filter(v=>v!=='flat')){
        assert.equal(pair[baseline].fullOutput.comparisonSha256,pair.flat.fullOutput.comparisonSha256,'Complete output mismatch');
        pairs.push({batch:batch+1,name:f.name,phase:f.phase,group:f.group,baseline,completeOutputAgreement:true,
          medianSpeedup:pair[baseline].medianMs/pair.flat.medianMs,peakRssRatio:pair.flat.peakRssKiB/pair[baseline].peakRssKiB,
          baselineP95Ms:pair[baseline].p95Ms,candidateP95Ms:pair.flat.p95Ms,
          controlP95Passed:pair.flat.p95Ms-pair[baseline].p95Ms<=Math.max(2,pair[baseline].p95Ms*.1)});
      }
    }
    verifyInputs(planPath);
    receipt.groups={};for(const baseline of ['public020','legacy'])for(const group of new Set(pairs.map(p=>p.group))){
      const selected=pairs.filter(p=>p.baseline===baseline&&p.group===group);if(!selected.length)continue;
      receipt.groups[baseline+'/'+group]={comparisons:selected.length,medianSpeedupGeomean:geomean(selected.map(p=>p.medianSpeedup)),
        peakRssRatioGeomean:geomean(selected.map(p=>p.peakRssRatio)),controlFailures:selected.filter(p=>!p.controlP95Passed)};
    }
    receipt.completed=true;receipt.correctnessPassed=true;receipt.nonTargetControlsPassed=pairs.every(p=>p.controlP95Passed);
    receipt.originalGraphTargetSuiteCompleted=false;
    receipt.performanceAccepted=false;receipt.reason='Full SDK measurement alone does not replace the original fixed graph target suite or independent acceptance';
    immutable(resolve(out,'receipt.json'),receipt);console.log(JSON.stringify({completed:true,nonTargetControlsPassed:receipt.nonTargetControlsPassed,performanceAccepted:false}));
  }catch(error){receipt.failure={name:error.name,message:error.message};immutable(resolve(out,'receipt.json'),receipt);throw error;}
}
const [mode,...args]=process.argv.slice(2);
if(mode==='--prepare')prepare(args);
else if(mode==='--semantic')await semantic(...args);
else if(mode==='--worker')await worker(args);
else if(mode==='--run')measure(...args);
else throw Error('Use --prepare, --semantic or --run PLAN NEW_OUTPUT --exclusive-host. Preparation never runs measurements.');
