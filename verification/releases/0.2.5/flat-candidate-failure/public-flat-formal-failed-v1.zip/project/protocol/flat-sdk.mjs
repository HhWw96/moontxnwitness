// Generated experimental full-SDK selection; no stable capsule creation exports.
export {version,analyze,analyzeWithOptions,shrink,shrinkWithOptions,compareModels,normalizeCapture,normalizePresenceCapture,normalizeCaptureV3,analyzeV3,reduceV3,normalizeListCaptureV3,analyzeListV3,reduceListV3,normalizeRelationCaptureV3,analyzeRelationV3,reduceRelationV3,inspectDislockCaptureV3,inspectExecutionFailuresV3,inspectOrmSourceV3,analyzeOrmProfileV3,reduceOrmProfileV3,analyzeModelProfileV3,classifyV3,reduceClassificationV3,classifyModelsV3,explainRegisterCycleV3} from './flat/dist/sdk.mjs';
import {experimental_flat_usage_json} from './flat/dist/core.mjs';
export const experimentalFlatUsage=()=>JSON.parse(experimental_flat_usage_json());
export const experimentalSelection=Object.freeze({id:'flat-sdk-layout-experiment-1',experimental:true,defaultEnabled:false,proofCountersEnabled:false,stableCapsuleCreationSupported:false,legacyReplayUsesOriginalRuntime:true});
