// Read-only independent output/hash audit. Never imports or executes an SDK.
import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {resolve,dirname} from 'node:path';
import {createHash} from 'node:crypto';
import {gunzipSync} from 'node:zlib';
const [sourceArg,planArg,outArg]=process.argv.slice(2);
const source=resolve(sourceArg),planPath=resolve(planArg),base=dirname(planPath),audit=resolve(outArg);
const sha=raw=>createHash('sha256').update(raw).digest('hex');
const json=x=>JSON.stringify(x,null,2)+'\n';
const planRaw=readFileSync(planPath),plan=JSON.parse(planRaw),receiptRaw=readFileSync(resolve(source,'receipt.json')),receipt=JSON.parse(receiptRaw);
assert.equal(sha(planRaw),'3ea0edfed7dd98585a81c314c26800f1a2c5a0ad6c1282e3580e976dc7125fe4');
assert.equal(receipt.planSha256,sha(planRaw));
const prepared=[];
for(const[name,expected]of Object.entries(plan.bindings)){
 const raw=readFileSync(resolve(base,name));assert.equal(sha(raw),expected,'Prepared byte mismatch: '+name);
 prepared.push({path:name,bytes:raw.length,sha256:expected});
}
const projectRoot=dirname(base),runner=readFileSync(resolve(projectRoot,'scripts/performance-flat-sdk.mjs'));
assert.equal(sha(runner),plan.runnerSha256);
assert.equal(sha(readFileSync(resolve(projectRoot,'experiments/graph_flat_candidate/performance-v020-fixtures.mjs'))),plan.fixtureGeneratorSha256);
assert.equal(sha(readFileSync(process.execPath)),receipt.nodeSha256);assert.equal(process.version,receipt.node);
const fixtureMap=new Map();
for(const info of plan.fixtures){const fixture=JSON.parse(readFileSync(resolve(base,info.path)));fixtureMap.set(info.name+'|'+info.phase,fixture);}
function independentProjection(value,f,variant){
 if(f.phase==='normalize')return value;
 if(f.method){
  assert.equal(value.engine.version,variant.version);assert.equal(value.engine.coreSha256,variant.coreSha256);
  assert.equal(value.engine.hostSha256,variant.hostSha256[f.method]);assert.equal(value.result.version,variant.version);
  value.engine.version='<validated-engine-version>';value.engine.coreSha256='<validated-actual-core-sha256>';value.result.version='<validated-engine-version>';
  return value;
 }
 if(f.phase==='legacy-reduce'){assert.equal(value.version,variant.version);value.version='<validated-engine-version>';}
 const analysis=['reduce','legacy-reduce'].includes(f.phase)?value.report:value;
 assert.equal(analysis.version,variant.version);analysis.version='<validated-engine-version>';
 if(['analyze','reduce'].includes(f.phase)&&analysis.evidence?.tool==='MoonTxnWitness'&&analysis.evidence.schemaVersion===2){
  assert.equal(analysis.evidence.version,variant.version);analysis.evidence.version='<validated-engine-version>';
 }
 return value;
}
const outputBindings=[],allCases=new Map();let bytes=0,headerChecked=0;
for(const row of receipt.rows){
 const f=fixtureMap.get(row.name+'|'+row.phase);assert.ok(f);const variant=plan.variants[row.which];
 assert.equal(sha(JSON.stringify(f.input)),row.inputSha256);
 const prefix='batch-'+row.batch+'-'+row.name+'-'+row.phase+'-'+row.which;
 const packed=readFileSync(resolve(source,prefix+'.output.json.gz'));assert.equal(sha(packed),row.fullOutput.gzipSha256);
 const raw=gunzipSync(packed,{maxOutputLength:32*1024*1024});assert.equal(raw.length,row.fullOutput.jsonBytes);assert.equal(sha(raw),row.fullOutput.jsonSha256);
 const value=JSON.parse(raw);assert.deepEqual(Buffer.from(json(value)),raw,'Noncanonical raw output');
 if(f.expectedStatus!==null)assert.equal(value.status,f.expectedStatus);
 const projected=independentProjection(value,f,variant),comparison=sha(json(projected));assert.equal(comparison,row.fullOutput.comparisonSha256);
 if(f.method)headerChecked++;
 const key=row.name+'|'+row.phase,previous=allCases.get(key);
 if(previous)assert.equal(comparison,previous,'Whole-output difference across batch or variant');else allCases.set(key,comparison);
 bytes+=raw.length;outputBindings.push({file:prefix+'.output.json.gz',gzipSha256:sha(packed),jsonBytes:raw.length,jsonSha256:sha(raw),independentComparisonSha256:comparison});
}
assert.equal(outputBindings.length,519);assert.equal(allCases.size,66);
const result={kind:'independent-flat-sdk-all-original-outputs',passed:true,workers:519,cases:66,
 actualUncompressedBytesChecked:bytes,allGzipAndRawSha256Matched:true,allInputJsonSha256Matched:true,
 allFullOutputComparisonsMatchedAcrossBatchesAndVariants:true,newCategoryAndModelActualHeaderOutputsChecked:headerChecked,
 comparisonRule:'Only explicit validated report header version fields and actual engine.coreSha256 are projected to protocol sentinels. Host hashes, business values, source facts, evidence, budgets, counters and entire other output remain exact.',
 preparedBindingsVerified:prepared.length,runnerSha256:sha(runner),planSha256:sha(planRaw),node:process.version,nodeSha256:sha(readFileSync(process.execPath)),
 sourceReceiptSha256:sha(receiptRaw),sdkInvoked:false,newMeasurementExecuted:false,proofOfEveryTimedOutput:false,
 limitation:'One complete final output is archived per worker, not one for every timed invocation. All 519 archived outputs were verified; the 15570 timing samples are separately recomputed.',preparedBindings:prepared,outputBindings};
writeFileSync(resolve(audit,'verified-outputs.json'),json(result),{flag:'wx'});
console.log(JSON.stringify({...result,preparedBindings:undefined,outputBindings:undefined}));
