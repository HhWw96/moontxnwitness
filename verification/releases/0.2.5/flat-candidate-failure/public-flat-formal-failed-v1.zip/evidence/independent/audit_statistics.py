"""Recompute frozen SDK performance evidence; never invokes an SDK or timer."""
from pathlib import Path
import csv, hashlib, json, math, sys, collections

source=Path(sys.argv[1]);plan_path=Path(sys.argv[2]);out=Path(sys.argv[3])
sha=lambda raw:hashlib.sha256(raw).hexdigest()
load=lambda p:json.loads(p.read_bytes())
receipt=load(source/'receipt.json');plan=load(plan_path)
assert receipt['planSha256']==sha(plan_path.read_bytes())=='3ea0edfed7dd98585a81c314c26800f1a2c5a0ad6c1282e3580e976dc7125fe4'
assert plan['warmups']==5 and plan['samples']==30 and plan['batches']==3
assert receipt['completed'] is True and receipt['performanceAccepted'] is False and receipt['defaultEnabled'] is False
expected_order=[];fixture_meta={}
for f in plan['fixtures']:
    fixture_meta[(f['name'],f['phase'])]=f
for batch in range(1,4):
    for f in plan['fixtures']:
        v=f['variants'];order=v if batch==1 else v[1:]+v[:1] if batch==2 else v[-1:]+v[:-1]
        expected_order += [(batch,f['name'],f['phase'],variant) for variant in order]
assert len(expected_order)==519
rows=receipt['rows'];assert len(rows)==519
assert [(r['batch'],r['name'],r['phase'],r['which']) for r in rows]==expected_order
by={};sample_records=[]
def near(a,b):
    assert math.isfinite(a) and math.isfinite(b) and math.isclose(a,b,rel_tol=1e-11,abs_tol=1e-11),(a,b)
for row in rows:
    key=(row['batch'],row['name'],row['phase'],row['which']);assert key not in by;by[key]=row
    batch,name,phase,variant=key;prefix=f'batch-{batch}-{name}-{phase}-{variant}'
    sample=load(source/(prefix+'.samples.json'));assert sample==row
    stdout=load(source/(prefix+'.stdout.log'));assert stdout=={k:v for k,v in row.items() if k!='batch'}
    assert (source/(prefix+'.stderr.log')).read_bytes()==b''
    values=row['timesMs'];assert len(values)==30 and all(type(v) in (int,float) and math.isfinite(v) and v>0 for v in values)
    sorted_values=sorted(values);median=sorted_values[len(values)//2];p95=sorted_values[math.ceil(len(values)*.95)-1]
    near(row['medianMs'],median);near(row['p95Ms'],p95)
    assert type(row['peakRssKiB']) is int and row['peakRssKiB']>0
    for field in ['moduleImportMs','firstFullCallMs','processAgeAtFirstResultMs']:
        assert type(row[field]) in (int,float) and math.isfinite(row[field]) and row[field]>=0
    assert row['group']==fixture_meta[(name,phase)]['group']
    sample_records.append({'batch':batch,'name':name,'phase':phase,'variant':variant,'group':row['group'],'samples':30,'medianMs':median,'p95Ms':p95,'peakRssKiB':row['peakRssKiB'],'moduleImportMs':row['moduleImportMs'],'firstFullCallMs':row['firstFullCallMs'],'outputBytes':row['fullOutput']['jsonBytes']})
pairs=[]
for batch in range(1,4):
    for f in plan['fixtures']:
        c=by[(batch,f['name'],f['phase'],'flat')]
        for baseline in [v for v in f['variants'] if v!='flat']:
            b=by[(batch,f['name'],f['phase'],baseline)]
            allowed=max(2,b['p95Ms']*.1)
            pairs.append({'batch':batch,'name':f['name'],'phase':f['phase'],'group':f['group'],'baseline':baseline,'completeOutputAgreement':b['fullOutput']['comparisonSha256']==c['fullOutput']['comparisonSha256'],'medianSpeedup':b['medianMs']/c['medianMs'],'peakRssRatio':c['peakRssKiB']/b['peakRssKiB'],'baselineP95Ms':b['p95Ms'],'candidateP95Ms':c['p95Ms'],'controlP95Passed':c['p95Ms']-b['p95Ms']<=allowed,'allowedP95IncreaseMs':allowed,'actualP95IncreaseMs':c['p95Ms']-b['p95Ms'],'thresholdExcessMs':c['p95Ms']-b['p95Ms']-allowed,'p95Ratio':c['p95Ms']/b['p95Ms']})
assert len(pairs)==321
for expected,actual in zip(receipt['pairs'],pairs):
    for k,v in expected.items():
        if type(v) is float:near(v,actual[k])
        else:assert v==actual[k],(k,v,actual[k])
def gm(items):return math.exp(math.fsum(math.log(x) for x in items)/len(items))
groups={}
for baseline in ['public020','legacy']:
    for group in dict.fromkeys(f['group'] for f in plan['fixtures']):
        selected=[p for p in pairs if p['baseline']==baseline and p['group']==group]
        if not selected:continue
        key=baseline+'/'+group
        value={'comparisons':len(selected),'medianSpeedupGeomean':gm([p['medianSpeedup'] for p in selected]),'peakRssRatioGeomean':gm([p['peakRssRatio'] for p in selected]),'p95Failures':len([p for p in selected if not p['controlP95Passed']])}
        original=receipt['groups'][key]
        assert original['comparisons']==value['comparisons'] and len(original['controlFailures'])==value['p95Failures']
        near(original['medianSpeedupGeomean'],value['medianSpeedupGeomean']);near(original['peakRssRatioGeomean'],value['peakRssRatioGeomean'])
        groups[key]=value
assert len(groups)==len(receipt['groups'])
controls=[p for p in pairs if p['group']=='control'];failed_controls=[p for p in controls if not p['controlP95Passed']]
all_failures=[p for p in pairs if not p['controlP95Passed']]
assert len(controls)==120
assert receipt['nonTargetControlsPassed']==all(p['controlP95Passed'] for p in pairs)
subsets={}
for baseline in ['public020','legacy']:
    definitions={'all-existing-20-controls':lambda p:p['group']=='control','common-41-all':lambda p:p['group'] in ['normalization','full-v3','reduction-v3','control'],'existing-v3-21':lambda p:p['group'] in ['normalization','full-v3','reduction-v3'],'seven-graph-controls-descriptive':lambda p:p['group']=='control' and any(t in p['name'] for t in ['dense-rt','sparse-','long-ring','small-cycle-noise']),'search-9-to-12-controls-descriptive':lambda p:p['name'] in ['legacy-completion-impossible-'+str(n) for n in range(9,13)],'reduction-512-control-descriptive':lambda p:p['name']=='legacy-reduction-512'}
    for name,predicate in definitions.items():
        selected=[p for p in pairs if p['baseline']==baseline and predicate(p)]
        if selected:subsets[baseline+'/'+name]={'comparisons':len(selected),'medianSpeedupGeomean':gm([p['medianSpeedup'] for p in selected]),'peakRssRatioGeomean':gm([p['peakRssRatio'] for p in selected]),'p95Failures':sum(not p['controlP95Passed'] for p in selected)}
case_aggregates=[]
for key in sorted(set((p['baseline'],p['name'],p['phase'],p['group']) for p in pairs)):
    selected=[p for p in pairs if (p['baseline'],p['name'],p['phase'],p['group'])==key]
    case_aggregates.append({'baseline':key[0],'name':key[1],'phase':key[2],'group':key[3],'batches':len(selected),'medianSpeedupGeomean':gm([p['medianSpeedup'] for p in selected]),'peakRssRatioGeomean':gm([p['peakRssRatio'] for p in selected]),'p95Failures':sum(not p['controlP95Passed'] for p in selected),'worstP95Ratio':max(p['p95Ratio'] for p in selected),'worstThresholdExcessMs':max(p['thresholdExcessMs'] for p in selected)})
def save_csv(name,values):
    with (out/name).open('w',newline='',encoding='utf8') as f:
        w=csv.DictWriter(f,fieldnames=list(values[0]));w.writeheader();w.writerows(values)
save_csv('all-519-recomputed-samples.csv',sample_records);save_csv('all-321-recomputed-pairs.csv',pairs);save_csv('actual-control-p95-failures.csv',failed_controls);save_csv('all-groups-p95-failures.csv',all_failures);save_csv('case-three-batch-aggregates.csv',case_aggregates)
original_files=[]
for path in sorted(source.iterdir()):
    assert path.is_file() and not path.is_symlink()
    raw=path.read_bytes();original_files.append({'file':path.name,'bytes':len(raw),'sha256':sha(raw)})
assert len(original_files)==2078
result={'kind':'independent-flat-sdk-formal-statistics','sourceReceiptSha256':sha((source/'receipt.json').read_bytes()),'planSha256':sha(plan_path.read_bytes()),'workers':519,'samplesPerWorker':30,'actualSamplesChecked':519*30,'sampleFilesAndWorkerStdoutExactlyMatchReceipt':True,'stderrFilesAllEmpty':True,'workerOrderExactlyMatchesFrozenProtocol':True,'allRecomputedRowsPairsGroupsMatchOriginal':True,'medianConvention':'Protocol upper middle: sorted[15] for 30 samples, not average of the two middle observations.','p95Convention':'Nearest rank ceil(0.95*n)-1: sorted[28] for 30 samples.','groups':groups,'descriptiveSubsets':subsets,'actualNonTargetControls':{'comparisons':len(controls),'failedComparisons':len(failed_controls),'failedUniqueCases':len(set((p['baseline'],p['name'],p['phase']) for p in failed_controls)),'passed':not failed_controls},'allPairsP95':{'comparisons':len(pairs),'failures':len(all_failures),'passed':not all_failures},'originalFlagNaming':'The original nonTargetControlsPassed is pairs.every(), covering all target and control pairs. The explicit group=control subset also fails; no acceptance outcome changes.','originalGraphTargetSuiteCompleted':receipt['originalGraphTargetSuiteCompleted'],'performanceAccepted':False,'defaultEnabled':False,'sameImplementationRerun':False,'newMeasurementExecuted':False,'rawFiles':original_files}
(out/'recomputed-statistics.json').write_bytes((json.dumps(result,indent=2)+'\n').encode())
print(json.dumps({k:v for k,v in result.items() if k not in ['rawFiles','groups','descriptiveSubsets']},indent=2))
print(json.dumps({'groups':groups,'subsets':subsets,'largestControlExcesses':sorted(failed_controls,key=lambda p:-p['thresholdExcessMs'])[:6]},indent=2))
