from pathlib import Path
import runpy,sys,types
root=Path(__file__).resolve().parent/'source'
# A same-named ambient module must never satisfy either isolated sibling import.
for name in ['_durable_policy','_experimental_budget']:
    poison=types.ModuleType(name)
    def forbidden(attr, name=name):raise AssertionError('ambient dependency accessed: '+name+'.'+attr)
    poison.__getattr__=forbidden;sys.modules[name]=poison
sys.argv=['scripts/v3-independent-oracle.py','--journal-audit','--scratch',str(root/'scratch')]
runpy.run_path(str(root/'scripts/v3-independent-oracle.py'),run_name='__main__')
