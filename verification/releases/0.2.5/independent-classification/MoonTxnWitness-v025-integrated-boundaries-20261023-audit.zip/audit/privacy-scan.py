from pathlib import Path
import re,json,hashlib
root=Path(__file__).resolve().parent
home=str(Path.home());needles=[v.encode('utf-8')for v in {home,home.replace('\\','/'),home.replace('\\','\\\\')}if v]
patterns=[('github-token',re.compile(rb'gh[pousr]_[A-Za-z0-9]{20,}')),('private-key',re.compile(rb'-----BEGIN [A-Z ]*PRIVATE'+rb' KEY-----'))]
findings=[];count=0;total=0
for p in sorted(root.rglob('*')):
    if not p.is_file()or p.name in ['privacy-scan.json','audit-files.json']:continue
    name=p.relative_to(root).as_posix();b=p.read_bytes();count+=1;total+=len(b)
    if p.name in ['credentials.json','.local-toolchain.json']:findings.append({'file':name,'kind':'private configuration selected'})
    if any(v in b for v in needles):findings.append({'file':name,'kind':'private home path'})
    for label,pattern in patterns:
        if pattern.search(b):findings.append({'file':name,'kind':label})
receipt={'format':'independent-audit-privacy-scan/v1','passed':not findings,'filesChecked':count,'bytesChecked':total,'findings':findings,'scope':'All raw selected files: publisher home path variants, GitHub token syntax, private-key markers, selected credential configuration filenames. Not an exhaustive secret detector.'}
(root/'privacy-scan.json').write_bytes((json.dumps(receipt,indent=2)+'\n').encode());print(json.dumps(receipt));raise SystemExit(0 if receipt['passed']else 1)
