// Independent semantic boundary checks over sealed compiled runtime; no timings.
import assert from 'node:assert/strict';
import {mkdirSync,writeFileSync,readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import * as sdk from './runtime/sdk.mjs';
import {graphTrace,withoutTransaction,hasCategory} from './input-constructor.mjs';
const out=new URL('./remaining-first/',import.meta.url);mkdirSync(out);
const sha=x=>createHash('sha256').update(x).digest('hex');
const saved=(name,value)=>writeFileSync(new URL(name,out),typeof value==='string'?value:JSON.stringify(value,null,2)+'\n',{flag:'wx'});
const cases=[];const test=(name,fn)=>{try{fn();cases.push({name,passed:true});}catch(error){cases.push({name,passed:false,error:error.stack});}};
let calls=0,oracleHistories=0,oracleCategoryComparisons=0;const corpus=[];
function classify(name,trace,options={}){
 const source=typeof trace==='string'?trace:JSON.stringify(trace),report=sdk.classifyV3(source,options);calls++;
 saved(name+'.input.json',source);saved(name+'.options.json',options);saved(name+'.report.json',report);
 corpus.push({name,inputSha256:sha(source),options,reportSha256:sha(JSON.stringify(report)),status:report.status});return report;
}
const kinds={G0:'ww',G1c:'wr','G2-item':'rw'};
for(const category of Object.keys(kinds)){
 const trace=graphTrace(['A','B'],[['A','B',kinds[category]],['B','A',kinds[category]]]);
 const full=classify('budget-'+category+'-full',trace,{categories:[category]});
 test(category+' baseline has a reliable category witness',()=>{assert.equal(full.status,'refuted');assert.equal(full.result.normalized.coverage.complete,true);});
 for(const[field,countField,limit]of [['maxStates','states',100000],['maxEdgeChecks','edgeChecks',1000000]]){
  const used=full.result.rules[category][countField];assert.ok(used>0&&used<limit);
  for(const delta of [-1,0,1]){
   const budget=used+delta,report=classify('budget-'+category+'-'+field+'-'+(delta+1),trace,{categories:[category],[field]:budget}),rule=report.result.rules[category];
   test(category+' '+field+' exact boundary '+delta,()=>{
    assert.ok(rule[countField]<=budget);assert.equal(report.result.normalized.coverage.complete,true);
    assert.equal(rule.status,delta<0?'unknown':'refuted');assert.equal(report.status,delta<0?'inconclusive':'refuted');
   });
  }
 }
}
const acyclic=graphTrace(['A','B','C'],[['A','B','rw'],['A','B','rw'],['B','C','rw']]);
const exhausted=classify('acyclic-full',acyclic,{categories:['G2-item']});
for(const[field,countField]of [['maxStates','states'],['maxEdgeChecks','edgeChecks']]){
 const used=exhausted.result.rules['G2-item'][countField];
 for(const delta of [-1,0,1]){
  const report=classify('acyclic-'+field+'-'+(delta+1),acyclic,{categories:['G2-item'],[field]:used+delta});
  test('acyclic '+field+' exact boundary '+delta,()=>{assert.equal(report.result.rules['G2-item'].status,delta<0?'unknown':'checked-compatible');assert.ok(report.result.rules['G2-item'][countField]<=used+delta);});
 }
}
const empty=classify('empty-zero',graphTrace(['A','B'],[]),{maxStates:0,maxEdgeChecks:0});
test('empty graph needs no search budget',()=>assert.equal(empty.status,'checked-compatible'));
const irrelevant=classify('no-eligible-seed-zero-state',acyclic,{categories:['G0'],maxStates:0,maxEdgeChecks:3});
test('no allowed seed needs edge scan but zero states',()=>{assert.equal(irrelevant.status,'checked-compatible');assert.equal(irrelevant.result.rules.G0.states,0);assert.equal(irrelevant.result.rules.G0.edgeChecks,3);});
const maskEdges=[['A','B','ww'],['A','B','ww'],['B','A','ww'],['C','D','ww'],['D','E','wr'],['E','C','rw']];
const maskedTrace=graphTrace(['A','B','C','D','E'],maskEdges),masked=classify('category-mask',maskedTrace);
const legacy=sdk.analyzeWithOptions(masked.result.normalized.history);saved('category-mask.legacy-global-report.json',legacy);
test('short global G0 cycle does not mask longer G2 category',()=>{
 assert.equal(masked.result.rules.G0.status,'refuted');assert.equal(masked.result.rules.G1c.status,'refuted');assert.equal(masked.result.rules['G2-item'].status,'refuted');
 assert.equal(legacy.witness.edges.length,2);assert.ok(legacy.witness.edges.every(edge=>edge.kind==='ww'));
 assert.equal(masked.result.rules['G2-item'].evidence.edges.length,3);assert.ok(masked.result.rules['G2-item'].evidence.edges.some(item=>item.edge.kind==='rw'));
 assert.equal(masked.result.dependencies.length,maskEdges.length);
});
const pure=classify('independent-G1c-pure-WW',graphTrace(['A','B'],[['A','B','ww'],['B','A','ww']]),{categories:['G1c']});
test('G1c-only WW proof keeps specific G0 and implication closure',()=>{assert.equal(pure.result.rules.G1c.evidence.specificCategory,'G0');assert.deepEqual(pure.result.impliedAnomalies,['G0','G1c','G1']);});
const vertices=['A','B'],proofEdges=[['A','B','rw'],['B','A','rw']];
for(let i=0;i<6;i++){vertices.push('N'+i,'O'+i);proofEdges.push(['N'+i,'O'+i,'rw']);}
const proofTrace=graphTrace(vertices,proofEdges);
for(const[ordinal,categories]of [['last',['G0','G1c','G2-item']],['first',['G2-item','G0','G1c']]]){
 const report=classify('reliable-proof-'+ordinal,proofTrace,{categories,maxEdgeChecks:2});
 test('reliable proof '+ordinal+' wins over other category budgets',()=>{
  assert.equal(report.status,'refuted');assert.equal(report.result.rules['G2-item'].status,'refuted');
  assert.equal(report.result.rules.G0.status,'unknown');assert.equal(report.result.rules.G1c.status,'unknown');
  assert.equal(report.result.rules.G0.edgeChecks,2);assert.equal(report.result.rules.G1c.edgeChecks,2);
 });
}
const pairs=[['A','B'],['A','C'],['B','A'],['B','C'],['C','A'],['C','B']];
const palettes=[Array(6).fill('ww'),Array(6).fill('rw'),['ww','wr','rw','wr','rw','ww']];
for(let palette=0;palette<palettes.length;palette++)for(let mask=0;mask<64;mask++){
 const edges=pairs.flatMap(([u,v],i)=>(mask&(1<<i))?[[u,v,palettes[palette][i]]]:[]);
 const report=classify('oracle-'+palette+'-'+mask,graphTrace(['A','B','C'],edges));oracleHistories++;
 test('independent DFS palette '+palette+' mask '+mask,()=>{
  assert.equal(report.result.normalized.coverage.complete,true);assert.equal(report.result.dependencies.length,edges.length);
  const actual=report.result.dependencies.map(edge=>edge.from+'|'+edge.to+'|'+edge.kind+'|'+edge.key).sort();
  const expected=edges.map(([u,v,kind],i)=>u+'|'+v+'|'+kind+'|k'+i).sort();assert.deepEqual(actual,expected);
  for(const category of ['G0','G1c','G2-item']){
   const expectedCycle=hasCategory(['A','B','C'],edges,category);oracleCategoryComparisons++;
   assert.equal(report.result.rules[category].status,expectedCycle?'refuted':'checked-compatible');
  }
 });
}
saved('corpus-manifest.json',corpus);
const result={kind:'independent-frozen-v025-remaining-boundaries',passed:cases.every(x=>x.passed),checks:cases.length,cases,
 actualSdkClassifyCalls:calls,actualLegacyAnalyzeCalls:1,independentDfsHistories:oracleHistories,independentCategoryComparisons:oracleCategoryComparisons,
 runtimeVersion:sdk.version(),coreSha256:sha(readFileSync(new URL('./runtime/core.mjs',import.meta.url))),hostSha256:sha(readFileSync(new URL('./runtime/classification.mjs',import.meta.url))),
 originalRuntimeAndProductionExpectationsModified:false,actualDatabaseExecution:false,formalPerformanceMeasured:false,
 scope:'Original sealed 89a candidate runtime only; actual stable-v025 integration and public-v024 capsules are separate checks.'};
saved('receipt.json',result);console.log(JSON.stringify({...result,cases:undefined}));if(!result.passed)process.exitCode=1;
