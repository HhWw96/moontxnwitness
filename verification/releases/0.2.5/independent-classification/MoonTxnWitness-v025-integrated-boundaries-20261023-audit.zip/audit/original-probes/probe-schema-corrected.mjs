import {writeFileSync,mkdirSync} from 'node:fs';
import * as sdk from './runtime/sdk.mjs';
import {graphTrace,withoutTransaction} from './input-constructor.mjs';
mkdirSync(new URL('./probe-schema-corrected/',import.meta.url));
const edges=[['A','B','rw'],['B','C','rw'],['C','A','rw'],...Array.from({length:7},()=>['A','B','rw'])];
const trace=graphTrace(['A','B','C'],edges),report=sdk.classifyV3(trace,{categories:['G2-item']});
writeFileSync(new URL('./probe-schema-corrected/input.json',import.meta.url),JSON.stringify(trace,null,2)+'\n');
writeFileSync(new URL('./probe-schema-corrected/report.json',import.meta.url),JSON.stringify(report,null,2)+'\n');
const rule=report.result.rules['G2-item'];const options={category:'G2-item',classificationOptions:{categories:['G2-item'],maxEdgeChecks:rule.edgeChecks}};
const reduction=sdk.reduceClassificationV3(trace,options);
writeFileSync(new URL('./probe-schema-corrected/reduction.json',import.meta.url),JSON.stringify(reduction,null,2)+'\n');
const singles={};for(const id of ['A','B','C']){const x=sdk.classifyV3(withoutTransaction(trace,id),options.classificationOptions);singles[id]={status:x.status,coverage:x.result.normalized?.coverage,rule:x.result.rules?.['G2-item']};}
console.log(JSON.stringify({version:sdk.version(),status:report.status,coverage:report.result.normalized.coverage,dependencies:report.result.dependencies.map(x=>({from:x.from,to:x.to,kind:x.kind})),rule,reduction:{status:reduction.status,checks:reduction.result.checks,oneMinimal:reduction.result.oneMinimal,removed:reduction.result.removed},singles}));
