from pathlib import Path
import json,subprocess,hashlib,datetime
root=Path(__file__).resolve().parent
runs=[]
for script in ['probe-schema-corrected.mjs','remaining-boundaries.mjs']:
    result=subprocess.run(['D:/nodejs/node.exe',script],cwd=root,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=120,check=False)
    stem=script.removesuffix('.mjs');(root/(stem+'.first.stdout')).write_bytes(result.stdout);(root/(stem+'.first.stderr')).write_bytes(result.stderr)
    runs.append({'script':script,'scriptSha256':hashlib.sha256((root/script).read_bytes()).hexdigest(),'exitCode':result.returncode,'stdout':stem+'.first.stdout','stderr':stem+'.first.stderr','stdoutSha256':hashlib.sha256(result.stdout).hexdigest(),'stderrSha256':hashlib.sha256(result.stderr).hexdigest()})
receipt={'format':'independent-integrated-v025-first-execution/v1','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'runs':runs,'passed':all(x['exitCode']==0 for x in runs),'formalPerformanceMeasured':False,'databaseExecuted':False,'moonCompilation':False}
(root/'first-execution.json').write_bytes((json.dumps(receipt,indent=2)+'\n').encode())
print(json.dumps(receipt))
raise SystemExit(0 if receipt['passed']else 1)
