from pathlib import Path
import argparse,json,hashlib
parser=argparse.ArgumentParser();parser.add_argument('--root',type=Path,default=Path(__file__).resolve().parent);args=parser.parse_args();root=args.root
sha=lambda b:hashlib.sha256(b).hexdigest()
x=json.loads((root/'probe-schema-corrected.first.stdout').read_bytes());reduction=json.loads((root/'probe-schema-corrected/reduction.json').read_bytes());report=json.loads((root/'probe-schema-corrected/report.json').read_bytes());trace=json.loads((root/'probe-schema-corrected/input.json').read_bytes())
manifest=json.loads((root/'runtime-manifest.json').read_bytes());engine=manifest['sourceBuildManifest']['version'];used=x['rule']['edgeChecks']
checks={
'original-source-complete':x['status']=='refuted' and x['coverage']['complete']is True,
'original-three-edge-proof':len(x['rule']['evidence']['edges'])==3,
'all-ten-parallel-and-cycle-edges-preserved':len(x['dependencies'])==10,
'candidate-A-complete-compatible':x['singles']['A']['status']=='checked-compatible' and x['singles']['A']['coverage']['complete']is True,
'candidate-B-complete-compatible':x['singles']['B']['status']=='checked-compatible' and x['singles']['B']['coverage']['complete']is True,
'candidate-C-complete-unknown':x['singles']['C']['status']=='inconclusive' and x['singles']['C']['rule']['status']=='unknown' and x['singles']['C']['coverage']['complete']is True,
'candidate-C-exact-budget-visible':x['singles']['C']['rule']['edgeChecks']==used and x['singles']['C']['rule']['reason']=='edge-check-budget',
'unknown-does-not-establish-minimality':reduction['status']=='inconclusive' and reduction['result']['oneMinimal']is False,
'all-three-single-deletions-checked':reduction['result']['checks']==3 and reduction['result']['removed']==[],
'host-source-and-final-replay-complete':reduction['sourceClosure']['complete']is True and reduction['finalReplay']['valid']is True,
'final-fixed-category-still-refuted':reduction['result']['report']['rules']['G2-item']['status']=='refuted' and reduction['result']['category']=='G2-item',
'original-business-version-not-retagged':trace['events'][0]['initial']['business']=='0.2.4' and report['result']['normalized']['history']['initial']['business']=='0.2.4',
'actual-engine-preserved':x['version']==engine=='0.2.5' and report['engine']['version']==engine and reduction['engine']['version']==engine}
assert len(checks)==13 and all(checks.values()),checks
raw=json.loads((root/'remaining-first/receipt.json').read_bytes());assert raw['passed'] and raw['checks']==225 and all(c['passed']for c in raw['cases'])
assert raw['runtimeVersion']==engine and raw['coreSha256']==manifest['sourceBuildManifest']['coreSha256']
corpus=json.loads((root/'remaining-first/corpus-manifest.json').read_bytes());old={e['name']:e for e in json.loads((root/'original-probes/corpus-manifest.json').read_bytes())}
assert len(corpus)==226
for e in corpus:
    assert e['inputSha256']==old[e['name']]['inputSha256'] and e['options']==old[e['name']]['options']
    assert sha((root/'remaining-first'/(e['name']+'.input.json')).read_bytes())==e['inputSha256']
for e in manifest['files']:
    b=(root/e['path']).read_bytes();assert len(b)==e['bytes'] and sha(b)==e['sha256']
original=(root/'original-probes/remaining-boundaries.mjs').read_bytes()
expected=original.replace(b"kind:'independent-frozen-v025-remaining-boundaries'",b"kind:'independent-integrated-v025-remaining-boundaries'").replace(b"Original sealed 89a candidate runtime only; actual stable-v025 integration and public-v024 capsules are separate checks.",b"Current root dist v0.2.5 classification runtime only; whole-release installation and public-v024 compatibility are separate checks.")
assert expected==(root/'remaining-boundaries.mjs').read_bytes()
assert (root/'probe-schema-corrected.mjs').read_bytes()==(root/'original-probes/probe-schema-corrected.mjs').read_bytes()
assert (root/'input-constructor.mjs').read_bytes()==(root/'original-probes/input-constructor.mjs').read_bytes()
result={'format':'independent-current-v025-observation-checks/v1','passed':True,'checkpointOutputChecks':checks,'remainingNamedChecks':225,'identicalOriginalInputAndOptions':226,'actualEngineVersion':engine,'currentCoreSha256':raw['coreSha256'],'currentClassificationHostSha256':raw['hostSha256'],'expectationsChanged':False,'runtimeModified':False,'mockedCore':False,'moonCompilation':False,'newDatabaseExecution':False,'formalPerformanceMeasurement':False}
(root/'observation-verification.json').write_bytes((json.dumps(result,indent=2)+'\n').encode());print(json.dumps(result))
