import assert from 'node:assert/strict';

export function graphTrace(vertices, edges) {
  const initial={business:'0.2.4'}, body=[];
  for(let i=0;i<edges.length;i++) initial['k'+i]='e'+i+'v0';
  for(const id of vertices) body.push({kind:'begin',tx:id,connection:'connection-'+id});
  for(let i=0;i<edges.length;i++) {
    const [from,to,kind]=edges[i],key='k'+i,v0='e'+i+'v0',v1='e'+i+'v1',v2='e'+i+'v2';
    assert.ok(vertices.includes(from)&&vertices.includes(to)&&from!==to);
    if(kind==='ww')body.push({kind:'write',tx:from,key,version:v1,predecessor:v0},{kind:'write',tx:to,key,version:v2,predecessor:v1});
    else if(kind==='wr')body.push({kind:'write',tx:from,key,version:v1,predecessor:v0},{kind:'read',tx:to,key,version:v1});
    else if(kind==='rw')body.push({kind:'read',tx:from,key,version:v0},{kind:'write',tx:to,key,version:v1,predecessor:v0});
    else throw new Error('Unknown synthetic edge kind');
  }
  for(const id of vertices) body.push({kind:'commit_request',tx:id},{kind:'commit_ok',tx:id});
  const events=[{kind:'snapshot',initial,consistent:true},...body].map((event,i)=>({...event,seq:i+1,time:i}));
  return {traceSchema:3,clockDomain:'independent-category-boundaries-20261023',scope:{exclusiveWriters:true},events,gaps:[]};
}
export function withoutTransaction(trace,id) {
  return {...structuredClone(trace),events:trace.events.filter(event=>event.tx!==id).map((event,i)=>({...structuredClone(event),seq:i+1}))};
}
export function hasCategory(vertices,edges,category) {
  const allowed=kind=>category==='G0'?kind==='ww':category==='G1c'?(kind==='ww'||kind==='wr'):['ww','wr','rw'].includes(kind);
  for(const start of vertices) {
    const visit=(at,seen,kinds)=>{
      for(const[from,to,kind]of edges)if(from===at&&allowed(kind)){
        const next=[...kinds,kind];
        if(to===start&&next.length>=2&&(category!=='G2-item'||next.includes('rw')))return true;
        if(!seen.has(to)&&visit(to,new Set([...seen,to]),next))return true;
      }
      return false;
    };
    if(visit(start,new Set([start]),[]))return true;
  }
  return false;
}
