from pathlib import Path
import argparse,shutil,subprocess,json
parser=argparse.ArgumentParser();parser.add_argument('--node',default='node');parser.add_argument('--out',type=Path,required=True);args=parser.parse_args()
source=Path(__file__).resolve().parent;out=args.out.resolve();out.mkdir(exist_ok=False)
for directory in ['runtime','source','original-probes']:shutil.copytree(source/directory,out/directory)
for name in ['runtime-manifest.json','remaining-boundaries.mjs','probe-schema-corrected.mjs','input-constructor.mjs','verify-observations.py']:shutil.copyfile(source/name,out/name)
runs=[]
for script in ['probe-schema-corrected.mjs','remaining-boundaries.mjs']:
    r=subprocess.run([args.node,script],cwd=out,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=120)
    stem=script.removesuffix('.mjs');(out/(stem+'.first.stdout')).write_bytes(r.stdout);(out/(stem+'.first.stderr')).write_bytes(r.stderr)
    runs.append({'script':script,'exitCode':r.returncode})
    if r.returncode:raise SystemExit(r.returncode)
r=subprocess.run([__import__('sys').executable,'-B','verify-observations.py'],cwd=out,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=30)
(out/'verify.first.stdout').write_bytes(r.stdout);(out/'verify.first.stderr').write_bytes(r.stderr)
print(json.dumps({'passed':r.returncode==0,'runs':runs,'observationVerifierExitCode':r.returncode}));raise SystemExit(r.returncode)
