from pathlib import Path
import json,hashlib,sys
R=Path(__file__).resolve().parent;E=R/'frozen/verification/capture-persistence/v023-initial';out=R/'transcript-supplement-first';out.mkdir();r=json.loads((E/'receipt.json').read_text(encoding='utf8'));checks=0;results=[]
for name,item in r['publishedLogs'].items():
 p=E/(name+'.log');z=p.read_bytes();actual=hashlib.sha256(z).hexdigest();assert actual==item['publishedSha256'],name;checks+=1;results.append({'log':p.name,'sha256':actual,'bytes':len(z),'publishedTranscript':item.get('publishedTranscript')})
assert (E/'postgres-first-failure.json').is_file() and (E/'source-first-slow.log').is_file();checks+=1
result={'schema':1,'passed':True,'checks':checks,'originalWrongFieldExpectationUnchanged':True,'correctPublicField':'publishedLogs','records':results,'scope':'Published normalized transcript hashes only; unavailable private raw transcript hashes are not claimed independently checked'}
(out/'receipt.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8');print(json.dumps(result))
