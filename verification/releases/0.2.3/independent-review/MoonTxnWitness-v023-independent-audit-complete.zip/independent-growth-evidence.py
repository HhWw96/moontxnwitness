"""Independent bounded-observer and retained-source checks; fake connections only."""
from pathlib import Path
import sys,types,json,hashlib,gc,traceback
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT/'frozen/integrations/python'))
from moontxnwitness_capture import instrumentation as m
OUT=ROOT/'growth-evidence-first';OUT.mkdir();cases=[];checks=0;limitations=[]
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def ck(x,msg):
 global checks
 assert x,msg;checks+=1

def test(name,f):
 try:f();cases.append({'name':name,'passed':True})
 except BaseException as e:cases.append({'name':name,'passed':False,'message':str(e),'stack':traceback.format_exc()})
class Driver:
 def __init__(self):self.info=types.SimpleNamespace(transaction_status=0,encoding='utf-8');self.autocommit=False;self.closed=False
 def cursor(self,*a,**kw):return Cursor(self)
 def rollback(self):self.info.transaction_status=0
 def close(self):self.closed=True
class Cursor:
 def __init__(self,c):self.connection=c;self.description=None;self.pgresult=types.SimpleNamespace(status=1);self.row_factory=None;self.rowcount=1;self.rownumber=0
 def execute(self,*a,**kw):self.connection.info.transaction_status=2;return self
 def close(self):pass

def active_registry():
 o=m.Instrumentation(OUT/'bounded-registry');c=o.wrap(Driver())
 try:
  for i in range(650):c.execute('UPDATE original');c.rollback()
  o.flush();ck(len(o._call_events)==0,'ended transaction references retained');ck(len(o._active_call_depths)==0,'ended call depths retained');ck(not hasattr(o,'_events'),'full event history retained');ck(not o.journal._active and not o.journal._commit_requested,'ended journal transactions retained in heap')
  for i in range(200):
   temporary=o.wrap(Driver());temporary.execute('UPDATE original');temporary.rollback();temporary.close();del temporary
  gc.collect();ck(len(o._connections)==1,'closed connections retained without business owners');o.flush();ck(o.journal._identities.count==850,'disk transaction identity count lost');ck(o.journal.stats['maxQueueBytes']<=o.journal.max_queue_bytes,'event queue capacity exceeded')
  (OUT/'registry-counts.json').write_text(json.dumps({'transactionsOnDisk':o.journal._identities.count,'liveConnections':len(o._connections),'callReferences':len(o._call_events),'activeDepths':len(o._active_call_depths),'eventsStoredInMemory':hasattr(o,'_events'),'journalStats':o.journal.stats},indent=2)+'\n',encoding='utf8')
 finally:o.close()
test('850 ended transactions and closed connections do not accumulate active references',active_registry)

E=ROOT/'frozen/verification/capture-persistence/v023-initial';r=json.loads((E/'receipt.json').read_text(encoding='utf8'));pg=json.loads((E/'postgres-final.json').read_text(encoding='utf8'))
def source_bindings():
 q=r['pythonRegression'];ck(q['tests']==146 and q['passedTests']==144 and q['skippedTests']==2,'author suite summary changed');ck(q['sourceBefore']==q['sourceAfter'],'author source changed');
 for name,sha in q['sourceBefore'].items():ck(digest(ROOT/'frozen'/name)==sha,name)
 for name,sha in pg['sourceBindings'].items():ck(digest(ROOT/'frozen'/name)==sha,name)
 ck(pg['passed'] and pg['sourceUnchangedAfterExecution'] and len(pg['cases'])==6,'retained PG summary changed');ck(pg['server'].startswith('PostgreSQL 18.6') and pg['psycopg']=='3.3.6' and pg['sqlalchemy']=='2.0.55','retained PG environment changed')
test('author 146-case report and seven PG implementation bindings match frozen source',source_bindings)

def transcript_integrity():
 for name,item in r['logsPublished'].items():
  path=E/(name+'.log');ck(digest(path)==item['publishedSha256'],name)
 ck((E/'postgres-first-failure.json').exists() and (E/'source-first-slow.log').exists(),'first failure or slow log removed')
test('published transcripts and original failed/slow runs remain byte-bound',transcript_integrity)

for name in ['native-sync','native-async','engine-sync','engine-async','lost-commit-sync','lost-commit-async']:
 def retained_case(name=name):
  folder=E/'postgres-cases'/name
  for rel,sha in r['actualPostgresql']['caseFileSha256'].items():
   if rel.startswith('postgres-cases/'+name+'/'):ck(digest(E/rel)==sha,rel)
  trace=(folder/'trace.json').read_bytes();life=(folder/'lifecycle.jsonl').read_bytes();idx=(folder/'journal-index.json').read_bytes();interval=json.loads((folder/'interval-evidence.json').read_text(encoding='utf8'));records=[json.loads(line) for line in life.splitlines()];lines=life.splitlines(keepends=True)
  ck(interval['sourceTraceSha256']==hashlib.sha256(trace).hexdigest(),'trace binding');ck(interval['sourceLifecycleSha256']==hashlib.sha256(life).hexdigest(),'lifecycle binding');ck(interval['sourceJournalIndexSha256']==hashlib.sha256(idx).hexdigest(),'index binding');ck(interval['records']==records,'interval record copy differs');seal=records[-1];ck(seal['kind']=='seal' and seal['records']==len(records)-1,'seal count');ck(seal['prefixSha256']==hashlib.sha256(b''.join(lines[:-1])).hexdigest(),'seal prefix');ck([x['seq'] for x in records]==list(range(1,len(records)+1)),'lifecycle sequence')
  t=json.loads(trace);ck(t['scope']['exclusiveWriters'] is False and t['gaps'],'diagnostic scope lost');ck(not any(x['kind'] in ('read','write','condition') for x in t['events']),'unproved modeled fact')
  index=json.loads(idx);claimed=index.pop('indexSha256');actual=hashlib.sha256(json.dumps(index,sort_keys=True,ensure_ascii=False,allow_nan=False,separators=(',',':')).encode()).hexdigest();ck(actual==claimed,'index canonical digest')
  missing=[s['name'] for s in index['segments'] if not (folder/s['name']).is_file()]
  if missing:limitations.append({'case':name,'journalSegmentsNotIncludedInPublicCommit':missing,'cannotReverifyWholeJournalBytes':True})
  if name.startswith('lost-commit'):
   kinds=[x['kind'] for x in t['events']];ck('commit_request' in kinds and 'disconnect' in kinds and 'commit_ok' not in kinds and 'rollback_ok' not in kinds,'lost COMMIT no longer unknown');detail=next(c['detail'] for c in pg['cases'] if c['name']==name);ck(detail['collectorOutcome']=='unknown' and detail['actualBusinessWriteCommitted'] is True,'server/client distinction lost')
 test('retained actual PostgreSQL bindings '+name,retained_case)

result={'schema':1,'passed':all(c['passed'] for c in cases),'groups':len(cases),'checks':checks,'cases':cases,'limitations':limitations,'actualDatabaseExecutionByReviewer':False,'formalPerformanceMeasurement':False,'scope':'Independent fake live-reference test plus exact frozen retained PG metadata/transcript/source binding; no fresh DB or full journal-byte revalidation where segments are private'}
(OUT/'receipt.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8');print(json.dumps(result));sys.exit(0 if result['passed'] else 1)
