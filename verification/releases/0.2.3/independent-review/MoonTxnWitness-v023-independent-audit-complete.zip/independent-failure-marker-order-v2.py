"""Controlled worker failure-marker ordering; no sleeps/retry-until-green and no database."""
from pathlib import Path
import sys,json,threading,hashlib
from unittest.mock import patch
BASE=Path(__file__).resolve().parent;sys.path.insert(0,str(BASE/'integrated-final/integrations/python'));from moontxnwitness_capture import source_sink as s
MODE=sys.argv[2] if len(sys.argv)>2 else 'zero';assert MODE in('zero','diskfull');OUT=Path(sys.argv[1]).resolve()if len(sys.argv)>1 else BASE/'failure-marker-order-v2-first';OUT.mkdir(parents=True,exist_ok=False);x=s.GroupedSourceSink(OUT/'source.jsonl');x.flush();durable_before=x._durable_seq;entered,released=threading.Event(),threading.Event();op=Path.open;checks=0
def ck(x,msg):
 global checks
 assert x,msg;checks+=1
class Zero:
 def __init__(self,f):self.f=f
 def write(self,data):
  if MODE=='diskfull':raise OSError(28,'Independent disk-full data write')
  return 0
 def __getattr__(self,n):return getattr(self.f,n)
def opened(path,*a,**kw):
 if path==x.failure_path:
  entered.set()
  if not released.wait(10):raise TimeoutError('independent failure marker gate timed out')
 return op(path,*a,**kw)
x._file=Zero(x._file)
with patch.object(Path,'open',opened):
 try:
  ck(x.append({'kind':'source-batch','value':'zero-write'}).accepted,'input not admitted')
  try:x.flush()
  except s.SourceSinkError:pass
  else:raise AssertionError('failed IO was acknowledged as flushed')
  ck(entered.wait(5),'worker did not reach actual marker IO')
  ck(not x.failure_path.exists(),'gate did not precede marker creation')
  ck(x.lock_path.exists(),'writer guard disappeared before failure marker')
  ck(x._durable_seq==durable_before,'failure advanced watermark')
  ck(not x.append({'kind':'source-batch','value':'late'}).accepted,'failed source accepted later append')
  try:s.verify_grouped_source(x.path)
  except s.SourceSinkError:pass
  else:raise AssertionError('fresh verifier accepted locked failed source')
 finally:released.set()
try:x.close()
except s.SourceSinkError:pass
else:raise AssertionError('failed close returned success')
ck(x.failure_path.exists()and x.lock_path.exists(),'joined worker did not retain durable failure guards');r={'schema':1,'passed':True,'checks':checks,'workerTemporarilyPausedBeforeMarkerCreation':True,'flushRefusesBeforeMarkerExists':True,'writerGuardAndWatermarkPreserved':True,'freshVerifierRefusesWhileWorkerPaused':True,'failureMarkerExistsAfterJoin':True,'actualDatabaseExecution':False,'formalPerformanceMeasurement':False,'original13ChallengeUnchanged':True,'mode':MODE,'scope':'flush error is observable before worker failure-marker IO finishes. Safety is provided by refused flush, preserved writer guard and unchanged watermark; closed worker later seals failure marker.'};(OUT/'receipt.json').write_bytes((json.dumps(r,indent=2)+'\n').encode());print(json.dumps(r))
