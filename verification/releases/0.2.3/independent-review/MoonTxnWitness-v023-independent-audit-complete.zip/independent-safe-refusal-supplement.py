from pathlib import Path
from unittest.mock import patch
import sys,json,traceback
R=Path(__file__).resolve().parent;sys.path.insert(0,str(R/'postfix-60afa17/frozen/integrations/python'))
from moontxnwitness_capture import source_sink as s,journal_v3 as j
out=R/'postfix-60afa17/safe-refusal-supplement-first';out.mkdir();cases=[]
def test(name,fn):
 try:fn();cases.append({'name':name,'passed':True})
 except BaseException as e:cases.append({'name':name,'passed':False,'message':str(e),'stack':traceback.format_exc()})
def close_refuses():
 x=s.GroupedSourceSink(out/'known-refused.jsonl');assert x.close()['storageSealed'] is True;original=Path.open
 def opened(path,*a,**kw):
  if path==x.invalidated_path:raise OSError(28,'Independent marker disk-full')
  return original(path,*a,**kw)
 with patch.object(Path,'open',opened):r=x.append({'kind':'source-batch'})
 assert r.accepted is False and r.gap
 try:result=x.close()
 except s.SourceSinkError:result={'explicitlyRefused':True,'exception':'SourceSinkError'}
 else:assert result['storageSealed'] is False
 (out/'refusal-result.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
def prune_returns_no_deletion():
 x=j.SegmentedJournal(out/'journal');x.append({'seq':1,'time':1,'kind':'snapshot','consistent':True,'initial':{}});assert x.close(source_closed=True).complete;before={p.name:p.read_bytes() for p in x.path.iterdir() if p.is_file()};result=x.prune(before_seq=1);assert result['implemented'] is False and result['deleted']==[];assert before=={p.name:p.read_bytes() for p in x.path.iterdir() if p.is_file()}
test('known post-close marker failure explicitly refuses sealed success',close_refuses);test('prune returns no-deletion result without an exception requirement',prune_returns_no_deletion)
r={'schema':1,'passed':all(c['passed'] for c in cases),'cases':cases,'originalRunnersAndExpectationsUnchanged':True,'basis':'Safety requires refusing a sealed-success result; existing failed-marker API may use SourceSinkError. The original runner overconstrained this to a false return and separately misread prune return contract.','actualDatabaseExecution':False,'formalPerformanceMeasurement':False};(out/'receipt.json').write_text(json.dumps(r,indent=2)+'\n',encoding='utf8');print(json.dumps(r))
