# 开发与发行状态

## v0.2.0 稳定范围收敛

本版以[稳定支持矩阵](stable-scope.md)整理已形成明确入口的能力，保留算法、预算、unknown/覆盖缺口、原始证据及显式引擎兼容。全自动 SQL、完整 ORM、六模型和完整业务生产接入仍属后续工作，不把早期30–40日计划的全部目标预填为完成。17/18能力只有通过其实际版本及本版适用验证后，才可在正式发行中列为已验收；候选和准备记录不能替代。

本版构建、完整回归、适用数据库、独立复核、两种分发包与公开下载以 `verification/releases/0.2.0/` 实际收据为准，性能数字不预填。真实数据库记录继续保留原产生版本；旧 ORM13/列表14/关系15观察的当前离线重放，与本版新执行 SQL 分开记录。

以下是各版当时的开发与发行记录，保留原状态、失败及审计标签，不将历史段落中的“当前”理解为本版结果。原[逐版大目标计划](remaining-execution-plan-2026-10-21.md)原文归档，当前[后续安排](remaining-execution-plan.md)按可验证子集持续推进。

## 逐版历史记录

2026 年 10 月 23 日：v0.1.7 已发布至 GitHub 与 Mooncakes，并通过[公开 Linux 下载验证](https://github.com/HhWw96/moontxnwitness/actions/runs/39820215994)，实际结果见[发布收据](../verification/releases/0.1.7/publication.json)。执行诊断包、证据环、关系集合、列表、采集、普通表与 ORM 模板继续按各自边界提供。

## v0.1.8

本版交付实际17版执行诊断包兼容重放与九项解析边界回归；保留全部既有 SDK、预算、来源和原发行门禁。默认生产解析器与已发布17版完整文件逐字节一致，ASCII 复用 helper 仅留在测试文件，原九项断言完整后缀不改。

优化候选的首轮正式对照完成了正确性核对，但性能控制验收未满足，故不纳入稳定默认路径。原599906/5b63实验构建、样本及失败收据保持；不能作为回退后稳定18的性能或独立验收。新稳定18的完整回归、基础数据库、独立复核、打包和公开下载各自以新收据记录；旧 ORM13、列表14、关系15的数据库来源不改标。稳定18未进行新性能测量，不声明性能目标通过。

## v0.1.7

执行诊断包提供两个 SDK 入口与既有 MLflow 记录离线对照，保留 unknown、故障及来源缺口。现有记录缺少当时 capture.py 的执行字节绑定，不能追补为完整来源认证；本版不声称新数据库复现或完整应用修复。候选的 54 项断言迁为源码测试，正式 v0.1.7 构建、安装与公开结果以 `verification/releases/0.1.7/` 实际收据为准，不能用候选或旧运行时检查替代。边界见[执行诊断包](execution-capsule-v3.md)。

## v0.1.6

本版提供已有点寄存器环的类型与来源解释和两项 SDK 入口，原报告与原 v3 胶囊保持，派生解读单独复核。支持边界见[解读说明](cycle-explanation-v3.md)。正式构建、安装、数据库回归与公开下载以 `verification/releases/0.1.6/` 的实际收据为准。先前候选独立审查覆盖 132 份历史及其保存点、来源、首尾相邻和篡改边界，使用 v0.1.4/v0.1.5 运行时；不得计成正式 v0.1.6 验收。

## v0.1.5

本版将有界 `relation-set-v1` 作为明确支持的关系集合入口，提供[六个专用 SDK 函数和来源闭包缩减示例](relation-sdk.md)。完整查询结果、空结果与实际写影响分别表示，保留 int64 字符串、布尔和文本规则；未知提交、来源不足、查询不完整或预算耗尽仍无法判定。

隔离候选在 v0.1.4 运行时上通过 194 项 SDK 检查，独立审查十组通过；170 份关系历史和 71 份旧列表历史逐字段核对，175 份关系输入由冻结解释器独立核验。示例从四个事务缩为 P/A/B 三个事务，删除 P 会缺少读取来源，分别删除 A/B 则可串行执行。候选审查与实际 v0.1.5 构建、数据库和公开下载验收分别保存于 `verification/releases/0.1.5/`，不互相替代。

实际 v0.1.5 构建的三个本地目标各 620 项核心检查、194 项关系 SDK 和 92 项列表 SDK 检查通过。新集群八类关系场景各执行 20 次，160 份实际 SQL 与 160 份当前核心模型结果均核验；原寄存器、采集及普通表数据库回归也通过。实际构建独立审查九组通过，包含 335 份冻结解释器输入、170 份关系及 71 份列表对照、来源闭包与预算/篡改检查，并重放 v0.1.4 的三份真实寄存器和 120 份真实列表胶囊。计数存在交叉，不累加为不同业务场景；没有新正式性能提升声明，分发安装及公开下载继续由各自实际收据确认。

## v0.1.4

本版将有界 `append-list-v1` 作为明确支持的列表模型，提供[六个固定模型 SDK 入口及 3→2 事务演示](list-sdk.md)。元素使用唯一身份和字符串值，不能混合数据模型；来源不足、未知提交和计算预算耗尽保持无法判定。精确分析仍限六个已提交事务、128 个 append/read，缩减与搜索预算分别记录；不据此扩展为任意 SQL 自动采集或完整隔离分类。

隔离接入候选已通过 **10/10 组独立检查**，原 **92/92 项** SDK 回归在独立目录重新通过，其中 71 份冻结手工历史与通用入口逐字段一致。检查确认五个 capture 包装入口把原始字符串交给核心、明确拒绝错模型，并保留 invalid/inconclusive 胶囊的真实状态。首版在重放非法 JSON 文本的通用诊断胶囊时抛出解析异常，原失败及快照保留；修复后相同四份输入均稳定返回固定模型拒绝。

以上检查使用 v0.1.3 已编译核心，未重新运行数据库、编译 v0.1.4 或进行正式性能测量。本版实际构建、数据库、完整回归、消费者及公开下载结果在 `verification/releases/0.1.4/` 按执行收据分别记录，不将候选结果预填为发行通过。以下各版历史记录保持原有源码和证据绑定。

v0.1.4 新构建的三个本地目标各 620 项核心检查、92 项列表 SDK 回归及原有采集兼容检查已通过。新的六类 PostgreSQL 列表场景各执行 20 次，共 120 次；当前核心与独立解释器核验其原始记录及复现包。新构建的独立审计 8/8 组通过，另验证 71 份历史逐字段对照、预算和来源缺口、3→2 示例的单删最小，以及 v0.1.3 真实 v2 与列表 v3 胶囊兼容。最终公开闭包见[当前版本审计](../verification/releases/0.1.4/list-independent/run14-5Q6lQq/receipt.json)。分发 86 项全新消费者检查、精确提交 Linux/Windows 与 Native、真实数据库 CI 和上述公开下载均已通过。

## v0.1.3

本版交付[固定 ORM SQL 模板与有界缓存](orm-plans.md)，以及明确范围的[局部来源诊断](orm-source-v3.md)。模板入口只编译和匹配固定 base-user 点 CRUD，不执行 SQL；缓存隔离完整键域、字段布局和配置上下文，不保存业务参数或结果。默认额度为 128 项、1 MiB 计费条目字节，超大计划不保留。

主线离线检查 **21/21** 通过，独立候选检查 **32/32** 通过（含前述 21 项复验与 11 项附加检查，非 53 个独立用例），零跳过。检查覆盖实际 SQLAlchemy 编译器、新旧模板对照、上下文隔离、缓存预算、逐次参数校验、结果与异常身份，以及执行阶段不调用 fetch。两个离线流程均禁止连接数据库。

本次另用新的 PostgreSQL 18 集群执行冻结的原 FastAPI Users 业务；缓存开关两组的 CRUD、刷新、嵌套回滚、连接重用和原异常结果一致。MoonBit 对两组新记录各核验 **21 条局部来源事实**，保留完整覆盖为 false。三个本地目标各 **620 项**核心检查、10,320 份串行重放核对、6,373 份环证据验证及现有 PostgreSQL 采集回归通过。原始数据库、来源核验、独立审计及公开安装结果见 `verification/releases/0.1.3/`；公开结果对应本页所列下载验证收据。

固定 35 形状、每形状执行三次的编译调用对照为旧实现 70 次、开启缓存 35 次、关闭缓存 140 次。这是工作量计数，尚无本版业务吞吐、延迟或 RSS 提升结论。独立检查保留候选和原始输入的前后摘要；原始日志在各自 `artifacts` 审查目录，不把本地审查记录冒充发行包可复跑证据。

局部诊断成功仍返回 `analysisCoverageAccepted:false`、`history:null`。`ProvenanceObserver`、公共安装迁移及完整 ORM 历史覆盖继续实验；更广 SQL、连接池、数据模型及性能优化按实际完成范围逐版发布。以下保留此前按日期与源码记录的开发证据，不将旧计划中的未完成目标作为已发布能力。

## 2026 年 10 月 21 日开发记录

记录日期：2026 年 10 月 21 日。当前包仍为 v0.1.1 开发版；公开稳定版本为 v0.1.0。普通表 CRUD 使用独立实验入口，尚未作为 v0.1.2 稳定接口发布。实现、公开发布、人工验收及赛事审核分别记录。

## v3 共同底座的首批实现

### 第八批：真实双窗口交接与初始化确认

普通表新增[双窗口来源交接实验](../verification/experimental-candidates/plain-epoch-r1-2026-10-21/README.md)，
在[独立 Linux / PostgreSQL 18.6 流程](https://github.com/HhWw96/moontxnwitness/actions/runs/39620317399)
实际通过 **47 项基础检查与 4 个数据库场景**。场景覆盖相同值的不同版本及跨窗口衔接、
事务回滚和保存点撤销、域外 SQL 保留业务结果但拒绝完整交接，以及执行真实 COMMIT 后
注入应答丢失时保留原异常和保护记录。最后一项不是网络断连实验。
首次流程因源码归档被忽略规则排除，在执行前失败；原始工件与原因完整保留。
[独立原始证据审计](../verification/experimental-candidates/plain-epoch-r1-2026-10-21/actual-ci-39620317399/README.md)
**2,832 项通过、零失败**，重算 740 个原始归档文件及 101 个不可变 Git 对象。
两次审计工具问题与修订分别保留，未改候选或预期场景结果。

独立静态审查发现键迭代器先全部物化、首次初始化未明确校验提交确认两处边界，
已在[单独冻结的修订](../verification/experimental-candidates/plain-epoch-r2-2026-10-21/README.md)修复。
新旧 **73 项**本地隔离检查通过，零跳过，27 项恢复文件绑定保持；
新测试使用合成数据库响应并执行原初始化器、确认屏障及真实文件操作。
该修订的[实际 Linux / PostgreSQL 验证](https://github.com/HhWw96/moontxnwitness/actions/runs/39622521792)
也保留 **73 项及 4 个真实数据库场景**的通过输出；
[独立限定审计](../verification/experimental-candidates/plain-epoch-r2-2026-10-21/actual-ci-39622521792/README.md)
**2,760 项通过、零失败**，未借用 R1 记录。官方 run 为 success，独立读取的 job 列表与直接
接口仍为 in_progress/null；两者同时保留，整体任务完成元数据及发布验收没有签收。
来源记录在关闭时同步；不声称每条 ACK 已独立 fsync 或初始化具备断电恢复保证。
SQL 核心证明、分析来源闭包、来源清理及完整 C/A 性能仍未完成，实验标志保持 false。

Elle 批处理的独立静态审查还发现：原包装会把“明确 false 且同时有部分搜索超时”
合成单一 timeout，摘要错误还可能丢失已返回的原始结果。
[独立传输修订](../verification/experimental-candidates/elle-result-transport-r3-2026-10-21/README.md)
已分开保留原判断与超时，并先存原始 EDN，再生成摘要；准备、检查器、结果存储及摘要错误分别记录。
纯摘要 **5 项 / 16 断言**、合成回调及文件故障 **6 项 / 27 断言**通过。
使用 Clojure 1.12.6 / Java 25.0.1；完整包装只做真实 reader 的八个 form 读取，未求值。
这不是固定 Java 21 的实际 Elle 集成或 2,000 输入判定；外层进程与输出预算、完整对照继续保留。
2,000 份冻结输入不作替换。

### 第七批：主线安装回归、普通表持久化与真实 Elle 前置验收

源码 `ec35d4a6` 的主线新增 ORM 来源诊断已通过四目标各 **616 项**核心回归。
首次公开构建 `41a6363` 的 Linux 打包把公共 GitHub hosted 账号路径误判为私人路径；
原失败日志与诊断保留。修复为打包与发布扫描共用已有的严格 hosted 账号识别，
另加归档检查，私人或 self-hosted 目录仍拒绝。修复提交 `73695cc` 的
[跨平台核心及全新消费者](https://github.com/HhWw96/moontxnwitness/actions/runs/39605151684)与
[真实 PostgreSQL 回归](https://github.com/HhWw96/moontxnwitness/actions/runs/39605151584)均成功。
CI 已同时上传实际源码和便携 ZIP；独立公开包下载验收另记，不借用这一步代替。
第一次主线公开产物另已完成
[1,478 项来源／运行文件／收据核对](../verification/experimental-candidates/orm-integrated-ec35-2026-10-21/actual-main-ci-39602851503/README.md)，
两种实际下载运行文件各通过原 **332 项**消费者及 **24 项** ORM 语义检查；严格报告字节仍为 23/24。
Linux 首次失败产物中的旧 76 项打包记录未被接受；它不能代替修复后 73695 新 ZIP 的独立安装验收。

普通表 R2 持久化实验的[实际 Linux 流程](https://github.com/HhWw96/moontxnwitness/actions/runs/39604038471)
执行 **31 项基础检查与 7 个 PostgreSQL 18.6 场景**，作者支持核对确认原始文件绑定。
四个受支持场景封闭，错误、域外 SQL 与 ledger 预算耗尽保持缺口。
[独立原始来源审计](../verification/experimental-candidates/plain-journal-r2-2026-10-21/actual-ci-39604038471/independent/independent-receipt.json)
**1,305 项通过、零失败**，独立重建来源及提交账本；冻结错误对象身份断言与真实CI日志另有绑定，
不把JSON字段本身称作对象身份再证明。SQL 核心证明、两个真实窗口交接、超过 64 个现有键及完整 C/A 成本均未完成。

真实 Elle 原 15 输入、8 实际 checker 结果及 69 转换边界现已通过
[95 项独立 AI 检查](../verification/experimental-candidates/elle-smoke-r2-2026-10-21/actual-ci-39599513353/independent-r2/independent-smoke-receipt-r2.json)。
六个明确结果一致，两个空图 unknown 差异保持；固定旧 b663，不覆盖新 ec35 主线。
两次环境失败与首次独立验收器标签错误保留。后续 **1,000＋1,000 原始历史**
已在[单次、仅生成流程](https://github.com/HhWw96/moontxnwitness/actions/runs/39606834359)完成冻结，
原数据摘要 `4b7ef85e`、5,940,749 字节。
[独立原始域与形状审查](../verification/experimental-candidates/elle-expansion-generation-v2-2026-10-21/actual-ci-39606834359/independent-root/receipt.json)
复算 2,000 份原始输入、首次出现程序形状及额外的最终程序 payload 等价类形状均为 2,000 种，
十族各 200，来源及支持范围均核验。该审查不证明完整图同构，也没有执行判定器；
下一关为单独审查的流式批量评估器，不能按后续结果替换输入。
其[首个实际转换切片](../verification/experimental-candidates/elle-batch-evaluator-r1-2026-10-21/README.md)
已保留 40 组各 50 份请求，2,000 份均通过原独立转换器与 EDN 解码逐项核对；
新的 Clojure 持久化包装仍未编译或执行，远程进程预算、全量结果汇总及独立证据验证待完成。

[解析器分配实验](../verification/experimental-candidates/ascii-parser-ec35-2026-10-21/README.md)
在隔离源上通过三目标各 **625 项**、2,542 份解析差分与 **117 份完整输出逐字节核对**。
单次固定采样的分配比分别为 0.903909 与 0.983525；它们不是正式速度、P95 或 RSS 验收。
主线仍保留原解析器，独立审查及正式性能门槛待完成。

公开稳定版本继续为 v0.1.0；上述均不是 v0.1.1／v0.1.2 联合发布或 v0.2.0 验收。

### 第六批：来源证明修复与受保护的日志收尾

主线现已集成显式 `inspectOrmSourceV3` / `inspect-orm-source-v3`，用法见[来源诊断](orm-source-v3.md)。本地完整回归通过三目标各 **616 项**、原解析/串行历史/环证据及旧CLI，新增 **12项**SDK/CLI检查；源码指纹 `ec35d4a61267af9c5600baf6e62197219aa979fdc1f36ca17a9a4bc40f1d9787`。首次本地回归使用缺少可选驱动的Python，在关系fixture的环境断言失败；换用原固定psycopg3.3.6环境后完整通过，原断言未改。两个本地符号链接权限跳过仍保留，Native和新公开构建以后续隔离CI为准。

新运行文件独立重放原24输入，语义 **24/24**通过，4份有效报告完整字节一致；严格24份报告字节核对为 **23/24**。唯一变化是格式化后拒绝报告中的编译器源位置，SQL摘要、拒绝条件及其余输出完全相同。原严格失败收据保持失败，不去掉错误位置或修改输入来补勾。新SDK不自动授予SQL覆盖。

ORM 第三轮候选修正了控制查询 JSONB 与业务结果文本传输的构造混用，保留首轮编译失败和第二轮原始正例失败。[实际隔离 CI](https://github.com/HhWw96/moontxnwitness/actions/runs/39588309646)通过四目标各 **616 项**测试及 **74 项**原始来源/篡改检查，并上传实际编译运行文件。独立下载运行文件的24项检查另有冻结程序，尚待实际执行；作者测试通过不替代独立验收。此实验仍不导出完整历史。

存储第四轮将永久 `coordination.lock` 原生互斥锁与可删除的 `operation.lock` 所有权记录分开，最终数据同步与失败保护在永久锁持有期间完成。[实际双平台 CI](https://github.com/HhWw96/moontxnwitness/actions/runs/39590720441)各 **51＋32＝83 项**通过、零跳过；[原始产物及收据](../verification/experimental-candidates/storage-r4-2026-10-21/actual-ci-39590720441/artifacts-metadata.json)保留。独立两项真实文件故障注入与24项检查已预登记，待实际双平台执行。第三轮独立失败原样保留，旧故障位置对新协议不适用，不记为通过。Windows目录同步原语及提交后原生释放与全部诊断IO同时失败的限制仍明确记录。

这两项候选均未接入默认稳定接口。本机资源限制下，只做有界静态检查，执行放在隔离CI；正式性能、完整采集C/A、业务并发种子、完整六模型和最终发布门槛仍未完成。

后续[实际独立下载ORM来源检查](https://github.com/HhWw96/moontxnwitness/actions/runs/39595025070) **24/24**通过，并完成40项原始证据/字节核验；原参考程序选错命名参数的首次失败完整保留。存储[独立两平台故障验收](https://github.com/HhWw96/moontxnwitness/actions/runs/39596107868)各 **24项**通过，并完成63项下载/原始归档/锁竞争核验；这是两类真实故障义务的签收，非完整GC或断电证明。

真实Elle小规模对照已在固定上游提交和固定旧b663分析器上实际运行：原8案为2true/4false/2空图unknown，原15输入和69转换边界保留。前两轮环境失败分别为缺显示环境与剔除上游必需dev依赖，均保留；第三轮使用真实Xvfb及上游原有dev配置。该比较不覆盖新的ec35主线，也不代表完整六模型；独立下载验收与1000＋1000扩展仍按各自门槛推进。

### 第五批：独立公开下载验收与来源实验

[独立公共下载流水线](https://github.com/HhWw96/moontxnwitness/actions/runs/39584863870)已对固定公开提交 `7863550` 实际执行。[独立 AI 再核验](../verification/public-audit-results/39584863870-verified.json) **56/56 项通过**：重新下载三份原 CI 产物及固定源码，复算实际 core/capture、两平台各339项源码绑定、原563项三目标及 Linux Native 日志；两套下载运行文件在新 Linux 目录各通过 **332项消费者＋24项 MLflow 审计**。本次没有借用作者 dist，也没有重新运行数据库或性能测量。旧公开 summary 中三项滞后绑定未被拿来替换新 CI 输入；首次观察器差异与纠正说明分别保留。源码/便携发行 ZIP 未由原打包 CI 上传，不能把实际运行文件下载验收称为发行 ZIP 下载验收。

归档原日志回收新增了[冻结实验源码及双平台隔离流程](../verification/experimental-candidates/storage-r3-2026-10-21/README.md)，未接入默认日志 API。修复错误恢复请求毒化后，[本修订各70项检查](https://github.com/HhWw96/moontxnwitness/actions/runs/39584875590)两平台通过且无跳过；独立审阅随后发现收尾目录同步故障会丢失失败保护，[独立真实反例](https://github.com/HhWw96/moontxnwitness/actions/runs/39585753335)在两平台均实际失败，原输入、崩溃 intent、错误和断言完整保存。因此70项通过不代表存储验收完成，继续修复该缺口。

ORM sourceSchema2 原始控制查询证明已形成[独立 MoonBit 候选](../verification/experimental-candidates/orm-source2-2026-10-21/README.md)，固定原始记录342,967字节、trace44,633字节及旧source1。首轮模板AST检查通过，编译检查失败；类型/语法修复另存新候选，后续实际阶段按各次收据记录。全部候选仍保持 `history:null`、`analysisCoverageAccepted:false`，不声明任意 SQL/ORM 或整个认证系统已覆盖，也未发布稳定版本。

[抽象 SI 独立证据包](../verification/classification-v3/abstract-si-2026-10-21/README.md)已公开冻结参考解释器、1,000份不同历史与完整结果、683份共同范围图及1,014个独立重放见证，并附实际实验运行文件及匹配源码关系。52个边界的手工期待与1,000份完整结果分开记录；原生成计划计数错误、空执行契约补充和未执行的便携脚本也明确保留。该批未重新运行测试，既有结果不代表实际 Elle 对照、原始历史自动分类或完整六模型验收。

### 第四批：搜索分配优化与正式性能复核

主线新增整数搜索键缓冲、等价 UTF-16 标识符校验和精确容量邻接表，保留完整边来源、搜索顺序、额度及计数。源码指纹 `b6638ee56395a14284d1440a92a0d975c4ea4073f42ccab6d8d39e359d928096`，完整回归通过三目标各 **563 项**、原 10,320 份历史 / 6,373 份环证据和 2,542 份解析差分；117 份完整输出与前一实现逐字节一致。JS 字符串原语只物化已编码的有界键，判断逻辑仍由 MoonBit 实现。

暂停并行任务后，按原协议执行新一轮完整测量，未重复未变实现。独立 AI 重算 [38 份快照、6,300 样本及 120 份完整输出](../verification/performance-v3-drafts/formal-audit-2026-10-21-082601/receipt.json)，20 项原 P95 门槛均通过。[本轮目标核对](../verification/performance-v3-drafts/b663-2026-10-21/formal-target-assessment.json)：图组提速 **1.497 倍**、9–12 事务搜索提速 **2.103 倍**达标；图组峰值 RSS 比 **0.930**、512 事务缩减 **1.151 倍**未达标，完整采集 C/A 尚未测量。第三批失败结果与草稿中缩减变慢的诊断均保留，不能混合不同实现的通过项。

诊断、补丁和两轮完整字节对照见 [冻结优化草稿](../verification/performance-v3-drafts/df23-candidate-v2-2026-10-21/publication-index.json)。该草稿的原始说明保留“当时尚未合入”的历史状态；当前主线是否通过以新 summary 与本节正式收据为准。采样数据不充当正式耗时或 RSS 验收。

分类图底层另有[实验源码与独立图语料](../verification/classification-v3/graph-kernel-2026-10-21/publication-index.json)，三目标各577项和1018份冻结图核对通过，预算恢复遗漏已被独立静态审阅发现并修复。此代码未进入主线默认运行时，只验证已给类型图上的约束，始终不声称完整六模型、原始历史来源或抽象 SI 已验收。

第三批公开提交 [8f5d51a](https://github.com/HhWw96/moontxnwitness/commit/8f5d51a878ef7872f76e02fa745888523df6436a) 的两项 CI 已成功；[独立公开下载验收](../verification/v3/independent-public-checkpoint-8f5d51a-completed-2026-10-21T08-22-46-678577Z.json)核对源码、三份实际产物、双平台各338项非 dist 源码绑定、实际 core/capture/wrapper、Linux Native554项、76项打包消费者及真实关系场景160轮。下载运行文件在独立新目录各通过332项检查，另各补24项 MLflow 审计；首次审计路径放置失败与修正收据分别保留。这是前一 df23 实现的公开验收，第四批尚需自己的 CI 与下载验收。

第四批后续打包的源码消费者在测试链接阶段发生[编译内存不足](../verification/v3/package-compiler-memory-failure-b663-2026-10-21.json)，首次包与消费者目录完整保留。打包工具改为一次只运行一个编译任务，测试和优化等级不变。此工具变更后的完整回归又在 [list CLI 检查](../verification/list-v3/acceptance-2026-10-21T09-06-16-462Z/receipt.json)遇到 Node 内存分配失败；20,071 份输入仍零差异，但本轮整体失败。宿主可用提交内存不足1 GB，自动审批服务也出现 Allocation error。并行任务已暂停，不重跑同一实现寻求通过；最新工具完整回归及全新安装尚待资源恢复或新隔离 CI 核验。本节最初的563项完整通过属于打包工具变更前的已绑定收据，不能补勾后续失败。

随后已推送 [7863550](https://github.com/HhWw96/moontxnwitness/commit/78635505e4c189c402ba70600632aeaef71ef206)。新的 [Windows/Linux 核心 CI](https://github.com/HhWw96/moontxnwitness/actions/runs/39577549262)与 [真实 PostgreSQL CI](https://github.com/HhWw96/moontxnwitness/actions/runs/39577549263)均成功。独立读取实际任务日志确认：两平台各三目标563项、Linux Native563项，以及两平台各76项全新源码/便携消费者通过，见[日志与产物元数据核验](../verification/v3/public-checkpoint-7863550-ci-log-audit-2026-10-21.json)。该原收据只检查日志和元数据；后续独立实际下载及新消费者验收见第五批，本机失败记录保留。

### 第三批：关系集合、执行故障及分配优化

本地已集成关系模型、执行故障诊断和三处分配优化，MoonBit 源码指纹为 `df23e6a01c0d59420c7576eb35271b6346c500044ee24a0ea0d7ac29a951d97b`。JS、Wasm GC、Wasm **各 554 项**、全目标静态检查、旧 oracle/CLI 及新独立模型/故障核对通过。首轮打包在便携归档压缩时发生内存分配失败，未进入消费者；[失败摘要](../verification/v3/package-memory-first-failure-2026-10-21.json)绑定原产物。压缩改为 64 KiB 分块，保留跨块隐私检查、固定元数据与完整 ZIP 校验，三个实际边界测试通过；变更后完整回归再次通过，**76 项全新消费者**包含源码重建、关系模型/缩减/复现及执行故障诊断。不借第二批 CI 作为本批验收。

[关系模型](relation-v3.md)新增 127 项核心边界。独立解释器事先冻结 170 个边界和 1,000 个不同生成输入，1,170 份输入零差异；704 个串行见证、1,138 份规范化、924 份来源和十项预算计数核对通过，57 项外部检查包含 35 类篡改及八项 CLI。早期 439 处差异与修复前字节完整保留。受控 PostgreSQL 18.6 的八场景各 20 轮已实际执行；SQL/参数/完整查询、写影响及最终来源账本逐项核对，100 consistent / 60 violation 符合预登记，160 份复现包通过。另有[独立原始数据链审计](../verification/relation-v3/raw-chain-independent-2026-10-21T06-22-23-676071Z.json)，重新核对完整谓词、结果、事务 ACK、保存点撤销、墓碑及实际 SSI 重试，不只信 fixture 作者的断言。原 SQL fixture 与模型收据分开，不声明任意 SQL 或完整 ORM 支持。

[MLflow 组件实验](../experiments/faults/mlflow/README.md)实际执行修复前后固定提交的原方法和原模型类：修复前一笔真实 `40P01`、一笔提交；修复后两笔提交，1,000 行最终值和版本字段正确。新 MoonBit 诊断有 14 项边界；[独立 AI 审计](../verification/faults/mlflow/independent-2026-10-21T06-03-09-641678Z/receipt.json)核对原始来源、AST、SQL、日志与最终数据，24 项 SDK/CLI/篡改检查通过。每案九条实际 SQL 在独立 fixture 日志中，通用 v3 只有八条 statement；原 ORM `executemany` 保持显式缺口，模型仍 inconclusive，没有将死锁改名为 G2。

性能改动减少实时边报告的中间对象、稀疏索引分配和搜索回滚元组，新增 15 项测试并保留完整边依据及旧搜索顺序。暂停并行编译、数据库、打包和下载后，已完成本轮 **5 次预热 / 30 样本 / 3 批独立进程**的 20 完整负载、15 阶段测量，全部原 P95 回退门槛和完整输出核对通过。[最终目标核对](../verification/performance-v3-drafts/2026-10-21/formal-target-assessment.json)中，图组提速 **1.566 倍**达到 1.3 倍；图组 RSS 比 **0.933**、9–12 事务搜索 **1.274 倍**、512 事务缩减 **1.122 倍**均未达到计划目标。原轮完整保留，继续诊断并修改代码，不重复同一实现直到测过。完整采集 C/A 仍未测量。

### 第二批：列表、业务采集与显式 SQL 来源证明

第二批已验 MoonBit 源码指纹为 `f33c8675a69a0681bb7865e32f2ace5aed21b03fb2d03dc16265dee2dbe6d57b`。本地 [完整回归](../verification/summary.json)已通过 JS、Wasm GC、Wasm **各 398 项**核心测试，保留原 10,320 份独立串行历史、6,373 份环证据、2,542 份解析差分及原 CLI 验证。Linux Native 和公开下载核验须以这一批新的 CI 与独立收据为准，不能借用旧 187 项成绩。

[追加列表](list-v3.md)新增 88 项核心边界，独立解释器核对 20,071 份冻结历史无差异并重放 8,352 个串行见证。记录含 **10,118 个不同输入**；原批覆盖重复偏多的记录保留，新批具有 7,555 种程序形状。六个真实 PostgreSQL 场景各 20 轮的原始 SQL、数据库结果与成功的离线核对均保留；原第一次核对在并行写入解释器时发生一案语法错误，公开脱敏副本绑定原失败字节，后续只读核对使用冻结解释器，没有改动真实历史。

[dislock 全生命周期](dislock-v3.md)已实际执行主连接、心跳、退出清理、busy、owner 变更、业务异常及真实断连重连。最终 [数据库收据](../verification/business/dislock/v3-db5f87c5620c4f8e955172340023482c/database-receipt.json)与 [模型收据](../verification/business/dislock/v3-db5f87c5620c4f8e955172340023482c/model-receipt.json)各通过七案。新增 [明确 COMMIT 失败](../verification/business/dislock/v3-commit-fb56573a35ef415b872509cf1004ee90/commit-receipt.json)实测：真实提交阶段 `40001` 及事务状态支持服务器中止确认，原异常身份保持，随后 idle rollback 不添加伪造事务；提交应答丢失仍为 unknown。

固定 SQL 经过结构、返回列、条件、OLD/NEW 来源、实际效果账本和安装目录核验后，可显式选择 `sqlProof:"dislock-f9946f0-sql-proof-1"`。默认入口保留原有保守行为。七案显式结果为 **3 consistent / 4 inconclusive**；零行条件缺来源、未知事务和未映射失败语句保持缺口。独立 SQL 诊断 86 项、显式策略 199 项检查通过，包含旧复现包、36 项报告/包篡改和来源闭包缩减。合成缩减样本只删除噪声事务，保留异常依赖的来源事务；该样本不冒充真实数据库排障。

同步 v3 采集器使用磁盘分段日志，不持续保留 `_events`。35 项协议测试通过；64 项日志测试本地 62 项通过、2 项因符号链接权限跳过，独立存储 10 项及关闭后继续使用连接的 42 项检查通过。独立审计发现的关闭后漏记和 `snapshot.consistent=false` 覆盖错误均先保留失败，再修复重测。

这些结果仍是开发切片。来源闭包窗口、安全保留/清理、完整采集 C/A 成本、ORM 来源证明、六模型与 Elle、真实 MLflow 故障缩减及最终性能尚未验收。关系模型和组件复现的新进展见第三批。v0.1.1 / v0.1.2 联合发布门槛保持未完成；独立 AI 技术验收与真人使用、生产采用及赛事审核分开记录。

第二批公开源码 `bb87f93` 的 PostgreSQL CI 首次成功；核心 CI 两平台首次均因缺少可选 psycopg 而在两项固定 SQL 组合测试失败。此前各 398 项三目标和旧 oracle/CLI 已执行通过，Native、打包与独立公开消费者尚未执行，不能借本地成绩补勾。见[独立首失败诊断](../verification/v3/independent-public-checkpoint-bb87f93-first-failure-2026-10-21.json)。修复是在核心 CI 安装原有 SHA 冻结驱动，保留原断言和失败运行，使用新提交重新验收。

修复提交 [f017c0d](https://github.com/HhWw96/moontxnwitness/commit/f017c0dfe6b8f69c58034046cf9e37c9e7614137) 的 [Windows/Linux 核心 CI](https://github.com/HhWw96/moontxnwitness/actions/runs/39547768317)和 [PostgreSQL CI](https://github.com/HhWw96/moontxnwitness/actions/runs/39547768346)均成功。独立 AI 从公开 artifact 新目录下载，核对两平台各 266 项非 dist 源码绑定、实际 core/capture 字节、Linux Native 398 项和各 68 项消费者；再执行两平台合计 332 项新消费者检查，见[公开验收收据](../verification/v3/independent-public-checkpoint-f017c0d-2026-10-21T05-19-32.336647Z.json)。列表 20,071 记录 / 10,118 不同输入另独立重算。两平台编译输出存在数值常量文本编码差异，分别记录原摘要，不归一化后声称字节相同。

以下首批 187 项和 CI 收据仅属于 `16ba355` 的历史公开底座。

### 首批公开底座收据

已从 `6f37245` 按[剩余执行计划](remaining-execution-plan.md)开发；当前切片契约见 [v3](v3-contract.md)。新增独立 `normalizeCaptureV3` / `analyzeV3` / `reduceV3` / `verifyV3`、对应 CLI 及 v3 复现包。MoonBit 区分不可变观察和可撤销写效果；同名保存点按实例处理，未知 COMMIT 不当作回滚，条件写和未映射 SQL 保持覆盖缺口。

首批公开下载收据记录其当时本地 JS、Wasm GC、Wasm **各 187 项**核心测试，以及原有 10,320 份历史、6,373 份环证据和 2,542 份解析差分。新增独立解释器 57 条轨迹及 SDK/CLI/证据 167 项检查；其中注册篡改变体 32 种。磁盘日志本地 55 项测试中 54 通过，因账户无法创建符号链接跳过 1 项；独立存储故障审计 10 项通过。

源码 [16ba355](https://github.com/HhWw96/moontxnwitness/commit/16ba3552f08d134f55795e6d95286c1d43a374ad) 的 [Windows/Linux 核心 CI](https://github.com/HhWw96/moontxnwitness/actions/runs/39534758059)与 [PostgreSQL CI](https://github.com/HhWw96/moontxnwitness/actions/runs/39534758057)均在首次运行通过。两平台各三目标 187 项，Linux Native 也为 187 项；CI 磁盘测试两平台均 55 项通过、无跳过。[独立 AI 公开下载验收](../verification/v3/independent-public-checkpoint-16ba355-2026-10-21T02-50-23.105113Z.json)核对 3 份实际 artifact 的 GitHub 摘要、两平台各 191 项源码绑定及真正下载的 core/capture/manifest/wrapper；在独立新目录用两个平台的下载运行文件完成 66 项检查，未借作者 dist/cache，也没有重新执行数据库或正式性能测量。此 CI 已上传实际编译 core，补齐前一实现只能核对运行时摘要的限制。

分段日志使用默认 4 MiB 队列、16 MiB 段、256 KiB 或 100 ms 同步、SQLite 磁盘事务索引及流式验证；4,100 个已完成事务的历史身份不会持续保留在内存集合中。独立审计实际发现并修复双重 IO 失败后误判完整、WAL 归档缺失和读取期间重开竞态。原失败、原 52 例冻结清单与参考解释器时态修正说明均保留在 [v3 证据目录](../verification/v3/)及 [修正记录](../fixtures/v3/protocol-correction-1.json)。

[PostgreSQL 18.6 的六个实际场景](../verification/v3/postgres-7b441738d1a545f4b8aefc0b9a421c5a/database-receipt.json)核对回滚前后自身读、释放子保存点后父回滚、重复名称恢复、重复回滚及游标位置；六份原始日志的 [MoonBit 核对及复现](../verification/v3/postgres-7b441738d1a545f4b8aefc0b9a421c5a/model-receipt.json)通过。原始 SQL 尚无映射证明，六份报告都保留 `unmapped_statement`，没有声称完整 SQL 分析。

这是共同底座的首批切片。旧驱动仍需迁到新存储；来源闭包窗口选择、安全清理、完整 dislock、ORM、多模型、最终性能和发布验收尚未完成。`prune` 保守拒绝删除全部来源，不能称来源 GC 已实现。技术验证按独立 AI 验收记录，真人反馈、生产采用及赛事审核仍分别记录。

## 已验收的前一实现基线

| 工作 | 当前证据 | 状态 |
| --- | --- | --- |
| 同步、异步 psycopg 采集 | 62 项驱动接口单元测试；一致快照、真实 fetch、提交/回滚、日志及聚合预算 | 已实现，本地通过 |
| MoonBit 跨目标回归 | JS / Wasm GC / Wasm / Linux Native 各 153 项；独立历史 10,320 份、环证据 6,373 份、解析差分 2,542 份 | 本地与独立 Windows / Linux CI 通过 |
| SDK / CLI | 原 75 项检查、14 项采集检查、新增 26 项 presence 检查 | 本地通过；失败或覆盖缺口不导出历史 |
| 稳定采集实测 | 7 个真实 PostgreSQL 场景、4 份复现包，异常缩至 2 事务 | 本地通过 |
| 原有数据库流程 | RR 及 Serializable 各 20 轮，3 份复现包 | 本地通过 |
| 既存行 SQL profile | 4 个场景、11 项拒绝、2 份复现包 | 实验，本地通过 |
| 冻结 dislock 业务切片 | 原 MIT 续约函数、7 个场景、4 份复现包，含真实 RC 锁等待后的 OLD 来源 | 本地通过；全应用采用未完成 |
| 普通表 CRUD / 负读 / 墓碑 | 6 个场景、10 项安装拒绝、8 项篡改检查、3 份复现包，写偏斜缩至 2 事务且单最小 | 实验，本地及独立审计通过 |
| 实验 Python 接口 | 22 项旧 profile、16 项 RETURNING、11 项冻结业务、22 项 presence | 本地通过；不是数据库执行次数 |
| 证据发布字节 | 2 份 dislock 收据与 1 份 presence 收据，共 84 项文件绑定 | 工作树、Git HEAD 与公开源码 ZIP 均逐字节核对通过 |
| 测试回执及打包 | 测试前后绑定可执行源码、JS / Python 包装层及运行文件摘要；旧回执打包被实际拒绝 | 已修复，完整回归通过 |
| 文件保存可靠性 | 9 项真实文件故障测试；原子替换、读回摘要、有界文件重试 | 通过；不重试计算来规避失败 |
| 同版本完整输出 | 20 / 20 份完整报告逐字节一致；15 份内部阶段编码中 8 份字节一致、7 份逻辑值一致 | 严格 35 项结果仍为 28 / 35，保留失败及独立解释 |
| 性能 | 新实现完成 20 个完整负载、15 个阶段、6,300 样本及 38 快照独立审计 | 20 / 20 原 P95 回退门槛通过；后续更高目标未全部达到 |
| 公开源码核对 | e6d57a1 的源码 ZIP：44 个 MoonBit 文件指纹、121 项测试源码摘要、84 项证据绑定 | 独立下载核验通过，8 项运行时摘要不冒充源码 ZIP 内编译文件 |
| 新实现独立 CI | e6d57a1 的两工作流、三任务及三份 artifact；各平台 121 项源码绑定、9 项文件故障、60 项消费者及真实 PostgreSQL 全链路 | 已下载摘要、日志及完整证据，逐项核验通过 |
| GitHub / Mooncakes 新稳定版 | 须完成适用发布门槛 | 尚未发布 |

前一实现的 MoonBit 源码指纹为 `c00c514defb7f551aae417245c5f6642284874cbdaf1a0fe77e717a433265bb1`，分析 core 为 `a8b94cd9e8db7a643523e7cd201ff5bce65b4382d25e41892cb6e431eebca3c3`，采集 core 为 `33c14cf537fb454e2177eaa17c4f7467c4c28316b9de04e1e8d4c9c665e57506`。本轮运行文件以新 summary 的逐路径摘要为准，不借用旧源码的 CI 或正式性能成绩。

## 普通表实验的完整证据

[最终 PostgreSQL 收据](../verification/provenance-presence/run-6089a462bdbd43e9ab80edc94b481c61/presence-receipt.json)包含实际 SQL、服务器结果、事务结局、审计来源、覆盖报告、历史、分析、缩减和复现包。它的 [独立审计](../verification/provenance-presence/run-6089a462bdbd43e9ab80edc94b481c61/independent-audit.json)重算 30 项文件绑定与 11 项源码绑定，并核对投射操作、回滚、数据库审计链及版本顺序；该审计本身没有重跑数据库。其他四套流程连同 presence 共 16 份复现包独立重放通过。

此能力仅支持固定已知文本键、规定的单表点读写模板、同步 tuple 游标以及受控安装窗口。不存在键也必须在初始键域内。存在性是单独采集的事实；版本前驱不是业务读取，身份 UUID 不是提交顺序。`normalizePresenceCapture` / `ingest-presence` 使用 traceSchema 2，旧入口继续拒绝它。详见 [实验契约及运行方式](../experiments/provenance/PRESENCE_PROFILE.md)。

## 性能及兼容性

固定公开 v0.1.0、同工具链、同输入、同完整输出。每场景 5 次预热、30 次样本、3 批独立进程，原 P95 门槛保持。上一实现的第六轮完整测量中，512 事务缩减 P95 已改善，但 sparse-512 与 small-cycle-noise-64 超限，因此整体失败。各轮原始结果及不可覆盖快照保留于 [性能诊断记录](../verification/releases/0.1.1/performance-v010-diagnosis.md)，不拼接通过项。

当前第七轮通过全部 20 个共同负载门槛，独立核对 120 份完整输出及 38 个快照；[完整审计](../verification/releases/0.1.1/performance-v010-formal-2026-10-20T15-55-43-611Z-persistence-audit.json)对应本页的 c00c… 源码。图组几何平均提速 1.236 倍、峰值 RSS 比 0.914；大型搜索组提速 1.329 倍，大型缩减组 1.515 倍。后续图组 1.3 倍 / RSS 0.8、搜索 1.5 倍及完整采集成本目标并未全部完成。

新实现的 20 份完整报告字节全部一致。7 份内部阶段对象的编码差异来自随机种子的 Map 桶布局；相同旧 core 的两个独立模块实例也能出现该差异。逐 key/value、插入顺序及其他字段核对一致，但严格字节失败记录没有改写，见 [单独评估](../verification/releases/0.1.1/common-paths-compatibility-assessment-2026-10-20T15-31-08-087Z.json)。内部对象编码不是公开报告契约，正式测量继续核对全部完整报告。

## 后续增强与历史验证边界

此前开发已有七项真实 dislock 生命周期和六条固定 SQL 来源证明；完整采集 C/A 成本、来源闭包窗口/保留及更广并发种子继续增强。v0.1.1 / v0.1.2 已按各自声明范围发布，不据此扩大到完整业务覆盖。零行条件等未证明路径继续无法判定。

完整采集 C/A 成本、并发锁/死锁、保留成本及更广业务验收分别记录。先前两种来源方案的 9,000 笔单客户端实测均有吞吐/延迟回退，不能只用 B/A 来源成本宣布完整采集达标。列表和 v3 保存点已有实验实现及独立证据；关系谓词、六类模型反证及 Elle 对照继续按[执行计划](remaining-execution-plan.md)推进。SQLAlchemy 局部来源诊断按本页所述范围交付，不等同完整 ORM 分析。

[上一实现的独立 CI 收据](../verification/releases/0.1.1/independent-ci-f76aebf.json)对应 f76aebf 的源码 4f1a5135…及 134 项核心测试。CI 未上传编译 core 原始字节，因此其中 core 摘要是运行时记录，不声称下载复算了二进制。其公共 GitHub 源码 ZIP 与 Windows 原始 27 项业务绑定已另行逐字节核验。

新实现的 [公开源码字节审计](../verification/releases/0.1.1/capture-public-bindings-e6d57a1.json)直接读取固定提交的 GitHub ZIP，全部 121 项非 dist 测试文件摘要与源码字节一致；84 项原始采集绑定也全部匹配。旧收据仍按各自执行时的构建摘要记录，不被改写为当前构建。3 份 presence capsule 使用匹配本地运行文件离线重放有效，该步骤没有重新执行数据库。

源码 e6d57a1 的 [核心 CI](https://github.com/HhWw96/moontxnwitness/actions/runs/39452756585)及 [PostgreSQL CI](https://github.com/HhWw96/moontxnwitness/actions/runs/39452756244)均通过。[新独立 CI 审计](../verification/releases/0.1.1/independent-ci-e6d57a1.json)核对三份下载产物的 GitHub 摘要、双平台测试与源码绑定、Linux Native，以及数据库的 22 项来源绑定、70 项当前产物绑定和 16 份复现包内部摘要/历史/报告。CI 未上传编译 core 字节的限制仍保留。后续文档及证据提交不改变这份已验实现的可执行源码摘要。

参赛者人工安装与解释验收尚未记录，组织方审核未重新提交；自动验证及公开仓库不代表官方通过或获奖。所有公开场景为受控测试数据，真实应用采集记录发布前仍需审查。
