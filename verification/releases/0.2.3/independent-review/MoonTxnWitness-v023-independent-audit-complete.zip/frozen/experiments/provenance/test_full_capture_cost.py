"""Full capture cost protocol unit checks, no PostgreSQL/network execution."""
import argparse
import importlib.util
import json
import os
from pathlib import Path
import random
import subprocess
import sys
import unittest
import uuid
ROOT=Path(__file__).resolve().parents[2]
spec=importlib.util.spec_from_file_location('capture_cost',ROOT/'experiments/provenance/full_capture_cost.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
BASE=Path(os.environ.get('MTW_JOURNAL_TEST_ROOT',str(ROOT/'artifacts/cost-runner-unit')))
RUN=BASE/('cost-'+uuid.uuid4().hex);RUN.mkdir(parents=True)


class Tests(unittest.TestCase):
    def args(self,**extra):return argparse.Namespace(quick=False,profile='column',workload='all',seed=123,**extra)
    def test_plan_has_four_workloads_three_batches_and_modes(self):
        p=m.plan(self.args());self.assertEqual(len(p['cells']),36)
        for cell in p['cells']:
            self.assertEqual((cell['warmupSeconds'],cell['durationSeconds'],cell['drainSeconds']),(15,60,30))
    def test_rotations_are_abc_bca_cab(self):
        cells=m.plan(self.args())['cells']
        for batch,order in enumerate(['ABC','BCA','CAB']):
            self.assertEqual(''.join(c['mode'] for c in cells if c['workload']=='serial' and c['batch']==batch),order)
    def test_quick_plan_never_claims_formal_measurement(self):
        args=self.args();args.quick=True;p=m.plan(args)
        self.assertFalse(p['formalPerformanceMeasurement'])
        self.assertTrue(all(c['quick'] for c in p['cells']))
    def test_workload_sequence_is_repeatable_across_modes(self):
        a,b=random.Random(123),random.Random(123);spec=m.WORKLOADS['hot']
        self.assertEqual([m.operation(a,spec) for _ in range(100)],[m.operation(b,spec) for _ in range(100)])
    def test_hot_updates_select_only_declared_key_domain(self):
        rng=random.Random(12);ops=[m.operation(rng,m.WORKLOADS['hot']) for _ in range(10000)]
        hot=sum(int(x['key'][4:])<4 for x in ops)
        self.assertTrue(8800<hot<9200)
        self.assertTrue(all(0<=int(x['key'][4:])<32 for x in ops))
    def test_crud_plan_preserves_four_actions_and_negative_reads(self):
        rng=random.Random(5);ops=[m.operation(rng,m.WORKLOADS['crud']) for _ in range(100)]
        self.assertEqual({x['action'] for x in ops},{0,1,2,3})
        self.assertTrue(all(x['missing'].startswith('missing-') for x in ops))
    def cells(self):
        result=[]
        for batch in range(3):
            for mode,tps,p95 in [('A',100,10),('B',1000,5),('C',50,20)]:
                result.append({'configuration':{'workload':'serial','batch':batch,'mode':mode},
                               'status':'passed','endToEndCommittedTps':tps,'allAttemptP95Ns':p95,
                               'formalProtocolCompleted':True,'captureBudgetExhausted':False})
        return result
    def test_comparison_uses_c_over_a_not_b_over_a(self):
        result=m.compare(self.cells())['serial']
        self.assertAlmostEqual(result['fullCaptureThroughputCOverA'],.5)
        self.assertAlmostEqual(result['fullCaptureP95COverA'],2)
        self.assertTrue(result['eligibleForTargets'])
    def test_incomplete_or_budget_exhausted_cell_is_ineligible(self):
        cells=self.cells();cells[2]['captureBudgetExhausted']=True
        self.assertFalse(m.compare(cells)['serial']['eligibleForTargets'])
        cells=self.cells();cells.pop()
        self.assertFalse(m.compare(cells)['serial']['eligibleForTargets'])
    def test_smoke_results_are_not_formal_targets(self):
        cells=self.cells()
        for c in cells:c['status']='smoke-passed';c['formalProtocolCompleted']=False
        self.assertFalse(m.compare(cells)['serial']['eligibleForTargets'])
    def test_plan_only_runs_without_database(self):
        out=RUN/'plan-only';env=dict(os.environ)
        env.pop('MTW_PG_DSN',None);env.pop('MTW_PG_CONNECTION_FILE',None)
        result=subprocess.run([sys.executable,'-B',m.__file__,'--output',str(out),'--plan-only'],env=env,capture_output=True)
        self.assertEqual(result.returncode,0,result.stderr.decode(errors='replace'))
        receipt=json.loads((out/'receipt.json').read_text())
        self.assertFalse(receipt['actualDatabaseExecution']);self.assertEqual(receipt['status'],'not-executed')
    def test_formal_without_exclusivity_is_not_executed(self):
        out=RUN/'no-exclusive'
        result=subprocess.run([sys.executable,'-B',m.__file__,'--output',str(out)],capture_output=True)
        self.assertEqual(result.returncode,3)
        self.assertFalse(json.loads((out/'receipt.json').read_text())['actualDatabaseExecution'])
    def test_missing_database_worker_is_not_executed(self):
        out=RUN/'no-db';config=RUN/'worker.json';config.write_text(json.dumps(m.plan(self.args())['cells'][0]))
        env=dict(os.environ);env.pop('MTW_PG_DSN',None);env.pop('MTW_PG_CONNECTION_FILE',None)
        result=subprocess.run([sys.executable,'-B',m.__file__,'--output',str(out),'--worker-config',str(config)],env=env,capture_output=True)
        self.assertEqual(result.returncode,3,result.stderr.decode(errors='replace'))
        self.assertEqual(json.loads((out/'receipt.json').read_text())['status'],'not-executed')


if __name__=='__main__':unittest.main(verbosity=2)
