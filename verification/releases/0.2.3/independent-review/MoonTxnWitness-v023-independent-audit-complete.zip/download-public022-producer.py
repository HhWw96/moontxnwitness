from pathlib import Path
import urllib.request,urllib.parse,hashlib,json,zipfile,time
b=Path(r'D:\CodexScratch\MoonTxnWitness-public023-independent-20261023');d=b/'public022-producer';d.mkdir();(d/'downloads').mkdir();runtime=d/'runtime';runtime.mkdir();result={'schema':1,'passed':False,'sourceTagCommit':'1ecd3ba204fb92d7c867e78991d7c68823a84d27','anonymous':True,'credentialRead':False,'files':[]}
assets=[('MoonTxnWitness-v0.2.2-SHA256SUMS.txt','https://github.com/HhWw96/moontxnwitness/releases/download/v0.2.2/MoonTxnWitness-v0.2.2-SHA256SUMS.txt',None,None),('MoonTxnWitness-v0.2.2-portable.zip','https://github.com/HhWw96/moontxnwitness/releases/download/v0.2.2/MoonTxnWitness-v0.2.2-portable.zip',39208760,'6c5015f2e67447e8431e97873fc1ac603ba95b4ae3203bded176ce35276adba4'),('registry.zip','https://download.mooncakes.io/user/HhWw96/moontxnwitness/0.2.2.zip',245481,'41743a05af7b25434200f570e81855afbe7e9c75c28bd26a2a037d5cbe0dc714')]
try:
 for name,url,size,expected in assets:
  p=d/'downloads'/name;h=hashlib.sha256();total=0
  with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'MoonTxnWitness-independent-public-review'}),timeout=45) as r,p.open('xb') as out:
   final=urllib.parse.urlsplit(r.url);assert final.scheme=='https' and final.hostname in ['github.com','release-assets.githubusercontent.com','objects.githubusercontent.com','download.mooncakes.io','d15l9c1mnzh3r.cloudfront.net'],final.hostname
   while chunk:=r.read(1024*1024):
    total+=len(chunk);assert total<=64*1024*1024;out.write(chunk);h.update(chunk)
  if size is not None:assert total==size
  if expected is not None:assert h.hexdigest()==expected
  item={'file':'downloads/'+name,'url':url,'finalHost':final.hostname,'bytes':total,'sha256':h.hexdigest(),'authorizationHeaderSent':False};result['files'].append(item);print(json.dumps(item),flush=True)
 sums=(d/'downloads'/assets[0][0]).read_text(encoding='utf8');assert '6c5015f2e67447e8431e97873fc1ac603ba95b4ae3203bded176ce35276adba4  MoonTxnWitness-v0.2.2-portable.zip' in sums
 with zipfile.ZipFile(d/'downloads'/assets[1][0]) as z:
  for i in z.infolist():
   p=Path(i.filename);assert not p.is_absolute() and '..' not in p.parts and ':' not in i.filename and '\\' not in i.filename and ((i.external_attr>>16)&0o170000)!=0o120000
  prefix='MoonTxnWitness-v0.2.2/dist/';result['producerFiles']={}
  for name in ['core.mjs','capture-core.mjs','sdk.mjs','evidence.mjs','build-manifest.json','THIRD_PARTY_NOTICES.txt']:
   raw=z.read(prefix+name);(runtime/name).write_bytes(raw);result['producerFiles'][name]={'archiveMember':prefix+name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
  assert result['producerFiles']['core.mjs']['sha256']=='3bf62e5c22d01f6c4b1110ee97bdf6376031fe17566a4d2f25037c5f17ff5911'
 with zipfile.ZipFile(d/'downloads/registry.zip') as z:
  result['registryEntries']=len(z.infolist());assert 'moon.mod' in z.namelist();mod=z.read('moon.mod').decode();assert '0.2.2' in mod
 result['passed']=True
except BaseException as ex:result['error']={'class':type(ex).__name__,'message':str(ex)}
(d/'download-first.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8');print(json.dumps({'passed':result['passed'],'error':result.get('error')}),flush=True)
