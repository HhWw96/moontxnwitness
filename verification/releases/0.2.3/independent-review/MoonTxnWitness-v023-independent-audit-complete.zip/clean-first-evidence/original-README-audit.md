# MoonTxnWitness v0.2.3 独立技术复核证据

本包保存全部独立首失败、后续修复验证、必要源码和实际运行文件，不代表真人验收、生产采用或赛事审核。

在全新的目录解压后，使用 Python 3.12+ 和 Node 24+ 运行：

```text
python replay-audit.py --node /absolute/path/to/node --output /absolute/path/to/new-empty-output
```

复核不联网、不编译、不启动数据库或正式性能测量。输出目录必须不存在。请将输出及临时目录放在容量充足的磁盘。

`audit-manifest.json` 对除自身以外的所有成员绑定原始字节。`final-current-source-bindings.json` 将最终集成文件明确映射到本包，包含三个只修改审计加载/历史来源绑定的辅助脚本覆盖。源码冻结前后的原文件均保留。

原始脚本故意保持不变，因此其中过强的异常返回值、字段名、25/24数量和 currentEngine 标签期待仍报告首失败；单独补充检查解释并验证正确契约，未修改原期待。`audit-summary.json` 给出各组原始/最终结果及边界。

六组 PostgreSQL 为开发者实际运行后的43文件原字节证据，本次独立复核读取全部日志段和 SQLite、核对生命周期与事实；独立复核者没有新运行数据库。

只有分段事件日志与可选分组来源日志使用有界 group-sync；生命周期日志仍保留 close flush/fsync 保证。归档保留来源，不宣称已实现任意窗口裁剪或删除。

实际 public22 portable 下载包的39MB原 ZIP 未重复嵌入；其不可变公开链接、字节摘要、真正提取的六个 producer 文件及 Mooncakes ZIP 均保留。SDK/CLI 与复现包复核可以完全离线运行。
