"""Independent protocol/retention tests: synthetic numbers, no cost measurement."""
from pathlib import Path
import sys,json,types,traceback,copy,math,importlib.util,hashlib
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT/'frozen/integrations/python'));sys.path.insert(0,str(ROOT/'cost-protocol/experiments/provenance'))
import full_capture_cost as cost,cell_archive as archive
from moontxnwitness_capture import journal_v3 as j
OUT=ROOT/'protocol-first';OUT.mkdir();cases=[];checks=0

def ck(x,msg):
 global checks
 assert x,msg;checks+=1

def save(name,v):(OUT/name).write_text(json.dumps(v,indent=2)+'\n',encoding='utf8')
def test(name,f):
 try:f();cases.append({'name':name,'passed':True})
 except BaseException as e:cases.append({'name':name,'passed':False,'message':str(e),'stack':traceback.format_exc()})
def cells():
 return [{'configuration':{'workload':'serial','batch':b,'mode':mode},'status':'passed','endToEndCommittedTps':tps,'allAttemptP95Ns':p95,'formalProtocolCompleted':True,'captureBudgetExhausted':False,'failures':0,'protocolFailures':[]} for b in range(3) for mode,tps,p95 in [('A',100,100),('B',10,500),('C',95,110)]]

def planning():
 a=types.SimpleNamespace(quick=False,workload='all',profile='column',seed=20261023,archive_cells=True,max_cells=3);p=cost.plan(a);save('plan.json',p);ck(len(p['cells'])==36,'plan lost cells');ck(set(cost.WORKLOADS)=={'serial','parallel','hot','crud'},'four workloads differ');ck(all((c['warmupSeconds'],c['durationSeconds'],c['drainSeconds'])==(15,60,30) for c in p['cells']),'timing changed');ck(p['orders']==[['A','B','C'],['B','C','A'],['C','A','B']],'batch orders changed');ck(p['maximumCellsThisInvocation']==3,'prefix changed plan');ck(p['sourceSemanticsCertified'] is False,'cost certifies source semantics')
test('36 preregistered cells retain timing, four workloads and three ABC orders',planning)

def ratios():
 r=cost.compare(cells())['serial'];ck(math.isclose(r['fullCaptureThroughputCOverA'],.95),'used B/A instead of C/A');ck(math.isclose(r['fullCaptureP95COverA'],1.1),'wrong P95 ratio');ck(r['eligibleForTargets'] and r['performanceTargetsPassed'],'valid synthetic complete comparison lost')
test('comparison uses C/A and preserves distinct B/A',ratios)

def invalid_cells():
 for change in ['missing','budget','failed','quick']:
  x=cells()
  if change=='missing':x.pop()
  elif change=='budget':x[2]['captureBudgetExhausted']=True
  elif change=='failed':x[2]['status']='failed'
  else:
   for c in x:c['status']='smoke-passed';c['formalProtocolCompleted']=False
  ck(cost.compare(x)['serial']['eligibleForTargets'] is False,change+' admitted for targets')
test('missing, failed, budget-exhausted and quick cells stay ineligible',invalid_cells)

def sql_failures():
 x=cells();x[2]['failures']=1;x[2]['sqlstateCounts']={'23505':1}
 r=cost.compare(x)['serial'];save('sql-failure-comparison.json',{'syntheticInput':x,'actualComparison':r,'scope':'Synthetic aggregation counterexample; no database/performance experiment executed'});ck(r['eligibleForTargets'] is False,'SQL failure count ignored for target eligibility despite original plan/doc requiring SQL failures ineligible')
test('SQL-failed attempts cannot silently qualify a strict target result',sql_failures)

def percentile():
 all_attempts=[100,200,50000];committed=[100,200];ck(cost.nearest_rank(all_attempts,.95)==50000,'failed slow attempt excluded from P95');ck(cost.nearest_rank(committed,.95)==200,'control percentile')
test('all-attempt percentile includes failed slow attempts',percentile)

def archive_restore():
 run=OUT/'archive-run';cell=run/'cell-0';cell.mkdir(parents=True);(cell/'sub').mkdir();(cell/'sub/raw.bin').write_bytes(bytes(range(256))*3);(cell/'receipt.json').write_text(json.dumps({'status':'failed','formalProtocolCompleted':False}),encoding='utf8');before={p.relative_to(cell).as_posix():p.read_bytes() for p in cell.rglob('*') if p.is_file()};pointer=archive.archive_cell(run,cell);ck(all((cell/k).read_bytes()==v for k,v in before.items()),'archive modified raw files');arc=run/pointer['archive'];verified=archive.verify_archive(arc,expected_sha256=pointer['archiveSha256']);ck(verified['manifest']['cellStatus']=='failed','failure archive rewritten as passing');restored=OUT/'archive-restored';archive.restore_archive(arc,restored,expected_sha256=pointer['archiveSha256']);ck(all((restored/k).read_bytes()==v for k,v in before.items()),'restored original bytes differ')
 # Release only this exact synthetic owned fixture after a verified archive.
 ck(cell.resolve().parent==run.resolve() and cell.resolve().is_relative_to(OUT.resolve()),'release boundary');released=archive.release_cell(run,cell,pointer);ck(released['rawReleased'] is True and (cell/'archive-pointer.json').is_file(),'release pointer missing');ck(set(p.name for p in cell.iterdir())=={'archive-pointer.json'},'release left/removed unexpected fixture');save('retention-pointer.json',released)
test('terminal failed cells archive and restore byte-for-byte before owned release',archive_restore)

def changed_raw_retained():
 run=OUT/'changed-run';cell=run/'cell-0';cell.mkdir(parents=True);(cell/'receipt.json').write_text('{"status":"passed"}',encoding='utf8');(cell/'keep.bin').write_bytes(b'original');pointer=archive.archive_cell(run,cell);(cell/'keep.bin').write_bytes(b'changed')
 try:archive.release_cell(run,cell,pointer)
 except ValueError:ck((cell/'keep.bin').read_bytes()==b'changed','changed original deleted')
 else:raise AssertionError('changed source released against stale archive')
test('changed raw cells refuse release and preserve originals',changed_raw_retained)

def prune_contract():
 path=OUT/'retained-journal';x=j.SegmentedJournal(path);x.append({'seq':1,'time':1,'kind':'snapshot','consistent':True,'initial':{}});ck(x.close(source_closed=True).complete,'setup journal incomplete');before={p.name:p.read_bytes() for p in path.iterdir() if p.is_file()};r=x.prune(before_seq=1);save('prune-result.json',r);ck(r['implemented'] is False and r['deleted']==[],'prune was implemented unexpectedly');ck(before=={p.name:p.read_bytes() for p in path.iterdir() if p.is_file()},'prune changed original source')
test('published prune result explicitly retains every source file',prune_contract)

r={'schema':1,'passed':all(c['passed'] for c in cases),'groups':len(cases),'checks':checks,'cases':cases,'sourceCommit':'8952886','actualDatabaseExecution':False,'formalPerformanceMeasurement':False,'originalDurabilityPruneExpectationUnchanged':True};save('receipt.json',r);print(json.dumps(r));sys.exit(0 if r['passed'] else 1)
