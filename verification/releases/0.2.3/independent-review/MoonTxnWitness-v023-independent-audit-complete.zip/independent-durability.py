"""Independent v0.2.3 small-file/fault tests, frozen Git source only."""
from pathlib import Path
import sys,os,json,hashlib,time,threading,dataclasses,traceback,shutil,gc
from unittest.mock import patch
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT/'frozen/integrations/python'))
from moontxnwitness_capture import source_sink as s,journal_v3 as j
from moontxnwitness_capture._orm_source_sink import SourceSink,verify as legacy_verify
from moontxnwitness_capture._durable_policy import CapacityQueue
OUT=ROOT/'challenge-first';OUT.mkdir();cases=[];checks=0

def ck(x,msg):
 global checks
 assert x,msg;checks+=1

def save(name,x):
 p=OUT/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n',encoding='utf8')

def test(name,f):
 try:f();cases.append({'name':name,'passed':True})
 except BaseException as e:cases.append({'name':name,'passed':False,'error':type(e).__name__,'message':str(e),'stack':traceback.format_exc()})

def sink(name,**kw):return s.GroupedSourceSink(OUT/(name+'.jsonl'),**kw)
def closed(x):
 try:x.close()
 except (s.SourceSinkError,j.JournalError):pass
class FileProxy:
 def __init__(self,raw,mode='short',entered=None,release=None):self.raw,self.mode,self.entered,self.release=raw,mode,entered,release
 def write(self,data):
  if self.mode=='short':return self.raw.write(data[:max(1,min(3,len(data)))])
  if self.mode=='zero':return 0
  if self.mode=='diskfull':raise OSError(28,'Independent disk-full injection')
  if self.mode=='block':
   self.entered.set()
   if not self.release.wait(5):raise TimeoutError('Independent writer gate expired')
  return self.raw.write(data)
 def __getattr__(self,name):return getattr(self.raw,name)
 def __enter__(self):return self
 def __exit__(self,*args):return self.raw.__exit__(*args)

def queue_accounting():
 q=CapacityQueue(512);q.reserve(256);q.enqueue(('owned',),160);q.release_reservation(256);ck(q.used_bytes==160,'reserved bytes not released');ck(q.pop()==('owned',) and q.used_bytes==160,'in-flight charge disappeared');ck(not q.can_reserve(400),'capacity ignored in-flight');q.complete(160);ck(q.used_bytes==0,'completion leaked capacity')
test('capacity retains in-flight bytes and separates reservations',queue_accounting)

def admission():
 x=sink('admission',flush_interval=60,flush_bytes=1024*1024)
 try:
  r=x.append({'kind':'source-batch','value':'accepted is not durable'});ck(r.accepted and r.durable_seq<r.source_seq,'admission claimed durability');ck(x.flush()>=r.source_seq,'flush did not acknowledge accepted prefix');status=x.close();ck(status['storageSealed'] and status['durableSourceSeq']==3,'close omitted seal/tail');ck(status['completeCapture'] is False and status['coreProofAccepted'] is False,'storage promoted semantics');save('admission-status.json',status)
 finally:closed(x)
test('admission, explicit watermark and close tail remain distinct',admission)

def same_wire():
 x=sink('wire');old=SourceSink(OUT/'legacy-wire.jsonl');records=[{'kind':'source-batch','value':['事务','0.2.0',None,True,17]},{'kind':'installation','mapping':'a|b\\quote"😀'},{'kind':'source-gap','reason':'observed gap'}]
 try:
  for record in records:ck(x.append(record).accepted,'group append refused');old.append(record)
  old.close();a=x.close();ck(x.path.read_bytes()==old.path.read_bytes(),'wire changed from legacy SourceSink');ck(legacy_verify(x.path)['sha256']==a['sha256'],'legacy verifier differs');save('wire-status.json',a)
 finally:closed(x);old.close()
test('grouped and legacy SourceSink produce identical raw wire bytes',same_wire)

def partial_write():
 x=sink('positive-short-write');x.flush();x._file=FileProxy(x._file,'short')
 try:
  ck(x.append({'kind':'source-batch','value':'small partial chunks'}).accepted,'append refused');r=x.close();ck(r['storageSealed'],'legal short data writes not completed');ck(s.verify_grouped_source(x.path)['sha256']==r['sha256'],'short-write data differs')
 finally:closed(x)
test('positive short data writes complete without byte loss',partial_write)

def source_failure(mode):
 x=sink('source-'+mode);x.flush();x._file=FileProxy(x._file,mode)
 try:
  ck(x.append({'kind':'source-batch','value':mode}).accepted,'fault ran before admission')
  try:x.flush()
  except s.SourceSinkError:ck(True,'sync failure visible')
  else:raise AssertionError('faulted source flush acknowledged durability')
  ck(x.lock_path.exists(),'writer guard lost on failed IO');ck(x.failure_path.exists(),'failure marker missing')
  try:s.verify_grouped_source(x.path)
  except s.SourceSinkError:ck(True,'failed source refused')
  else:raise AssertionError('failed source verified as sealed')
 finally:closed(x)
for mode in ['zero','diskfull']:test('source '+mode+' write leaves failure and writer guards',lambda mode=mode:source_failure(mode))

def fsync_failure():
 x=sink('source-fsync');x.flush();fd=x._file.fileno();original=os.fsync
 def bad(n):
  if n==fd:raise OSError(5,'Independent data fsync failure')
  return original(n)
 try:
  with patch.object(os,'fsync',bad):
   r=x.append({'kind':'source-batch','value':'must not be durable'});ck(r.accepted,'append unexpectedly refused')
   try:x.flush()
   except s.SourceSinkError:ck(True,'fsync failure visible')
   else:raise AssertionError('failed fsync acknowledged durability')
  ck(x._durable_seq<r.source_seq,'watermark advanced after failed fsync')
 finally:closed(x)
test('failed source fsync cannot advance durable prefix',fsync_failure)

def backpressure():
 x=sink('backpressure',max_queue_bytes=512,max_record_bytes=256,flush_interval=60,flush_bytes=4096);x.flush();entered=threading.Event();release=threading.Event();x._file=FileProxy(x._file,'block',entered,release);accepted=[]
 def produce():
  for n in range(10):accepted.append(x.append({'kind':'source-batch','n':n,'payload':'x'*80}))
 t=threading.Thread(target=produce)
 try:
  t.start();ck(entered.wait(2),'writer did not reach gate');time.sleep(.05);ck(t.is_alive(),'producer not backpressured');ck(x._capacity.used_bytes<=512,'queue exceeded byte cap');release.set();t.join(5);ck(not t.is_alive() and len(accepted)==10,'backpressure never released');r=x.close();ck(r['storageSealed'],'backpressured source not sealed');ck(r['stats']['backpressureCount']>0 and r['stats']['backpressureNs']>0,'backpressure not measured');ck(r['stats']['maxQueueBytes']<=512,'reported queue exceeded budget');save('backpressure-status.json',r)
 finally:release.set();t.join(5);closed(x)
test('full source queue applies real measurable producer backpressure',backpressure)

def corruption():
 x=sink('corruption-original');x.append({'kind':'source-batch','value':71});x.close()
 for label in ['data','seal','index']:
  p=OUT/('corrupt-'+label+'.jsonl');shutil.copyfile(x.path,p);idx=Path(str(p)+'.index.json');shutil.copyfile(x.index,idx)
  if label=='data':p.write_bytes(p.read_bytes().replace(b'"value":71',b'"value":72'))
  if label=='seal':p.write_bytes(p.read_bytes()[:-3])
  if label=='index':a=json.loads(idx.read_text());a['bytes']+=1;idx.write_text(json.dumps(a),encoding='utf8')
  try:s.verify_grouped_source(p)
  except (s.SourceSinkError,ValueError):ck(True,label+' refused')
  else:raise AssertionError(label+' corruption accepted')
test('changed data/index and truncated seal remain visible',corruption)

def no_growth():
 x=sink('bounded',max_queue_bytes=2048,max_record_bytes=256)
 try:
  for i in range(500):ck(x.append({'kind':'source-batch','ordinal':i}).accepted,'bounded append refused')
  r=x.close();ck(not hasattr(x,'_events'),'unbounded events copy exists');ck(not x._capacity.items and x._capacity.used_bytes==0,'closed queue retained records');ck(r['records']==502 and r['stats']['maxQueueBytes']<=2048,'bounded stats mismatch');save('bounded-status.json',r)
 finally:closed(x)
test('source queue releases records without an in-memory event history',no_growth)

def source_postclose_marker_failure():
 x=sink('postclose-marker-failure');initial=x.close();ck(initial['storageSealed'],'setup source not sealed');original=Path.open
 def opened(path,*args,**kw):
  if path==x.invalidated_path:raise OSError(28,'Independent invalidation marker disk-full')
  return original(path,*args,**kw)
 with patch.object(Path,'open',opened):r=x.append({'kind':'source-batch','later':'refused'})
 ck(not r.accepted and r.gap is not None,'post-close refusal missing');result=x.close();save('postclose-known-refusal.json',{'append':dataclasses.asdict(r),'closeAfterKnownMarkerFailure':result,'inMemoryGaps':x._gaps});ck(result['storageSealed'] is False,'same source object returned sealed after known post-close refusal with failed marker')
test('known post-close refusal cannot regain sealed status when marker IO fails',source_postclose_marker_failure)

def journal_short_index():
 path=OUT/'journal-short-index';x=j.SegmentedJournal(path,flush_interval=60,flush_bytes=65536)
 x.append({'seq':1,'time':1,'kind':'snapshot','consistent':True,'initial':{}});x.flush();original=Path.open
 def opened(path,*args,**kw):
  f=original(path,*args,**kw)
  return FileProxy(f,'short') if path.parent==x.path and path.name.startswith('.journal-index-') and args and args[0]=='wb' else f
 try:
  with patch.object(Path,'open',opened):
   x.append({'seq':2,'time':2,'kind':'begin','tx':'T','connection':'C'});x.append({'seq':3,'time':3,'kind':'rollback_ok','tx':'T'})
   try:
    durable=x.flush();raw=(x.path/'journal-index.json').read_bytes();(OUT/'journal-index-while-acked.bin').write_bytes(raw);save('journal-index-ack.json',{'durableSeq':durable,'bytes':len(raw)})
    try:meta=json.loads(raw)
    except ValueError:raise AssertionError('journal flush acknowledged a torn short-written index')
    ck(meta['durableSeq']>=3,'acknowledged index does not bind prefix')
   except j.JournalIOError:ck(True,'short index write explicitly failed')
 finally:
  try:x.close(source_closed=True)
  except j.JournalError:pass
test('journal flush requires a complete synchronized index despite short writes',journal_short_index)

def journal_retains_sources():
 p=OUT/'journal-retention';x=j.SegmentedJournal(p,flush_interval=60);events=[{'seq':1,'time':1,'kind':'snapshot','consistent':True,'initial':{}}]
 for e in events:ck(x.append(e).accepted,'journal append refused')
 status=x.close(source_closed=True);ck(status.complete,'complete source not sealed');before={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in p.iterdir() if f.is_file()};x.archive(OUT/'journal-preserved.zip');j.JournalReader(p).export(OUT/'retained-trace.json',clock_domain='independent-retention',exclusive_writers=True)
 try:x.prune(before_seq=1)
 except j.JournalError:ck(True,'pruning refused')
 else:raise AssertionError('unproven source deletion allowed')
 after={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in p.iterdir() if f.is_file()};ck(before==after,'archive/export/prune changed original sources')
test('sealed source export/archive never deletes original evidence',journal_retains_sources)

r={'schema':1,'version':'0.2.3-frozen','sourceCommit':'273a3deb24c6d02a49b3772541ce9162d5c565d0','passed':all(x['passed'] for x in cases),'groups':len(cases),'checks':checks,'cases':cases,'actualDatabaseExecution':False,'formalPerformanceMeasurement':False,'scope':'Independent small files, controlled queue gates and IO fault injection; no Moon/DB/benchmark'}
save('receipt.json',r);print(json.dumps(r));sys.exit(0 if r['passed'] else 1)
