"""Independent frozen integrated-v23 evidence and exact source delta verification; no live database."""
from pathlib import Path
import sys,json,hashlib,ast,dataclasses,traceback,os,shutil
BASE=Path(__file__).resolve().parent;ROOT=BASE/'integrated-final';OUT=BASE/'integrated-final-first';OUT.mkdir();scratch=OUT/'scratch';scratch.mkdir();os.environ['MTW_JOURNAL_SCRATCH']=str(scratch)
sys.path.insert(0,str(ROOT/'integrations/python'))
from moontxnwitness_capture.journal_v3 import JournalReader,JournalVerificationError
checks=0;cases=[]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def ck(x,msg):
 global checks
 assert x,msg;checks+=1
def test(name,fn):
 try:fn();cases.append({'name':name,'passed':True})
 except BaseException as e:cases.append({'name':name,'passed':False,'error':type(e).__name__,'message':str(e),'stack':traceback.format_exc()})
def save(name,v):(OUT/name).write_bytes((json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode())
manifest=json.loads((ROOT/'snapshot-manifest.json').read_bytes());E=ROOT/'verification/capture-instrumentation/v023-validation-fix';ad=json.loads((E/'adoption.json').read_bytes());original=json.loads((E/'receipt.json').read_bytes())
def frozen_integrity():
 for f in manifest['files']:ck((ROOT/f['file']).stat().st_size==f['bytes'] and sha(ROOT/f['file'])==f['sha256'],f['file'])
 ck(sha(E/'adoption.json')=='3eb7169328deb6fb7d7fc04dca34c8c08e543750f9529f49bb41bdba21f0f864','adoption');ck(len(ad['files'])==43,'full raw closure')
 for name,value in ad['sourceBindings'].items():ck(sha(ROOT/name)==value,name)
 ck(ad['completeModelCoverageClaimed'] is False and ad['actualDatabaseExecution'] is True and ad['formalPerformanceMeasurement'] is False,'producer claim scope')
test('immutable integrated source and 43 original PostgreSQL files',frozen_integrity)
def delta():
 for name in ['source_sink.py','journal_v3.py','_durable_policy.py','capture_v3.py','capture.py','_orm_raw_async.py']:
  ck((ROOT/'integrations/python/moontxnwitness_capture'/name).read_bytes()==(BASE/'postfix-60afa17/frozen/integrations/python/moontxnwitness_capture'/name).read_bytes(),'unreviewed delta '+name)
 ck((ROOT/'experiments/provenance/full_capture_cost.py').read_bytes()==(BASE/'postfix-60afa17/cost-protocol/experiments/provenance/full_capture_cost.py').read_bytes(),'cost changed')
 old=ast.parse((BASE/'frozen/integrations/python/moontxnwitness_capture/instrumentation.py').read_bytes());new=ast.parse((ROOT/'integrations/python/moontxnwitness_capture/instrumentation.py').read_bytes())
 a=next(n for n in old.body if isinstance(n,ast.FunctionDef)and n.name=='instrument_psycopg');b=next(n for n in new.body if isinstance(n,ast.FunctionDef)and n.name=='instrument_psycopg')
 # Public argument guards are the sole integration delta to the already reviewed 273 instrumentation.
 new.body[new.body.index(b)]=a;ck(ast.dump(old,include_attributes=False)==ast.dump(new,include_attributes=False),'unreviewed instrumentation module delta')
 ck(any(isinstance(n,ast.Raise) for n in ast.walk(b)),'argument guard missing')
 save('argument-guard-function.json',{'before':ast.unparse(a),'after':ast.unparse(b),'scope':'Only instrument_psycopg function differs from the independently frozen 273 module; remaining module AST identical.'})
 old38=BASE.parent/'MoonTxnWitness-public021-independent-20261023-8da7e3f5/v022-independent/frozen/integrations/python/tests/test_instrumentation.py'
 # All original test functions in pre-existing first 273 comparison remain bound in this closure.
 prior=json.loads((BASE/'original-38-ast-comparison.json').read_bytes());ck(prior.get('originalMethodsUnchanged',prior.get('passed',False)) is not False,'original comparison')
test('only reviewed persistence fix and retained argument guard enter integrated producer',delta)
for name in ['native-sync','native-async','engine-sync','engine-async','lost-commit-sync','lost-commit-async']:
 def case(name=name):
  folder=E/name;before={p.relative_to(folder).as_posix():sha(p)for p in folder.rglob('*')if p.is_file()};reader=JournalReader(folder/'journal');status=reader.verify();save(name+'-journal-verification.json',status.as_dict());ck(status.valid and not status.complete,'diagnostic storage validity and incompleteness');events=list(reader.iter_events(require_complete=False));trace=json.loads((folder/'trace.json').read_bytes());ck(events==trace['events'],'streamed raw events changed');ck(trace['scope']['exclusiveWriters']is False and trace['gaps'],'diagnostic scope lost');ck(not any(e['kind'] in ('read','write','condition') for e in events),'unsupported model fact fabricated')
  life=(folder/'lifecycle.jsonl').read_bytes();lines=life.splitlines(keepends=True);records=[json.loads(l)for l in lines];interval=json.loads((folder/'interval-evidence.json').read_bytes());ck(interval['sourceTraceSha256']==sha(folder/'trace.json'),'trace binding');ck(interval['sourceLifecycleSha256']==sha(folder/'lifecycle.jsonl'),'lifecycle binding');ck(interval['sourceJournalIndexSha256']==sha(folder/'journal/journal-index.json'),'index binding');ck(interval['records']==records,'interval observations altered');ck(records[-1]['kind']=='seal' and records[-1]['prefixSha256']==hashlib.sha256(b''.join(lines[:-1])).hexdigest(),'tail seal/prefix');ck(records[-1]['records']==len(records)-1 and [x['seq']for x in records]==list(range(1,len(records)+1)),'lifecycle sequence')
  try:reader.export(OUT/(name+'-must-refuse-export.json'),clock_domain=trace['clockDomain'])
  except JournalVerificationError:ck(True,'')
  else:raise AssertionError('diagnostic journal exported as complete')
  if name.startswith('lost-commit'):
   kinds=[e['kind']for e in events];ck('commit_request'in kinds and 'disconnect'in kinds and 'commit_ok'not in kinds and 'rollback_ok'not in kinds,'lost COMMIT became conclusive');detail=next(x['detail']for x in original['cases']if x['name']==name);ck(detail['collectorOutcome']=='unknown' and detail['actualBusinessWriteCommitted']is True,'retained server/client distinction')
  after={p.relative_to(folder).as_posix():sha(p)for p in folder.rglob('*')if p.is_file()};ck(before==after,'evidence changed while consuming')
 test('original PostgreSQL full journal read and lifecycle '+name,case)
def tamper():
 src=E/'native-sync/journal';dst=OUT/'tampered-journal';shutil.copytree(src,dst);q=dst/'segment-000001.jsonl';q.write_bytes(q.read_bytes()[:-1]);ck(JournalReader(dst).verify().valid is False,'truncated raw segment accepted')
 dst2=OUT/'tampered-index';shutil.copytree(src,dst2);q=dst2/'journal-index.json';x=json.loads(q.read_bytes());x['durableSeq']+=1;q.write_bytes(json.dumps(x).encode());ck(JournalReader(dst2).verify().valid is False,'changed index accepted')
test('independently truncated real segment and changed index fail visible',tamper)
r={'schema':1,'passed':all(x['passed']for x in cases),'groups':len(cases),'checks':checks,'cases':cases,'adoptionSha256':sha(E/'adoption.json'),'actualDatabaseExecutionByReviewer':False,'formalPerformanceMeasurement':False,'scope':'Exact source binding and independent read-only verification of producer-executed six PostgreSQL cases including all 43 raw files. No new database execution or complete isolation coverage claimed.','limitations':['Lifecycle log remains buffered file append with close flush/fsync; not the 4MiB grouped queue.','Old 273 published evidence omitted segment files; that older limitation is retained. New evidence is a distinct complete-byte closure.','Arbitrary source-closed subwindow export and pruning are not implemented; retain sources.']};save('receipt.json',r);print(json.dumps(r));sys.exit(0 if r['passed']else 1)
