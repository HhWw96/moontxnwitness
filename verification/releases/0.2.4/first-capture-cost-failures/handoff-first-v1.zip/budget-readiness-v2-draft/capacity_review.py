"""Static capacity/readiness assessment; no database, timing, or protocol edits.

A one-million measured-attempt ceiling is evaluated, not silently made active.
The current collector's source/lifecycle hard limits remain untouched.
"""
from pathlib import Path
import hashlib
import json
import math

BASE=Path(__file__).resolve().parent
TASK=BASE.parent
CELL=TASK/'results-first/column/metadata/nested/archives/cell-0.zip/receipt.json'
EXPECTED_CELL_SHA='3b968ceb631fb72687022c707eb93eacf7d3dcccc93ebc6e21e9cf9113dffb24'
LIMITS={'sourceRecords':1_000_000,'sourceBytes':1024**3,'lifecycleRecords':2_000_000,'lifecycleBytes':512*1024**2,'journalBytes':1024**3,'sqliteIndexBytes':2*1024**3,'sourceQueueBytes':4*1024**2,'journalQueueBytes':4*1024**2,'reserveBytes':512*1024**2}
WORKLOADS={'serial':{'keys':4096,'connections':1},'parallel':{'keys':4096,'connections':4},'hot':{'keys':32,'connections':8},'crud':{'keys':4096,'connections':4}}
ORDERS=(('A','B','C'),('B','C','A'),('C','A','B'))

def source_count(total_transactions,keys):
    # Every successful cost workload transaction observes one business key and
    # one initialized missing key. Initial entries + header/seal are additional.
    # Final audit batching adds further records, intentionally not subtracted.
    return 2*total_transactions+keys+32+2

def assess(cell,measured_cap=1_000_000):
    issue_plus_tail=cell['endToEndWallNs']/1e9
    per_worker_rate=cell['attempts']/issue_plus_tail
    measured_projection=math.ceil(per_worker_rate*60)
    warm_projection=cell['warmupAttempts']
    workloads={}
    for name,spec in WORKLOADS.items():
        tx=spec['connections']*(measured_projection+warm_projection)
        # Serial projection only; no assumption that concurrency scales, and no
        # measured B/C throughput. Linear scaling is an explicit sizing stress.
        lifecycle_floor=9*tx if name!='crud' else None
        workloads[name]={'connections':spec['connections'],'linearAProjectionSizingOnly':True,'projectedTotalIncludingWarmup':tx,'readSourceRecordsLowerBound':source_count(tx,spec['keys']),'sourceRecordLimitSufficientAtProjection':source_count(tx,spec['keys'])<=LIMITS['sourceRecords'],'successfulNonCrudLifecycleRecordsLowerBound':lifecycle_floor,'lifecycleRecordLimitSufficientAtProjection':None if lifecycle_floor is None else lifecycle_floor<=LIMITS['lifecycleRecords']}
    # Warmup has no cap in frozen v1: no finite measured-attempt cap alone can
    # guarantee total event/source/storage sufficiency even before sizing.
    return {'schema':1,'kind':'full-capture-cost-capacity-review/v2-draft','sourceCommit':'bf28179a40aa2d1325f4f1484acb30362eea4f18','originalCellSha256':EXPECTED_CELL_SHA,'oldMeasuredAttemptCapPerWorker':100000,'candidateMeasuredAttemptCapPerWorker':measured_cap,'candidatePerWorker60sCeilingTps':measured_cap/60,'observedSingleWorkerRateIncludingTailTps':per_worker_rate,'headroomOverProjected60sAttempts':measured_cap/measured_projection,'projected60sAttemptsPerWorker':measured_projection,'observedWarmupAttemptsPerWorker':warm_projection,'warmupBoundedByTimeButNotAttemptCount':True,'collectorLimitsUnchanged':LIMITS,'sizingOnly':workloads,'readSourceTransactionCeilingIgnoringFinalAudit':(LIMITS['sourceRecords']-4096-32-2)//2,'successfulNonCrudLifecycleTransactionCeilingIgnoringHeaderAndConnections':LIMITS['lifecycleRecords']//9,'readyForFormalExecution':False,'notReadyReasons':['A-only evidence does not establish B/C throughput or serialized bytes per transaction.','Increasing measured attempt cap alone does not bound warmup record count.','Source record and lifecycle count ceilings already fail the 4/8-connection linear sizing stress; bytes may fail sooner.','No measured capture/journal/index/database/WAL/archive total or full-36-cell disk bound has been validated.'],'scope':'Sizing stress is neither a throughput prediction nor a performance result. No collector default, old plan, target eligibility rule, or expected SQLSTATE changed. Original exhaustion remains failed.'}

def draft_plan(profile):
    cells=[]
    for name,spec in WORKLOADS.items():
        for batch,order in enumerate(ORDERS):
            for mode in order:
                cells.append({'workload':name,'batch':batch,'mode':mode,'profile':profile,'seed':20261023+batch*10000,'warmupSeconds':15,'durationSeconds':60,'drainSeconds':30,'candidateMaxAttemptsPerWorker':1_000_000,'activeWarmupAttemptCeiling':None,'collectorLimitsUnchanged':LIMITS,'executable':False})
    return {'schema':1,'kind':'non-executable-capacity-candidate-plan/v2-draft','status':'not-ready','profile':profile,'frozenSource':'bf28179a40aa2d1325f4f1484acb30362eea4f18','cells':cells,'targetsUnchanged':{'fullCaptureThroughputCOverAAtLeast':.90,'fullCaptureP95COverAAtMost':1.15},'formalPerformanceMeasurement':False,'actualDatabaseExecution':False,'requires':'Explicit bounded warmup/streaming retention design and validated byte/count/disk capacity before implementation or dispatch.'}

if __name__=='__main__':
    raw=CELL.read_bytes();assert hashlib.sha256(raw).hexdigest()==EXPECTED_CELL_SHA
    cell=json.loads(raw)
    output=assess(cell)
    (BASE/'assessment.json').write_text(json.dumps(output,indent=2)+'\n',encoding='utf8')
    manifest={}
    for profile in ('column','sidecar'):
        file=BASE/('candidate-plan-'+profile+'.json')
        file.write_text(json.dumps(draft_plan(profile),indent=2)+'\n',encoding='utf8')
        manifest[file.name]=hashlib.sha256(file.read_bytes()).hexdigest()
    (BASE/'frozen-draft-manifest.json').write_text(json.dumps({'schema':1,'candidatePlans':manifest,'executable':False,'sourceCell':EXPECTED_CELL_SHA,'analysisScriptSha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()},indent=2)+'\n',encoding='utf8')
    print(json.dumps({'assessment':str(BASE/'assessment.json'),'ready':False,'projectedAttempts':output['projected60sAttemptsPerWorker'],'headroom':output['headroomOverProjected60sAttempts'],'workloads':output['sizingOnly']}))
