"""Bounded static checks only; these do not certify formal capacity."""
import json
import unittest
from capacity_review import assess,draft_plan,source_count,LIMITS,CELL
class Tests(unittest.TestCase):
    def setUp(self):self.cell=json.loads(CELL.read_text(encoding='utf8'))
    def test_original_exhaustion_remains_failed(self):
        self.assertEqual(self.cell['status'],'failed');self.assertFalse(self.cell['formalProtocolCompleted'])
        self.assertEqual(self.cell['protocolFailures'][0]['errorClass'],'AttemptBudgetExhausted')
        self.assertIsNone(self.cell['protocolFailures'][0]['sqlstate'])
    def test_observed_rate_exceeds_old_sixty_second_cap(self):
        result=assess(self.cell);self.assertGreater(result['projected60sAttemptsPerWorker'],100000)
        self.assertGreater(result['headroomOverProjected60sAttempts'],8)
    def test_one_million_does_not_certify_capacity(self):
        result=assess(self.cell);self.assertFalse(result['readyForFormalExecution'])
        self.assertFalse(result['sizingOnly']['hot']['sourceRecordLimitSufficientAtProjection'])
        self.assertFalse(result['sizingOnly']['parallel']['lifecycleRecordLimitSufficientAtProjection'])
    def test_source_bound_counts_missing_reads_and_control_records(self):
        self.assertEqual(source_count(3,4096),6+4096+32+2)
        self.assertGreater(source_count(500000,4096),LIMITS['sourceRecords'])
    def test_both_profile_plans_preserve_all_cells_and_target(self):
        for profile in ('column','sidecar'):
            plan=draft_plan(profile);self.assertEqual(len(plan['cells']),36)
            self.assertEqual(plan['targetsUnchanged']['fullCaptureThroughputCOverAAtLeast'],.9)
            self.assertEqual(plan['targetsUnchanged']['fullCaptureP95COverAAtMost'],1.15)
            for cell in plan['cells']:
                self.assertFalse(cell['executable']);self.assertEqual(cell['warmupSeconds'],15);self.assertEqual(cell['durationSeconds'],60);self.assertEqual(cell['drainSeconds'],30)
    def test_unbounded_warmup_not_hidden_by_measured_cap(self):
        result=assess(self.cell,10_000_000);self.assertFalse(result['readyForFormalExecution'])
        self.assertTrue(result['warmupBoundedByTimeButNotAttemptCount'])
if __name__=='__main__':unittest.main(verbosity=2)
