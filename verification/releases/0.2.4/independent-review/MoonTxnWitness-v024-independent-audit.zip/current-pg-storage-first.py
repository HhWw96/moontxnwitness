from pathlib import Path
import os,sys,json,hashlib,sqlite3
base=Path(__file__).resolve().parent
sys.dont_write_bytecode=True
scratch=base/'storage-scratch';scratch.mkdir();os.environ['MTW_JOURNAL_SCRATCH']=str(scratch)
sys.path.insert(0,str(base/'frozen/integrations/python'))
from moontxnwitness_capture.journal_v3 import JournalReader
from moontxnwitness_capture.source_sink import verify_grouped_source
root=base/'frozen/verification/configured-user-profile/v024-current-20261023T104628Z-56e0d817'
receipt=json.loads((root/'receipt.json').read_bytes());checks=[]
def check(value,label):
 assert value,label
 checks.append(label)
for producer in receipt['producers']:
 case=root/('producer-'+str(producer['id']));profile=case/'suite/profile'
 for rel,entry in producer['files'].items():
  raw=(case/rel).read_bytes();check(len(raw)==entry['bytes'] and hashlib.sha256(raw).hexdigest()==entry['sha256'],'raw-bound-'+str(producer['id'])+'-'+rel)
 env=json.loads((case/'suite/profile-source.json').read_bytes())
 for field,path in [('traceText',profile/'capture/trace.json'),('sourceJournalText',profile/'sources.jsonl'),('lifecycleText',profile/'capture/lifecycle.jsonl'),('journalIndexText',profile/'capture/journal/journal-index.json')]:check(env[field].encode('utf8')==path.read_bytes(),'envelope-exact-'+str(producer['id'])+'-'+field)
 source=verify_grouped_source(profile/'sources.jsonl');check(source['storageSealed'] and source['completeCapture'] is False and source['coreProofAccepted'] is False,'source-storage-boundary-'+str(producer['id']))
 reader=JournalReader(profile/'capture/journal');journal=reader.verify();check(journal.valid and journal.closed and not journal.source_closed and not journal.complete,'journal-original-diagnostic-boundary-'+str(producer['id']))
 check(list(reader.iter_events(require_complete=False))==json.loads(env['traceText'])['events'],'all-real-segment-events-equal-envelope-'+str(producer['id']))
 rows=env['lifecycleText'].splitlines(keepends=True);seal=json.loads(rows[-1]);check(seal['prefixSha256']==hashlib.sha256(''.join(rows[:-1]).encode()).hexdigest() and seal['records']==len(rows)-1,'original-lifecycle-seal-'+str(producer['id']))
 for rel,entry in producer['files'].items():check(hashlib.sha256((case/rel).read_bytes()).hexdigest()==entry['sha256'],'raw-unchanged-after-verify-'+str(producer['id'])+'-'+rel)
output={'schema':1,'kind':'independent-current-v024-actual-PG-byte-and-storage-evidence-verification','passed':True,'checks':len(checks),'labels':checks,'producerFiles':24,'producerCases':2,'actualDatabaseExecutionByReviewer':False,'coreSourcePromotionCoveredSeparatelyByOriginal54':True,'formalPerformance':False,'databaseAuthenticityClaim':False,'inputReceiptSHA256':hashlib.sha256((root/'receipt.json').read_bytes()).hexdigest()}
(base/'current-pg-storage-first.json').write_bytes((json.dumps(output,indent=2)+'\n').encode());print(json.dumps({'passed':True,'checks':len(checks),'producerFiles':24}))
