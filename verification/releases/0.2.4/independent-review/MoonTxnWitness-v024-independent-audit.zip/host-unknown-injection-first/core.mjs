import * as real from './real-core.mjs';
export const version=real.version;
export const orm_profile_source_v3_json=real.orm_profile_source_v3_json;
export const shrink_options_json=real.shrink_options_json;
export const replay_report_json=real.replay_report_json;
export let injected=0;
export function analyze_options_json(text,options){const raw=real.analyze_options_json(text,options);if(JSON.stringify(JSON.parse(text).transactions.map(t=>t.id).sort())==="[\"orm-tx-1b9f1cd23e2c4504bb0a299392766032\",\"orm-tx-cba7e99a99914306a146419d2a201582\"]"){const value=JSON.parse(raw);if(value.status!=='consistent')throw Error('Injected candidate must first have a real consistent result');value.status='inconclusive';value.complete=false;injected++;return JSON.stringify(value)}return raw}
