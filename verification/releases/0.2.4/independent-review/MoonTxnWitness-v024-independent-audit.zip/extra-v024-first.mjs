// Independent additional challenges. Freeze before the first integrated-runtime execution.
import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
import {spawnSync} from 'node:child_process';
const [runtimeArg,packetOneArg,packetTwoArg,syntheticArg,outArg]=process.argv.slice(2);
for(const arg of [runtimeArg,packetOneArg,packetTwoArg,syntheticArg,outArg])assert.equal(typeof arg,'string');
const runtime=resolve(runtimeArg),out=resolve(outArg);mkdirSync(out);
const sdk=await import(pathToFileURL(resolve(runtime,'sdk.mjs')));
const digest=x=>createHash('sha256').update(x).digest('hex');
const pretty=x=>JSON.stringify(x,null,2)+'\n',clone=x=>structuredClone(x);
const save=(name,value)=>writeFileSync(resolve(out,name),typeof value==='string'||Buffer.isBuffer(value)?value:pretty(value),{flag:'wx'});
const inputs=[packetOneArg,packetTwoArg].map(path=>readFileSync(path,'utf8'));
const synthetic=readFileSync(syntheticArg,'utf8');
const checks=[];let serialStates=0;
const test=(name,fn)=>{try{const detail=fn();checks.push({name,passed:true,detail:detail??null})}catch(error){checks.push({name,passed:false,error:String(error.stack||error)})}};
function sealIndex(value,{first=false,decimal=false}={}){
 delete value.indexSha256;
 let raw=JSON.stringify(value);
 if(decimal)raw=raw.replace(/"eventCount":(\d+)(?=[,}])/g,'"eventCount":$1.0');
 const sha=digest(raw);
 return first?'{"indexSha256":"'+sha+'",'+raw.slice(1):raw.slice(0,-1)+',"indexSha256":"'+sha+'"}';
}
function sealLife(rows){rows.forEach((r,i)=>r.seq=i+1);const prefix=rows.slice(0,-1).map(r=>JSON.stringify(r)+'\n').join('');rows.at(-1).records=rows.length-1;rows.at(-1).prefixSha256=digest(prefix);return prefix+JSON.stringify(rows.at(-1))+'\n'}
function mutated(text,edit){const value=JSON.parse(text);edit(value);return JSON.stringify(value)}
function closed(original,kept){
 const included=new Set(kept.transactions.map(t=>t.id));
 const versions=new Map();
 for(const [key,version] of Object.entries(original.initial))versions.set(JSON.stringify([key,version]),null);
 for(const tx of original.transactions)for(const op of tx.ops)if(op.type==='write')versions.set(JSON.stringify([op.key,op.version]),tx.id);
 const absent=[];
 function require(key,version){const identity=JSON.stringify([key,version]);if(!versions.has(identity))absent.push({key,version,why:'no-original-source'});else{const writer=versions.get(identity);if(writer!==null&&!included.has(writer))absent.push({key,version,writer,why:'writer-deleted'})}}
 for(const tx of kept.transactions)for(const op of tx.ops){
  if(op.type==='read')require(op.key,op.version);
  if(op.type==='write'){
   const order=original.versionOrders?.[op.key];if(order){const rank=order.indexOf(op.version);if(rank>0)require(op.key,order[rank-1])}
  }
 }
 return {complete:absent.length===0,absent};
}
function deleteOne(original,history,id){
 const kept=history.transactions.filter(tx=>tx.id!==id),seen=new Map(Object.entries(original.initial).map(([k,v])=>[k,new Set([v])]));
 for(const tx of kept)for(const op of tx.ops){if(!seen.has(op.key))seen.set(op.key,new Set());seen.get(op.key).add(op.version)}
 return {...clone(original),transactions:clone(kept),versionOrders:Object.fromEntries(Object.entries(original.versionOrders??{}).map(([k,order])=>[k,order.filter(v=>seen.get(k)?.has(v))]))};
}
function serialExists(history){
 const transactions=history.transactions.filter(tx=>tx.status==='committed');
 assert(transactions.length<=6,'Independent oracle is deliberately bounded to six committed transactions');
 function visit(remaining,state){
  serialStates++;
  if(!remaining.length)return true;
  for(let i=0;i<remaining.length;i++){
   const next={...state};let legal=true;
   for(const op of remaining[i].ops){
    if(op.type==='read'){if(next[op.key]!==op.version){legal=false;break}}
    else if(op.type==='write'){
     const order=history.versionOrders?.[op.key],rank=order?.indexOf(op.version)??-1;
     if(rank>0&&next[op.key]!==order[rank-1]){legal=false;break}
     next[op.key]=op.version;
    }else throw new Error('Independent point oracle encountered an unsupported operation');
   }
   if(legal&&visit(remaining.filter((_,j)=>i!==j),next))return true;
  }
  return false;
 }
 return visit(transactions,{...history.initial});
}
for(const [i,input] of inputs.entries()){
 const prefix='packet-'+(i+1);
 test(prefix+'-original-control-and-generic-boundary',()=>{
  const r=sdk.analyzeOrmProfileV3(input);assert.equal(r.analysisCoverageAccepted,true);assert.equal(r.status,'consistent');
  assert.equal(r.result.originalDiagnosticCoverage.complete,false);assert.equal(r.result.originalSourceProof.analysisCoverageAccepted,false);assert.equal(r.result.originalSourceProof.history,null);
  assert.equal(JSON.parse(JSON.parse(input).journalIndexText).sourceClosed,false);save(prefix+'.original-report.json',r);
 });
 for(const style of [{first:true,decimal:false},{first:false,decimal:true}])test(prefix+'-valid-index-original-byte-elision-'+JSON.stringify(style),()=>{
  const text=mutated(input,e=>{e.journalIndexText=sealIndex(JSON.parse(e.journalIndexText),style)});
  const r=sdk.analyzeOrmProfileV3(text);save(prefix+'.index-style-'+(style.first?'first':'last-decimal')+'.input.json',text);save(prefix+'.index-style-'+(style.first?'first':'last-decimal')+'.report.json',r);
  assert.equal(r.analysisCoverageAccepted,true);assert.equal(r.status,'consistent');assert.equal(r.sourceBindings.journalIndexSha256,digest(JSON.parse(text).journalIndexText));
 });
 const attacks={
  'durable-tail':index=>index.durableSeq--,
  'segment-gap':index=>index.segments[0].firstSeq++,
  'active-transaction':index=>index.activeTransactions.push('independent-active'),
  'generic-source-closed-upgrade':index=>index.sourceClosed=true,
  'unread-result':index=>index.references.unreadResults.push({statement:3})
 };
 for(const [name,edit] of Object.entries(attacks))test(prefix+'-resealed-index-'+name,()=>{
  const text=mutated(input,e=>{const index=JSON.parse(e.journalIndexText);edit(index);e.journalIndexText=sealIndex(index)});
  const r=sdk.analyzeOrmProfileV3(text);save(prefix+'.'+name+'.report.json',r);assert.equal(r.analysisCoverageAccepted,false);assert.equal(r.status,'inconclusive');
 });
 test(prefix+'-canonical-clock-leading-zero-refusal',()=>{
  const text=mutated(input,e=>{const rows=e.lifecycleText.trimEnd().split('\n').map(JSON.parse),r=rows.find(x=>x.kind==='engine-attached');r.monotonicNs='0'+r.monotonicNs;e.lifecycleText=sealLife(rows)});
  const r=sdk.analyzeOrmProfileV3(text);assert.equal(r.analysisCoverageAccepted,false);assert.equal(r.status,'inconclusive');
 });
 test(prefix+'-segment-byte-verification-boundary-visible',()=>{
  const text=mutated(input,e=>{const index=JSON.parse(e.journalIndexText);assert.equal(typeof index.segments[0].sha256,'string');index.segments[0].sha256='a'.repeat(64);e.journalIndexText=sealIndex(index)});
  const r=sdk.analyzeOrmProfileV3(text);save(prefix+'.unrehashed-segment-descriptor.report.json',r);
  assert.equal(r.analysisCoverageAccepted,true);assert.equal(r.scope.eventSegmentPayloadsRehashed,false);assert.equal(r.scope.databaseAuthenticityVerified,false);
  return 'A resealed descriptor does not establish underlying segment authenticity; external original segment verification is required.';
 });
 test(prefix+'-duplicate-raw-envelope-property-refusal',()=>{
  const text=input.trimEnd().replace(/}$/,',"profile":"fastapi-users-sqlalchemy-7.0.0-pg18/1"}');
  const r=sdk.analyzeOrmProfileV3(text);assert.equal(r.analysisCoverageAccepted,false);assert.equal(r.status,'inconclusive');
 });
 test(prefix+'-capsule-original-bytes-and-resealed-result-refusal',()=>{
  const cap=sdk.makeOrmProfileCapsuleV3(input),parsed=JSON.parse(cap),replay=sdk.replayOrmProfileCapsuleV3(cap);
  assert.equal(replay.valid,true);assert.equal(replay.envelopeText,input);assert.equal(parsed.envelopeText,input);
  for(const edit of [r=>r.status='violation',r=>r.scope.databaseAuthenticityVerified=true,r=>r.sourceBindings.journalIndexSha256='0'.repeat(64),r=>r.budgets.exactSearchTransactions++]){
   const changed=clone(parsed),report=JSON.parse(changed.reportText);edit(report);changed.reportText=JSON.stringify(report);changed.reportSha256=digest(changed.reportText);assert.equal(sdk.replayOrmProfileCapsuleV3(pretty(changed)).valid,false);
  }
  const future=clone(parsed);future.engineVersion='0.2.5';assert.equal(sdk.replayOrmProfileCapsuleV3(pretty(future)).valid,false);
 });
}
let originalSynthetic=null,fullReduction=null;
test('synthetic-independent-initial-oracle-control',()=>{
 const r=sdk.analyzeOrmProfileV3(synthetic);assert.equal(r.analysisCoverageAccepted,true);assert.equal(r.status,'violation');originalSynthetic=r.result.history;
 assert.equal(serialExists(originalSynthetic),false);save('synthetic.original-report.json',r);return {transactions:originalSynthetic.transactions.length,committed:originalSynthetic.transactions.filter(t=>t.status==='committed').length};
});
for(const budget of [0,1,2,4,8,256])test('synthetic-shared-candidate-budget-'+budget,()=>{
 const r=sdk.reduceOrmProfileV3(synthetic,{maxChecks:budget}),red=r.result.reduction;assert(red);assert.equal(red.maxChecks,budget);assert(red.checks<=budget);assert.equal(red.checks,red.semanticCandidateChecks);assert.equal(red.candidateAttempts,red.checks+red.cachedCandidateLookups);
 assert.equal(red.sourceClosure.complete,true);assert.equal(closed(originalSynthetic,red.reducedHistory).complete,true);
 if(budget===0){assert.equal(red.oneMinimal,false);assert.equal(r.result.finalReanalysis,null);assert.equal(r.result.finalReplay,null);assert.equal(red.genericAttempt,null);assert.deepEqual(r.result.verificationPasses,{inputSourcePromotions:1,genericCalls:0,finalSourcePromotions:0,finalCandidateAnalyses:0,finalReportReplays:0})}
 else{assert.equal(r.result.finalReanalysis.status,'violation');assert.equal(r.result.finalReplay.valid,true);assert.equal(serialExists(red.reducedHistory),false)}
 if(red.oneMinimal){assert.equal(red.oneMinimalPredicate,'source-closed definite violation under recorded analysis budgets');assert.equal(red.sourceClosure.allRemainingSingleDeletesChecked,true);assert(!red.sourceClosure.singleDeletionChecks.some(c=>c.status==='inconclusive'&&c.sourceClosure.complete))}
 if(budget===256)fullReduction=r;
 save('synthetic.budget-'+budget+'.report.json',r);return {status:r.status,checks:red.checks,oneMinimal:red.oneMinimal,transactions:red.reducedHistory.transactions.length};
});
test('synthetic-enumerate-source-domain-single-deletions-independently',()=>{
 assert(fullReduction);const reduced=fullReduction.result.reduction;assert.equal(reduced.oneMinimal,true);const rows=[];
 for(const tx of reduced.reducedHistory.transactions){
  const candidate=deleteOne(originalSynthetic,reduced.reducedHistory,tx.id),closure=closed(originalSynthetic,candidate);
  const row={transaction:tx.id,sourceClosed:closure.complete,missing:closure.absent};
  if(closure.complete){const report=sdk.analyzeWithOptions(JSON.stringify(candidate));row.analysisStatus=report.status;row.independentSerialExists=serialExists(candidate);assert.equal(report.status,'consistent');assert.equal(row.independentSerialExists,true)}
  else{const recorded=reduced.sourceClosure.singleDeletionChecks.findLast(c=>c.transaction===tx.id);assert(recorded);assert.equal(recorded.reason,'missing-source');assert.equal(recorded.status,'unknown')}
  rows.push(row);
 }
 assert(rows.some(r=>!r.sourceClosed),'Fixture must exercise actual source-open deletions, not merely a name');save('synthetic.independent-source-domain-single-deletions.json',rows);return rows;
});
test('synthetic-bounded-final-report-and-minimality-tampering-refused',()=>{
 const cap=sdk.makeOrmProfileReductionCapsuleV3(synthetic),parsed=JSON.parse(cap);assert.equal(sdk.replayOrmProfileCapsuleV3(cap).valid,true);
 for(const edit of [r=>r.result.reduction.oneMinimalPredicate='globally transaction minimal',r=>r.result.reduction.oneMinimal=false,r=>r.result.reduction.sourceClosure.allRemainingSingleDeletesChecked=false,r=>r.result.reduction.maxChecks=257]){
  const changed=clone(parsed),report=JSON.parse(changed.reportText);edit(report);changed.reportText=JSON.stringify(report);changed.reportSha256=digest(changed.reportText);assert.equal(sdk.replayOrmProfileCapsuleV3(pretty(changed)).valid,false)
 }
});
test('cli-invalid-utf8-and-output-collision-do-not-overwrite',()=>{
 const input=resolve(out,'cli.original.json');save('cli.original.json',inputs[0]);save('cli.invalid-utf8.json',Buffer.from([255,123,125]));
 const cli=args=>spawnSync(process.execPath,[resolve(runtime,'moontxnwitness.mjs'),...args],{encoding:'utf8',windowsHide:true,maxBuffer:16*1024*1024,timeout:30000});
 let child=cli(['orm-profile-v3',resolve(out,'cli.invalid-utf8.json')]);save('cli.invalid-utf8.stdout',child.stdout??'');save('cli.invalid-utf8.stderr',child.stderr??'');assert.equal(child.status,2);
 const before=digest(readFileSync(input));child=cli(['orm-profile-v3',input,'--output',input]);save('cli.collision.stdout',child.stdout??'');save('cli.collision.stderr',child.stderr??'');assert.equal(child.status,2);assert.equal(digest(readFileSync(input)),before);
});
const runtimeBinding=Object.fromEntries(['sdk.mjs','core.mjs','capture-core.mjs','orm-profile.mjs','evidence.mjs','moontxnwitness.mjs','build-manifest.json'].map(name=>[name,digest(readFileSync(resolve(runtime,name)))]));
const receipt={schema:1,kind:'independent-v024-additional-source-domain-and-host-challenges',passed:checks.every(c=>c.passed),engineVersion:sdk.version(),runnerSha256:digest(readFileSync(new URL(import.meta.url))),runtimeBinding,inputSha256:inputs.map(digest),syntheticInputSha256:digest(synthetic),syntheticChangedObservationsExecutedOnDatabase:false,original54ExpectationsModified:false,checks,independentSerialSearchStates:serialStates,actualDatabaseExecutionHere:false,formalPerformanceMeasurement:false,compilerExecutionHere:false,scope:'Independent technical challenges over frozen supplied evidence; source-closed definite anomaly minimality is distinct from generic/global transaction minimality, hashes/recomputation do not authenticate a database'};
save('receipt.json',receipt);console.log(pretty({passed:receipt.passed,checks:checks.length,failures:checks.filter(c=>!c.passed),serialStates,receiptSha256:digest(pretty(receipt))}));if(!receipt.passed)process.exitCode=1;
