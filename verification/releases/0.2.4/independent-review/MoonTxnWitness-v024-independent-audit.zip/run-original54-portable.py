from pathlib import Path
import subprocess,json,hashlib,shutil,os
base=Path(__file__).resolve().parent
runs=base/'original54-runs';runs.mkdir()
frozen=base/'frozen'
original=base/'original54/verification/configured-user-profile/v024-initial/independent-first-failures'
packets=[('historical-packet-1',frozen/'verification/configured-user-profile/v024-initial/producer-first/profile-source.json'),('historical-packet-2',frozen/'verification/configured-user-profile/v024-initial/producer-second/profile-source.json')]
pg=frozen/'verification/configured-user-profile/v024-current-20261023T104628Z-56e0d817'
packets += [('current-packet-'+str(i),pg/('producer-'+str(i))/'suite/profile-source.json') for i in [1,2]]
summary={'schema':1,'kind':'independent-original54-exact-expectations-on-historical-and-current-PG-packets','passed':True,'originalExpectedValuesModified':False,'runs':[],'actualDatabaseExecutionHere':False,'formalPerformanceHere':False,'compilerHere':False}
for label,source in packets:
 work=runs/label;work.mkdir();(work/'runtime').mkdir();(work/'original').mkdir()
 for name in ['core.mjs','build-manifest.json']:shutil.copyfile(frozen/'dist'/name,work/'runtime'/name)
 shutil.copyfile(source,work/'original/profile-source.json')
 row={'packet':label,'inputSha256':hashlib.sha256(source.read_bytes()).hexdigest(),'suites':[]}
 for name,receiptName,count in [('audit-profile-first.mjs','first-receipt.json',18),('audit-profile-second.mjs','second-receipt.json',9)]:
  shutil.copyfile(original/name,work/name)
  p=subprocess.run([os.environ.get('MTW_REVIEW_NODE','node'),str(work/name)],cwd=work,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=90)
  (work/(name+'.stdout')).write_bytes(p.stdout);(work/(name+'.stderr')).write_bytes(p.stderr)
  receipt=json.loads((work/receiptName).read_bytes()) if (work/receiptName).exists() else None
  passed=p.returncode==0 and receipt is not None and receipt['passed'] and len(receipt['cases'])==count
  row['suites'].append({'runner':name,'runnerSHA256':hashlib.sha256((work/name).read_bytes()).hexdigest(),'exitCode':p.returncode,'passed':passed,'checks':count,'receiptSHA256':hashlib.sha256((work/receiptName).read_bytes()).hexdigest() if receipt else None,'stdoutSHA256':hashlib.sha256(p.stdout).hexdigest(),'stderrSHA256':hashlib.sha256(p.stderr).hexdigest()})
  if not passed:summary['passed']=False
 summary['runs'].append(row)
 print(json.dumps({'packet':label,'passed':all(s['passed']for s in row['suites']),'suites':row['suites']}),flush=True)
summary['checks']=sum(s['checks']for r in summary['runs']for s in r['suites'])
(base/'original54-runs-summary.json').write_bytes((json.dumps(summary,indent=2)+'\n').encode('utf8'))
print(json.dumps({'passed':summary['passed'],'checks':summary['checks']}),flush=True)
if not summary['passed']:raise SystemExit(1)
