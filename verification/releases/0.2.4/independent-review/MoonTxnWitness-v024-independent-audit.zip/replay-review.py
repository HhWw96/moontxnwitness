from pathlib import Path
import argparse,hashlib,json,os,shutil,subprocess,sys
parser=argparse.ArgumentParser();parser.add_argument('--node',required=True);parser.add_argument('--python',default=sys.executable);parser.add_argument('--output',required=True);args=parser.parse_args()
base=Path(__file__).resolve().parent;out=Path(args.output).resolve();out.mkdir(parents=True,exist_ok=False)
manifest=json.loads((base/'audit-manifest.json').read_bytes())
for row in manifest['files']:
 raw=(base/row['path']).read_bytes();assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256'],row['path']
for folder in ['frozen','original54','actual-public23']:shutil.copytree(base/folder,out/folder)
for name in ['run-original54-first.py','run-original54-portable.py','extra-v024-first.mjs','public23-compat-first.mjs','current-pg-storage-first.py','host-unknown-injection-first.mjs']:shutil.copyfile(base/name,out/name)
# Original JS audit runners and all expectations remain byte-identical; the portable controller only selects the supplied Node executable.
scratch=out/'temp';scratch.mkdir();env=dict(os.environ,TEMP=str(scratch),TMP=str(scratch),TMPDIR=str(scratch),PYTHONDONTWRITEBYTECODE='1',MTW_REVIEW_NODE=args.node)
pg=out/'frozen/verification/configured-user-profile/v024-current-20261023T104628Z-56e0d817'
commands=[('original54',[args.python,str(out/'run-original54-portable.py')],out/'original54-runs-summary.json',108),('additional',[args.node,str(out/'extra-v024-first.mjs'),str(out/'frozen/dist'),str(pg/'producer-1/suite/profile-source.json'),str(pg/'producer-2/suite/profile-source.json'),str(out/'frozen/fixtures/orm-profile-v3/synthetic-nonrepeatable-first/profile-source.json'),str(out/'extra-first')],out/'extra-first/receipt.json',34),('public23',[args.node,str(out/'public23-compat-first.mjs')],out/'public23-compat-first/receipt.json',133),('storage',[args.python,str(out/'current-pg-storage-first.py')],out/'current-pg-storage-first.json',64),('host-fault-injection-only',[args.node,str(out/'host-unknown-injection-first.mjs')],out/'host-unknown-injection-first/receipt.json',8)]
groups=[]
for label,command,receiptPath,count in commands:
 proc=subprocess.run(command,cwd=out,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=180)
 (out/(label+'.stdout')).write_bytes(proc.stdout);(out/(label+'.stderr')).write_bytes(proc.stderr)
 receipt=json.loads(receiptPath.read_bytes()) if receiptPath.exists() else None
 passed=proc.returncode==0 and receipt is not None and receipt['passed'] and (receipt['checks']==count if isinstance(receipt['checks'],int) else len(receipt['checks'])==count)
 groups.append({'name':label,'passed':passed,'checks':count,'exitCode':proc.returncode,'receiptSHA256':hashlib.sha256(receiptPath.read_bytes()).hexdigest() if receipt else None,'stdoutSHA256':hashlib.sha256(proc.stdout).hexdigest(),'stderrBytes':len(proc.stderr)})
 print(json.dumps(groups[-1]),flush=True)
result={'schema':1,'passed':all(x['passed']for x in groups),'groups':groups,'sourceArchiveManifestSHA256':hashlib.sha256((base/'audit-manifest.json').read_bytes()).hexdigest(),'authorWorkspaceRead':False,'networkUsed':False,'compilerRun':False,'databaseRun':False,'formalPerformanceRun':False,'realChecks':339,'mockChecksSeparate':8,'knownTwoAuditHypothesisFirstFailuresPreservedByFullManifest':True,'knownWrongPreconditionProbeNotRepeated':True}
(out/'replay-receipt.json').write_bytes((json.dumps(result,indent=2)+'\n').encode());print(json.dumps({'passed':result['passed'],'groups':len(groups),'realChecks':339,'mockChecksSeparate':8}),flush=True)
if not result['passed']:raise SystemExit(1)
