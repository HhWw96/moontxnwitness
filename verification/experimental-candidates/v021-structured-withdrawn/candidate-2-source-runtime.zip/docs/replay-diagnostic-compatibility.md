# Released invalid-report diagnostics

Some v3 invalid reports are replayable evidence. Their generated diagnostic text
contains a compiler source location. Refactoring a guard must preserve the old
capsule even when the guard moves to a different line.

Verification recomputes the complete report. For the explicitly supported released
engines 0.1.1 through 0.1.8 and 0.2.0, it restores the generated invalid diagnostic's
exact old location before the existing exact comparison. Only unchanged fail-call
sites are mapped. The source mapping is generated from the released Git tags and
the current formatted normalizer files; source hashes are recorded in
`verification/compatibility/v3-diagnostic-locations.json`.

The transformation applies only to a generated invalid normalized report's own
single diagnostic gap and matching error field, including a register lifecycle
rejection forwarded unchanged by list normalization. It never rewrites supplied
reports, original observations, business values, user gaps, budgets, or verdicts.
The host still checks all capsule digests and exact normalized/evidence content.
Unknown engines and coordinates are not accepted through this mechanism.

Run `python scripts/generate-v3-diagnostic-locations.py --check` after changes.
When a mapped normalizer changes, format it first, regenerate the exact table,
and rerun the frozen public-release capsules and tamper tests. This map is not a
promise that arbitrary future algorithms can replay old reports without review.
