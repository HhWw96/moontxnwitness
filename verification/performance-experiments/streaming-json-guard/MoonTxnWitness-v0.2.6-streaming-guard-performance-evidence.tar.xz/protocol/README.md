MoonTxnWitness StreamingJsonScan 下一候选性能协议准备

本目录只准备下一轮门禁与数据。执行主字段与完整正确性门禁仍为pending；已观测到的真实编译摘要单列OBSERVED-BUILD-PENDING.json，尚不启用冻结，没有冻结可执行bundle，没有运行SDK或计时。

仍使用前轮相同10份原输入、同一完整SDK调用、5次预热+30正式样本x3批、60个独立串行进程。固定128链原文78800B、SHA fb2764c1f35f939b7ad6d46af26dc0de3c62b2abb6abc456606df35a6b37634d、options={}保持。目标仍为该固定128完整六模型SDK提速>=1.15或RSS<=0.85，两项分别报告；其余九项逐批及pooled P95回退限额不变。六模型整体几何均值仍单独报告，原v020完整SDK目标和上一empty-interval候选的失败结论都不改变。

沿用前轮5个工具。worker.mjs/run.mjs/pure-test.mjs原字节不变；仅common/freeze去除旧candidate专属硬编码并增加pending关闭条件、改为明确协议字段。原工具完整副本和最小diff保留，未引入新测量框架、额外case或并行worker。

新候选是有效JSON路径的StreamingJsonScan实现，保留原JsonScan/index，并在无效JSON时调用原guard以保持原前缀、行列及错误文本。它会实际改变capture实现，不能复用上轮“只有编译器名称重编号”的说明。必须绑定新的37core/SDK、public25、固定128、capture全部8导出、index差分、parse/Unicode边界、原748预期不变的全回归及所有首次失败/fix1/fix2记录。GATE-SCHEMA.json只描述契约；correctness-gate.pending.json明确不是通过收据。

实际全部通过后，由主线程核对原证据，填写新的真实SHA/format和通过gate，将runtimeState设ready，再单独审查/冻结新的plan。待定字段不能填虚构值，不能仅凭756测试通过提前冻结，也不能沿用旧候选原报告作为当前候选验收。

本轮仅执行语法和纯门禁数据控制。原pure-test包含ready运行时输出辅助控制，准备期不运行它来假装候选已锁；pending-state-controls.mjs只检查门禁/矩阵/原输入/旧工具字节，绝不导入SDK、编译或计时。

READY follow-up: all required scoped actual evidence is now bound. Original g pending data stays unchanged. Baseline compatibility for195 complete cases passed; historicalManifestMatched remains false. No performance claim or adoption. New ready protocol changes data only; exactly the previous5 tools and10 performance cases remain.
