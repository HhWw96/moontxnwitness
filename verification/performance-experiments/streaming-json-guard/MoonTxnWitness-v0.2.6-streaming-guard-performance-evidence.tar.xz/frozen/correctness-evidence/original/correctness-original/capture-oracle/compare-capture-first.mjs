// Correctness differential only: no benchmark, timer, warmup, database or source mutation.
import {readFileSync,writeFileSync,appendFileSync,existsSync,mkdirSync} from 'node:fs';
import {join,resolve,dirname} from 'node:path';
import {pathToFileURL,fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import {tmpdir} from 'node:os';
const here=dirname(fileURLToPath(import.meta.url)),out=join(here,'results-first');
if(existsSync(out))throw Error('Refusing to overwrite first output');mkdirSync(out);
const hash=b=>createHash('sha256').update(b).digest('hex');
const load=p=>JSON.parse(readFileSync(p,'utf8'));
const bind=p=>{const b=readFileSync(p);return{bytes:b.length,sha256:hash(b)}};
const plan=load(join(here,'plan.json')),runtimePath=resolve(plan.runtimeBindings.path),bindings=load(runtimePath);
const receipt={format:'streaming-guard-capture-public-oracle/v1',status:'running',plan:bind(join(here,'plan.json')),runtimeBindings:bind(runtimePath),runner:bind(fileURLToPath(import.meta.url)),performanceMeasured:false,rootWrites:false,checks:0,directCalls:0,coreCalls:0,sdkCalls:0,cases:0,captureExports:[],baselineOracleCoreSha:bindings.baseline.buildManifest.coreSha256,firstFailure:null};
const save=()=>writeFileSync(join(out,'receipt.json'),JSON.stringify(receipt,null,2)+'\n');
function check(ok,message){receipt.checks++;if(!ok)throw Error(message)}
function frozen(config){for(const f of config.files){const b=bind(join(config.directory,f.path));check(b.bytes===f.bytes&&b.sha256===f.sha256,'Runtime changed: '+f.path)}}
function call(obj,name,args){try{const v=obj[name](...args);return {kind:'return',text:typeof v==='string'?v:JSON.stringify(v)}}catch(error){return {kind:'throw',name:error.name,message:error.message}}}
function pair(id,name,ba,ca,args,kind){
 const b=call(ba,name,args),c=call(ca,name,args);receipt[kind+'Calls']+=2;
 appendFileSync(join(out,'original-outputs.jsonl'),JSON.stringify({id,method:name,kind,baseline:b,candidate:c})+'\n');
 check(JSON.stringify(b)===JSON.stringify(c),'Exact public output changed: '+id+'/'+name);
 check(b.kind==='return','Unexpected throw in public oracle: '+id+'/'+name);
 return {text:b.text,value:JSON.parse(b.text)};
}
function expected(value,want,id){if(!want)return;check(value[want.field]===want.value,'Frozen original expectation failed: '+id+'/'+want.field)}
try{
 check(/^[dD]:[\\/]/.test(tmpdir()),'Temporary directory fell back outside D');
 check(receipt.runtimeBindings.sha256===plan.runtimeBindings.sha256,'Runtime-binding file changed');
 frozen(bindings.baseline);frozen(bindings.candidate);
 const bc=await import(pathToFileURL(join(bindings.baseline.directory,'core.mjs'))),cc=await import(pathToFileURL(join(bindings.candidate.directory,'core.mjs')));
 const bp=await import(pathToFileURL(join(bindings.baseline.directory,'capture-core.mjs'))),cp=await import(pathToFileURL(join(bindings.candidate.directory,'capture-core.mjs')));
 const bs=await import(pathToFileURL(join(bindings.baseline.directory,'sdk.mjs'))),cs=await import(pathToFileURL(join(bindings.candidate.directory,'sdk.mjs')));
 check(bc.version()===cc.version(),'Version changed');
 for(const name of plan.allEightExports){check(typeof bp[name]==='function'&&typeof cp[name]==='function','Missing capture export '+name);receipt.captureExports.push(name)}
 const validTrace=readFileSync(join(here,'inputs/v3-initial-read-commit.txt'),'utf8');
 const sdkNames={normalize_capture_json:'normalizeCapture',normalize_presence_json:'normalizePresenceCapture',normalize_capture_v3_json:'normalizeCaptureV3',normalize_capture_v3_options_json:'normalizeCaptureV3',inspect_execution_failures_v3_json:'inspectExecutionFailuresV3',dislock_sql_v3_proof_json:'inspectDislockCaptureV3',orm_sql_source2_v3_proof_json:'inspectOrmSourceV3'};
 for(const row of plan.cases){
  const inputPath=join(here,row.input.path),b=readFileSync(inputPath);check(b.length===row.input.bytes&&hash(b)===row.input.sha256,'Input changed '+row.id);const text=b.toString('utf8');
  if(row.kind==='guard'){
   for(const name of plan.allEightExports){
    const result=pair(row.id,name,bp,cp,name==='normalize_capture_v3_options_json'?[text,'{}']:[text],'direct');
    if(row.id==='guard-distinct-emoji-keys')check(!result.text.includes('Duplicate JSON object key'),'Distinct emoji values were incorrectly identical in public oracle');
    if(row.id==='guard-same-emoji-keys')check(result.text.includes('Duplicate JSON object key'),'Corrected equivalent emoji fixture must reject duplicate in public oracle');
   }
   pair(row.id,'classify_v3_json',bc,cc,[validTrace,text],'core');
  }else if(row.kind==='options'){
   pair(row.id,'classify_v3_json',bc,cc,[validTrace,text],'core');
   pair(row.id,'normalize_capture_v3_options_json',bp,cp,[validTrace,text],'direct');
  }else if(row.kind==='profile'){
   pair(row.id,'orm_profile_source_v3_json',bc,cc,[text,'{}'],'core');
   const report=pair(row.id,row.method,bs,cs,[text],'sdk');expected(report.value,row.baselineAssertion,row.id);
   const verification=pair(row.id,'verifyOrmProfileV3',bs,cs,[text,report.text],'sdk');check(verification.value.valid===true,'Profile report must independently verify '+row.id);
   const tampered=JSON.parse(report.text);tampered.status=report.value.status==='invalid'?'consistent':'invalid';
   const rejection=pair(row.id+'-report-tamper','verifyOrmProfileV3',bs,cs,[text,JSON.stringify(tampered)],'sdk');check(rejection.value.valid===false,'Profile report tamper accepted '+row.id);
  }else{
   const args=row.method==='normalize_capture_v3_options_json'?[text,row.optionsText]:[text];
   const result=pair(row.id,row.method,bp,cp,args,'direct');expected(result.value,row.baselineAssertion,row.id);
   const sdk=sdkNames[row.method];if(sdk){const args=row.method==='normalize_capture_v3_options_json'?[text,JSON.parse(row.optionsText)]:[text];const s=pair(row.id,sdk,bs,cs,args,'sdk');check(s.text===result.text||JSON.stringify(s.value)===JSON.stringify(result.value),'SDK did not deliver capture result '+row.id)}
  }
  receipt.cases++;save();
 }
 frozen(bindings.baseline);frozen(bindings.candidate);receipt.status='passed';
}catch(error){receipt.status='failed-first-retained';receipt.firstFailure={error:error.stack??String(error)}}
receipt.outputs=existsSync(join(out,'original-outputs.jsonl'))?bind(join(out,'original-outputs.jsonl')):null;save();console.log(JSON.stringify(receipt));if(receipt.status!=='passed')process.exitCode=1;
