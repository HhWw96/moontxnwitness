from pathlib import Path
import ctypes,os,json,shutil,hashlib,subprocess,sys
OUT=Path(__file__).resolve().parent
class M(ctypes.Structure):
 _fields_=[('length',ctypes.c_ulong),('load',ctypes.c_ulong),('totalPhys',ctypes.c_ulonglong),('availPhys',ctypes.c_ulonglong),('totalPage',ctypes.c_ulonglong),('availPage',ctypes.c_ulonglong),('totalVirtual',ctypes.c_ulonglong),('availVirtual',ctypes.c_ulonglong),('availExtended',ctypes.c_ulonglong)]
def resources():
 m=M();m.length=ctypes.sizeof(m)
 if not ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m)):raise ctypes.WinError()
 r={'cFreeBytes':shutil.disk_usage('C:\\').free,'dFreeBytes':shutil.disk_usage('D:\\').free,'availablePhysicalMemoryBytes':m.availPhys,'memoryLoadPercent':m.load};r['gatePassed']=r['cFreeBytes']>=805306368 and r['dFreeBytes']>=1073741824 and r['availablePhysicalMemoryBytes']>=int(1.2*1073741824);return r
def binding(p):
 b=p.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def save(n,v):
 p=OUT/n;p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('x',encoding='utf8',newline='\n') as f:f.write(json.dumps(v,indent=2)+'\n');f.flush();os.fsync(f.fileno())



runner=OUT.parent/'compare-capture-continuation.mjs'
expectedRunnerSha='5012f17354f9753ff1d3cf803e2fe89280be770cdd04b5f1aa7dde4e9baa15f1'
expectedPlanSha='d2bfa776d0643f17f243c986d6804878e9c893df1d840cd06910e34d45225028'
expectedBindingSha='754c2d009ecd44dcc5bfa91a8b362decd15250ef9c0303c5c505fdfb6487ba3b'

receipt={'format':'streaming-guard-pending19-single-use/v1','status':'not-executed','performanceMeasured':False,'previousCompleteCaseCount':176,'pendingCaseCount':19,'nodeInvocations':0,'firstResourceRefusalPreserved':True}
try:
 resource=resources();save('RESOURCE-CHECK-FIRST.json',resource);receipt['resources']=resource
 if not resource['gatePassed']:raise RuntimeError('Runtime-only gate failed before Node; stop without retry')
 assert binding(runner)['sha256']==expectedRunnerSha
 assert binding(OUT.parent/'plan.json')['sha256']==expectedPlanSha
 assert binding(OUT.parent.parent/'runtime-bindings.json')['sha256']==expectedBindingSha
 temporary=OUT.parent.parent/'tmp';assert temporary.is_dir() and str(temporary).lower().startswith('d:\\')
 env={**os.environ,**{key:str(temporary) for key in ['TEMP','TMP','TMPDIR','MTW_SCRATCH','MTW_SCRATCH_DIR']}}
 assert not (OUT.parent/'results-continuation-after-diagnostic-scope-fix').exists(),'Existing result refuses rerun'
 args=[r'D:\nodejs\node.exe',str(runner)];receipt['nodeInvocations']=1
 with (OUT/'process-first.stdout').open('xb') as a,(OUT/'process-first.stderr').open('xb') as b:p=subprocess.run(args,stdout=a,stderr=b,env=env,timeout=600)
 receipt.update(exitCode=p.returncode,stdout=binding(OUT/'process-first.stdout'),stderr=binding(OUT/'process-first.stderr'))
 result=OUT.parent/'results-continuation-after-diagnostic-scope-fix/receipt.json'
 if result.exists():receipt['comparisonReceipt']=binding(result);receipt['comparisonResult']=json.loads(result.read_text())
 receipt['status']='passed' if p.returncode==0 and receipt.get('comparisonResult',{}).get('status')=='passed-output-equivalence' else 'failed-first-retained'
except BaseException as e:receipt['status']='blocked-or-failed-first-retained';receipt['failure']={'type':type(e).__name__,'message':str(e)}
finally:receipt['driver']=binding(Path(__file__));save('PROCESS-FIRST.json',receipt);print(json.dumps(receipt),flush=True)
if receipt['status']!='passed':sys.exit(2)
