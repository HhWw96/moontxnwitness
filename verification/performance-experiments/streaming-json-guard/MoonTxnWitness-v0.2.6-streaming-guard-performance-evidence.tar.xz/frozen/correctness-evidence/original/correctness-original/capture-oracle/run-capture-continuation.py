from pathlib import Path
import ctypes,os,json,shutil,hashlib,subprocess,sys
OUT=Path(__file__).resolve().parent
class M(ctypes.Structure):
 _fields_=[('length',ctypes.c_ulong),('load',ctypes.c_ulong),('totalPhys',ctypes.c_ulonglong),('availPhys',ctypes.c_ulonglong),('totalPage',ctypes.c_ulonglong),('availPage',ctypes.c_ulonglong),('totalVirtual',ctypes.c_ulonglong),('availVirtual',ctypes.c_ulonglong),('availExtended',ctypes.c_ulonglong)]
def resources():
 m=M();m.length=ctypes.sizeof(m)
 if not ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m)):raise ctypes.WinError()
 r={'cFreeBytes':shutil.disk_usage('C:\\').free,'dFreeBytes':shutil.disk_usage('D:\\').free,'availablePhysicalMemoryBytes':m.availPhys,'memoryLoadPercent':m.load};r['gatePassed']=r['cFreeBytes']>=805306368 and r['dFreeBytes']>=1073741824 and r['availablePhysicalMemoryBytes']>=int(1.2*1073741824);return r
def binding(p):
 b=p.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def save(n,v):
 p=OUT/n;p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('x',encoding='utf8',newline='\n') as f:f.write(json.dumps(v,indent=2)+'\n');f.flush();os.fsync(f.fileno())


resource=resources();save('execution-resource-continuation.json',resource);print(json.dumps(resource),flush=True)
if not resource['gatePassed']:raise RuntimeError('Runtime-only resource gate failed; no SDK execution')
args=[r'D:\nodejs\node.exe',str(OUT/'compare-capture-continuation.mjs')]
env={**os.environ,**{key:str(OUT.parent/'tmp') for key in ['TEMP','TMP','TMPDIR','MTW_SCRATCH','MTW_SCRATCH_DIR']}}
with (OUT/'process-continuation.stdout').open('xb') as a,(OUT/'process-continuation.stderr').open('xb') as b:p=subprocess.run(args,stdout=a,stderr=b,env=env,timeout=600)
result={'exitCode':p.returncode,'stdout':binding(OUT/'process-continuation.stdout'),'stderr':binding(OUT/'process-continuation.stderr'),'driver':binding(Path(__file__)),'resource':resource,'performanceMeasured':False}
if (OUT/'results-continuation-after-diagnostic-scope-fix/receipt.json').exists():result['receipt']=binding(OUT/'results-continuation-after-diagnostic-scope-fix/receipt.json');result['result']=json.loads((OUT/'results-continuation-after-diagnostic-scope-fix/receipt.json').read_text())
save('PROCESS-CONTINUATION.json',result);print(json.dumps(result),flush=True)
if p.returncode:sys.exit(p.returncode)
