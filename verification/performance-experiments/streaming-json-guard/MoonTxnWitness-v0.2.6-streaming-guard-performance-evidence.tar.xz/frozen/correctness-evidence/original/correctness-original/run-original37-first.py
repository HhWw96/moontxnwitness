from pathlib import Path
import ctypes,os,json,shutil,hashlib,subprocess,sys,datetime
OUT=Path(__file__).resolve().parent
class M(ctypes.Structure):
 _fields_=[('length',ctypes.c_ulong),('load',ctypes.c_ulong),('totalPhys',ctypes.c_ulonglong),('availPhys',ctypes.c_ulonglong),('totalPage',ctypes.c_ulonglong),('availPage',ctypes.c_ulonglong),('totalVirtual',ctypes.c_ulonglong),('availVirtual',ctypes.c_ulonglong),('availExtended',ctypes.c_ulonglong)]
def resources():
 m=M();m.length=ctypes.sizeof(m)
 if not ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m)):raise ctypes.WinError()
 r={'cFreeBytes':shutil.disk_usage('C:\\').free,'dFreeBytes':shutil.disk_usage('D:\\').free,'availablePhysicalMemoryBytes':m.availPhys,'memoryLoadPercent':m.load};r['gatePassed']=r['cFreeBytes']>=1073741824 and r['dFreeBytes']>=1073741824 and r['availablePhysicalMemoryBytes']>=int(1.2*1073741824);return r
def binding(p):
 b=p.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def save(n,v):
 p=OUT/n;p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('x',encoding='utf8',newline='\n') as f:f.write(json.dumps(v,indent=2)+'\n');f.flush();os.fsync(f.fileno())

receipt={'format':'streaming-guard-original37-differential/v1','status':'running','performanceMeasured':False,'warmups':0,'rootWrites':False,'stages':[]}
old=Path(r'D:\CodexScratch\MoonTxnWitness-model-empty-interval-graph-reuse-20261024-a')
try:
 for mode in ['core','sdk','legacy']:
  resource=resources();save(mode+'-resource-first.json',resource);print(json.dumps({'mode':mode,'resource':resource}),flush=True)
  if not resource['gatePassed']:raise RuntimeError('Resource gate failed before '+mode)
  resultdir=OUT/(mode+'-original-first')
  args=[r'D:\nodejs\node.exe',str(old/'compare-fixed-v2.mjs'),'--execute','--mode',mode,'--bindings',str(OUT/'runtime-bindings.json'),'--out',str(resultdir),'--allow-128']
  with (OUT/(mode+'-first.stdout')).open('xb') as a,(OUT/(mode+'-first.stderr')).open('xb') as b:p=subprocess.run(args,stdout=a,stderr=b,env={**os.environ,'TEMP':str(OUT/'tmp'),'TMP':str(OUT/'tmp')},timeout=600)
  stage={'mode':mode,'exitCode':p.returncode,'stdout':binding(OUT/(mode+'-first.stdout')),'stderr':binding(OUT/(mode+'-first.stderr'))}
  if (resultdir/'receipt.json').exists():
   report=json.loads((resultdir/'receipt.json').read_text());stage.update({'receipt':binding(resultdir/'receipt.json'),'status':report['status'],'cases':len(report['caseResults']),'checks':report['checks'],'firstFailure':report['firstFailure']})
  receipt['stages'].append(stage);print(json.dumps(stage),flush=True)
  if p.returncode or stage.get('status')!='passed':raise RuntimeError('Original differential failed; first evidence retained')
 receipt['status']='passed'
except BaseException as e:receipt['status']='failed-first-retained';receipt['failure']={'type':type(e).__name__,'message':str(e)}
finally:
 receipt['driver']=binding(Path(__file__));save('ORIGINAL37-FIRST.json',receipt);print(json.dumps(receipt),flush=True)
if receipt['status']!='passed':sys.exit(2)
