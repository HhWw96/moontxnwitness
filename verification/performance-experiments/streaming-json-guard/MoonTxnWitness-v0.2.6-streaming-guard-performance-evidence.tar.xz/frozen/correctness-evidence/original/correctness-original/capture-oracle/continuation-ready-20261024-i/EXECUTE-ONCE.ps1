& 'D:\Border\python\python.exe' -B 'D:\CodexScratch\MoonTxnWitness-streaming-json-guard-candidate-20261024-f\correctness-fix2\capture-oracle\continuation-ready-20261024-i\run-pending19-once.py'
