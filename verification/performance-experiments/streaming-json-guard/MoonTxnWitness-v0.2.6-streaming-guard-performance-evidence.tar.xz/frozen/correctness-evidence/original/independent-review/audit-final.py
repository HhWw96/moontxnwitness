from pathlib import Path
import json,hashlib,collections,copy
BASE=Path(r'D:\CodexScratch\MoonTxnWitness-streaming-json-guard-candidate-20261024-f')
ROOT=BASE/'correctness-fix2'
OUT=Path(r'D:\CodexScratch\MoonTxnWitness-streaming-json-runtime-independent-review-20261024-k')
OUT.mkdir(exist_ok=False)
checks=0; manifest=[]
def ck(ok,label):
 global checks
 checks+=1
 if not ok:raise AssertionError(label)
def load(p):return json.loads(p.read_text('utf-8-sig'))
def bind(p):
 b=p.read_bytes();v={'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()};manifest.append(v);return v
def frozen(p,want):
 got=bind(p);ck(got['bytes']==want['bytes'] and got['sha256']==want['sha256'],'Frozen byte binding: '+str(p));return got
bindings=load(ROOT/'runtime-bindings.json');binding=bind(ROOT/'runtime-bindings.json')
ck(binding['sha256']=='754c2d009ecd44dcc5bfa91a8b362decd15250ef9c0303c5c505fdfb6487ba3b','final runtime binding sha')
for role in ['baseline','candidate']:
 cfg=bindings[role];r=Path(cfg['directory']);rels=set()
 ck(len(cfg['files'])==47,'47 runtime files/'+role)
 for f in cfg['files']:
  ck(f['path'] not in rels and '..' not in Path(f['path']).parts and not Path(f['path']).is_absolute(),'safe unique runtime binding')
  rels.add(f['path']);frozen(r/f['path'],f)
 actual={str(x.relative_to(r)).replace('\\','/') for x in r.rglob('*') if x.is_file()}
 ck(actual==rels,'exact47 closure/'+role)
 core=next(f for f in cfg['files'] if f['path']=='core.mjs')
 cap=next(f for f in cfg['files'] if f['path']=='capture-core.mjs')
 ck(cfg['buildManifest']['coreSha256']==core['sha256'],'manifest core/'+role)
 ck(cfg['buildManifest']['captureCoreSha256']==cap['sha256'],'manifest capture/'+role)
bcore=bindings['baseline']['buildManifest']['coreSha256'];ccore=bindings['candidate']['buildManifest']['coreSha256']
ck(bcore=='132774cb868bbd08c95f86577871bc326c59bd2fb3db5565b27a46883f68e5e1','public original baseline core')
ck(ccore=='0e11e5b9bf1cb0a72786e1bb44a1638143c0d00c39663b2890a30dc2dac094d5','final candidate core')
for k in ['actualRunner','plan','historicalLfRunnerManifest']:frozen(Path(bindings[k]['path']),bindings[k])
oldplan=load(Path(bindings['plan']['path'])); oldroot=Path(bindings['plan']['path']).parent
ck(len(oldplan['cases'])==37,'37 frozen classifier cases')
class_summary=[]
for mode in ['core','sdk']:
 d=ROOT/(mode+'-runtime-gate-adjusted-first');rc=load(d/'receipt.json');bind(d/'receipt.json')
 ck(rc['status']=='passed' and rc['firstFailure'] is None and len(rc['caseResults'])==37,'actual successful receipt/'+mode)
 ck(rc['bindingsSha256']==binding['sha256'],'receipt runtime/'+mode)
 ck(rc['planSha256']==bindings['plan']['sha256'],'receipt plan/'+mode)
 for case in oldplan['cases']:
  cid=case['id'];raw=(d/(cid+'.input.json')).read_bytes();ck(hashlib.sha256(raw).hexdigest()==case['sha256'],'frozen input/'+mode+'/'+cid);bind(d/(cid+'.input.json'))
  bb=(d/(cid+'.baseline.json')).read_text('utf-8');cb=(d/(cid+'.candidate.json')).read_text('utf-8');bind(d/(cid+'.baseline.json'));bind(d/(cid+'.candidate.json'))
  if mode=='core':
   ck(bb==cb,'exact core report/'+cid)
   vr=load(d/(cid+'.verification.json'));bind(d/(cid+'.verification.json'))
   ck(vr['baselineRaw']==vr['candidateRaw'] and json.loads(vr['baselineRaw'])['valid'] is True,'core reproduced/'+cid)
  else:
   bv=json.loads(bb);cv=json.loads(cb)
   ck(bv['engine']['coreSha256']==bcore and cv['engine']['coreSha256']==ccore,'actual engine fingerprints/'+cid)
   ck(bb.count(bcore)==1 and cb==bb.replace(bcore,ccore),'sole permitted raw SDK difference/'+cid)
   expected=copy.deepcopy(bv);expected['engine']['coreSha256']=ccore
   ck(expected==cv,'sole permitted semantic SDK difference/'+cid)
 ck([x['id'] for x in rc['caseResults']]==[x['id'] for x in oldplan['cases']],'case order/'+mode)
 class_summary.append({'mode':mode,'completeCases':37,'authorChecks':rc['checks'],'independentFullOutputComparison':True})
legacy=ROOT/'legacy-runtime-gate-adjusted-first';lrc=load(legacy/'receipt.json');bind(legacy/'receipt.json')
ck(lrc['status']=='passed' and lrc['checks']==335,'legacy receipt')
legacy_orig=0;legacy_tamper=0
for case in oldplan['legacyReportSets']:
 cid=case.get('id',case['path'].replace('/','-'));p=legacy/(cid+'.input.json');raw=p.read_bytes();bind(p);ck(hashlib.sha256(raw).hexdigest()==case['sha256'],'legacy frozen input')
 samples=json.loads(raw);observations=load(legacy/(cid+'.outputs.json'));bind(legacy/(cid+'.outputs.json'))
 want=[]
 for s in samples:
  want.append((s['id'],'original'))
  want.extend((s['id'],k) for k in ['unknown-version','unknown-algorithm','changed-status'])
  if isinstance(json.loads(s['reportText']).get('error'),str):want.append((s['id'],'changed-original-diagnostic'))
 ck(want==[(x['id'],x['kind']) for x in observations],'legacy complete mutation sequence')
 for x in observations:
  ck(x['baselineRaw']==x['candidateRaw'],'legacy exact response')
  original=x['kind']=='original';ck(json.loads(x['baselineRaw'])['valid'] is original,'legacy expected acceptance')
  legacy_orig+=original;legacy_tamper+=not original
ck((legacy_orig,legacy_tamper)==(14,48),'legacy14+48')
cap=ROOT/'capture-oracle';plan=load(cap/'plan.json');cpbind=bind(cap/'plan.json')
ck(cpbind['sha256']=='d2bfa776d0643f17f243c986d6804878e9c893df1d840cd06910e34d45225028','capture frozen original plan')
ck(len(plan['cases'])==195 and len({x['id'] for x in plan['cases']})==195,'195 unique capture input cases')
for x in plan['cases']:frozen(cap/x['input']['path'],x['input'])
for x in plan['originalSources']:frozen(Path(x['path']),x)
sdk={'normalize_capture_json':'normalizeCapture','normalize_presence_json':'normalizePresenceCapture','normalize_capture_v3_json':'normalizeCaptureV3','normalize_capture_v3_options_json':'normalizeCaptureV3','inspect_execution_failures_v3_json':'inspectExecutionFailuresV3','dislock_sql_v3_proof_json':'inspectDislockCaptureV3','orm_sql_source2_v3_proof_json':'inspectOrmSourceV3'}
def schedule(row):
 cid=row['id']
 if row['kind']=='guard':return [(cid,m,'direct') for m in plan['allEightExports']]+[(cid,'classify_v3_json','core')]
 if row['kind']=='options':return [(cid,'classify_v3_json','core'),(cid,'normalize_capture_v3_options_json','direct')]
 if row['kind']=='profile':return [(cid,'orm_profile_source_v3_json','core'),(cid,row['method'],'sdk'),(cid,'verifyOrmProfileV3','sdk'),(cid+'-report-tamper','verifyOrmProfileV3','sdk')]
 out=[(cid,row['method'],'direct')]
 if row['method'] in sdk:out.append((cid,sdk[row['method']],'sdk'))
 return out
rawfile=cap/'results-reference-fixed/original-outputs.jsonl';rows=[json.loads(x) for x in rawfile.read_text('utf-8').splitlines()];rawbind=bind(rawfile)
rc=load(cap/'results-reference-fixed/receipt.json');bind(cap/'results-reference-fixed/receipt.json')
ck(rawbind['sha256']==rc['outputs']['sha256'] and rawbind['bytes']==rc['outputs']['bytes'],'raw1130 binding')
ck(rc['plan']=={k:cpbind[k] for k in ['bytes','sha256']},'capture receipt plan')
for name in ['compare-capture-first.mjs','compare-capture-reference-fixed.mjs','compare-capture-continuation.mjs']:bind(cap/name)
ck(bind(cap/'compare-capture-reference-fixed.mjs')['sha256']==rc['runner']['sha256'],'second runner exact byte binding')
ck(rc['cases']==176 and rc['status']=='failed-first-retained','completed176 with retained failure')
expected=[s for row in plan['cases'][:176] for s in schedule(row)]
partial=schedule(plan['cases'][176])[:5]
ck(len(expected)==560,'first176 exactly560 output pairs')
ck([(x['id'],x['method'],x['kind']) for x in rows]==expected+partial,'full176 and exact partial177 call sequence')
for x in rows:
 ck(x['baseline']==x['candidate'],'all565 original outputs identical')
 ck(x['baseline']['kind']=='return','public exports returned serialized report')
 json.loads(x['baseline']['text'])
kind_calls={k:2*v for k,v in collections.Counter(x['kind'] for x in rows).items()}
ck(kind_calls=={k:rc[k+'Calls'] for k in ['direct','core','sdk']},'actual method counters1130')
by={(x['id'],x['method'],x['kind']):x for x in rows}
mismatches=[];profile=[]
for row in plan['cases'][:176]:
 if row.get('baselineAssertion'):
  method=row['method'];kind='sdk' if row['kind']=='profile' else 'direct'
  v=json.loads(by[(row['id'],method,kind)]['baseline']['text']);want=row['baselineAssertion']
  ok=v.get(want['field'])==want['value']
  if row['id'].startswith('v3-'):
   if not ok:mismatches.append({'id':row['id'],'field':want['field'],'expected':want['value'],'actual':v.get(want['field'])})
  else:ck(ok,'mandatory nonhistorical targeted assertion')
 if row['kind']=='profile':
  cid=row['id'];a=json.loads(by[(cid,row['method'],'sdk')]['baseline']['text'])
  ver=json.loads(by[(cid,'verifyOrmProfileV3','sdk')]['baseline']['text'])
  tam=json.loads(by[(cid+'-report-tamper','verifyOrmProfileV3','sdk')]['baseline']['text'])
  ck(ver['valid'] is True and tam['valid'] is False,'profile reproduction + tamper rejection/'+cid)
  profile.append({'id':cid,'status':a['status'],'analysisCoverageAccepted':a['analysisCoverageAccepted'],'originalVerifies':True,'tamperedStatusRejected':True})
ck(len(mismatches)==2,'two retained oldmanifest references')
ck(rc['oldV3ManifestMismatches']==[{**x,'passed':False} for x in mismatches],'oldreference mismatch record')
historical=load(cap/'historical-manifest-reference-mismatches/REVIEW.json');bind(cap/'historical-manifest-reference-mismatches/REVIEW.json')
ck(historical['historicalManifestMatched'] is False and historical['manifestExpectationsChanged'] is False,'historical status not upgraded')
frozen(Path(historical['manifest']['path']),historical['manifest'])
for x in historical['mismatches']:
 frozen(Path(x['baseline']['path']),x['baseline']);frozen(Path(x['candidate']['path']),x['candidate'])
 ck(Path(x['baseline']['path']).read_bytes()==Path(x['candidate']['path']).read_bytes(),'historical public+candidate raw same')
first=load(cap/'results-first/receipt.json');bind(cap/'results-first/receipt.json');frozen(cap/'results-first/original-outputs.jsonl',first['outputs'])
firstrows=[json.loads(x) for x in (cap/'results-first/original-outputs.jsonl').read_text('utf-8').splitlines()]
ck(len(firstrows)==25 and all(x['baseline']==x['candidate'] for x in firstrows),'first50 exact but reference assertion failed')
ck(first['cases']==12 and 'Frozen original expectation failed' in first['firstFailure']['error'],'first failure retained')
ck('equivalent emoji fixture' in rc['firstFailure']['error'],'second assertion failure retained')
for rel in ['REFERENCE-HARNESS-CORRECTION.json','DIAGNOSTIC-SCOPE-HARNESS-CORRECTION.json','execution-resource-continuation.json','continuation-ready-20261024-h/run-pending19-once.py','continuation-ready-20261024-i/run-pending19-once.py','continuation-ready-20261024-i/EXECUTE-ONCE.ps1']:bind(cap/rel)
continuation=cap/'results-continuation-after-diagnostic-scope-fix'
crc=load(continuation/'receipt.json');crcb=bind(continuation/'receipt.json')
ck(crcb['sha256']=='1a7bb27d8c492eb3f76d750b00dec05c1f2f9053ccd2b2c99218749971d2163a','continuation actual receipt')
ck(crc['status']=='passed-output-equivalence' and crc['cases']==19 and crc['firstFailure'] is None,'19 actually passed')
ck(crc['plan']==rc['plan'] and crc['runtimeBindings']==rc['runtimeBindings'],'continuation same frozen plan and runtimes')
craw=continuation/'original-outputs.jsonl';frozen(craw,crc['outputs'])
crows=[json.loads(x) for x in craw.read_text('utf-8').splitlines()]
cschedule=[s for row in plan['cases'][176:] for s in schedule(row)]
ck([(x['id'],x['method'],x['kind']) for x in crows]==cschedule,'exact19 unique input schedule')
ck(len(crows)==129,'continuation129 output pairs258calls')
for x in crows:
 ck(x['baseline']==x['candidate'] and x['baseline']['kind']=='return','continuation exact full actual reports')
 json.loads(x['baseline']['text'])
ck({k:2*v for k,v in collections.Counter(x['kind'] for x in crows).items()}=={'direct':220,'core':38},'continuation220direct+38core')
ck(crc['oldV3ManifestReferences']==[] and crc['oldV3ManifestAllReferencesPassed'] is True,'continuation local historical true is vacuous')
wrapper=load(cap/'continuation-ready-20261024-i/PROCESS-FIRST.json');bind(cap/'continuation-ready-20261024-i/PROCESS-FIRST.json')
ck(wrapper['nodeInvocations']==1 and wrapper['status']=='passed' and wrapper['exitCode']==0,'actual authorized one continuation subprocess')
ck(wrapper['resources']['gatePassed'] is True,'normal resource gate passed')
ck(wrapper['comparisonResult']==crc and wrapper['comparisonReceipt']=={k:crcb[k] for k in ['bytes','sha256']},'wrapper exact actual continuation receipt')
for name in ['stdout','stderr']:
 matches=[x for x in (cap/'continuation-ready-20261024-i').iterdir() if x.is_file() and x.suffix=='.'+name]
 for x in matches:frozen(x,wrapper[name])
combined=rows[:560]+crows
ck(len(combined)==689,'complete195 unique689 pair calls')
ck([(x['id'],x['method'],x['kind']) for x in combined]==[v for row in plan['cases'] for v in schedule(row)],'complete ordered195 exact schedule')
complete_map=[];offset=0
for i,row in enumerate(plan['cases']):
 count=len(schedule(row));sub=combined[offset:offset+count];ck(len(sub)==count,'each complete case has every required method')
 complete_map.append({'index':i,'id':row['id'],'sourceSegment':'first176' if i<176 else 'continuation19','pairCount':count,'actualFunctionCalls':2*count,'firstUniquePairIndex':offset,'fullActualPublicOutputsExact':True})
 offset+=count
for a,b in zip(rows[560:],crows[:5]):ck(a==b,'partial177 repeated originals exactly same in continuation')
all_attempt_rows=firstrows+rows+crows
observed_calls=2*len(all_attempt_rows);unique_calls=2*len(combined)
ck(observed_calls==1438 and unique_calls==1378,'actual raw aggregate not guessed')

cont=(cap/'compare-capture-continuation.mjs').read_text('utf-8')
ck('plan.cases.slice(176)' in cont,'continuation selects19 only')
ck("&&name==='normalize_capture_v3_json'" in cont,'extra duplicate diagnostic only exposing API')
ck("JSON.stringify(b)===JSON.stringify(c)" in cont,'full equality remains mandatory for every export')
guards=[]
for x in combined:
 if x['id'].startswith('guard-') and x['method']=='normalize_capture_v3_json':
  v=json.loads(x['baseline']['text']);guards.append({'id':x['id'],'error':v.get('error'),'exactBoth':True,'completeCase':True})
source=bind(BASE/'candidate-source/src/json_guard.mbt');patch=bind(BASE/'fix2/FINAL-streaming-json-guard.patch')
ck(source['sha256']=='a003f4c774730c19276e2274a226cca0342e8b9c1a3004ce5971286473a9f932','reviewed final source stable')
bind(BASE/'HANDOFF-PARTIAL-20261024-i.json')

source_review=Path(r'D:\CodexScratch\MoonTxnWitness-streaming-json-source-review-20261024-g/FINAL-SOURCE-REVIEW.json')
source_receipt=load(source_review);bind(source_review)
ck(source_receipt.get('sourceReviewPassed') is True,'prior independent source review passed')
first_state=Path(r'D:\CodexScratch\MoonTxnWitness-streaming-json-runtime-independent-review-20261024-j/FIRST-AUDIT-STATE-CHANGE.json');bind(first_state)
aggregate={'format':'moontxnwitness-streaming-guard-baseline-compatibility-aggregate/v1','passed':True,'scope':'Full actual serialized public baseline/candidate output compatibility for exactly195 frozen capture cases; not historical manifest correctness, SQL-source completeness, new database execution, performance, other targets, or release adoption.','baselineCoreSha256':bcore,'candidateCoreSha256':ccore,'baselineCaptureSha256':bindings['baseline']['buildManifest']['captureCoreSha256'],'candidateCaptureSha256':bindings['candidate']['buildManifest']['captureCoreSha256'],'runtimeBindings':binding,'plan':cpbind,'segments':[{'completeCases':176,'completePairCount':560,'completeActualCalls':1120,'retainedPartialNextCasePairs':5,'retainedPartialActualCalls':10,'actualRecordedPairCount':len(rows),'actualRecordedCalls':2*len(rows),'receipt':bind(cap/'results-reference-fixed/receipt.json'),'rawOriginals':rawbind,'originalReceiptRemainsFailed':True},{'completeCases':19,'completePairCount':len(crows),'completeActualCalls':2*len(crows),'receipt':crcb,'rawOriginals':bind(craw),'actualNodeInvocations':1,'authorChecks':crc['checks']}],'uniqueCompleteCases':195,'uniqueCompleteOutputPairs':len(combined),'uniqueCompleteFunctionCalls':unique_calls,'totalRecordedCallsAcrossSecondAndContinuation':2*(len(rows)+len(crows)),'firstStoppedHarness':{'completeCases':12,'recordedOutputPairs':len(firstrows),'recordedFunctionCalls':2*len(firstrows),'receipt':bind(cap/'results-first/receipt.json'),'excludedFromUniqueAggregate':True,'originalReceiptRemainsFailed':True},'totalRecordedCallsAcrossAllThreeCaptureHarnessExecutions':observed_calls,'oldHistoricalManifest':{'matched':False,'expectationsChanged':False,'mismatches':mismatches,'last19AllReferencesPassedTrueIsLocalEmptyListOnly':True,'originalReferenceCountFirst176':len(rc['oldV3ManifestReferences']),'referenceCountLast19':0},'completeCaseMap':complete_map,'actualFunctionCallsAreBothRolesAndExcludeVersionProbes':True,'captureAllEightExportsActuallyCalled':True,'reviewerSdkCalls':0,'reviewerCompilationCalls':0,'reviewerTimedRuns':0}
(OUT/'BASELINE-COMPATIBILITY-AGGREGATE.json').write_text(json.dumps(aggregate,ensure_ascii=True,indent=2)+'\n','utf-8')
agg_binding=bind(OUT/'BASELINE-COMPATIBILITY-AGGREGATE.json')
report={'format':'moontxnwitness-streaming-guard-independent-runtime-review/v1','status':'passed-scoped-baseline-compatibility','auditExecution':{'sdkCalls':0,'compilations':0,'timedRuns':0,'authorFilesChanged':False,'readOnlyInputChecks':True,'checks':checks},'baselineCoreSha256':bcore,'candidateCoreSha256':ccore,'candidateCaptureSha256':bindings['candidate']['buildManifest']['captureCoreSha256'],'runtimeClosure':{'filesEach':47,'bothRolesAllBytesRehashed':True,'actualDiskClosureMatched':True},'classification':class_summary,'old25':{'originalReports':legacy_orig,'tamperVariants':legacy_tamper,'authorChecks':335,'exactAllVerifierResponses':True},'capture':{'plannedCases':195,'completeUniqueCases':195,'uniqueCompleteOutputPairs':len(combined),'uniqueCompleteFunctionCalls':unique_calls,'allObservedFunctionCallsIncludingRetainedRetries':observed_calls,'allActualObservedSerializedPublicOutputsExact':True,'baselineCompatibilityPassed':True,'historicalManifestMatched':False,'historicalManifestMismatches':mismatches,'oldManifestBytesUnchanged':True,'last19HistoricalTrueIsLocalEmptyListOnly':True,'allEightCaptureExportsActuallyCalled':True,'profileCases':profile,'guardDiagnosticOriginals':guards,'sourceProofScope':'All seven raw dislock proof calls and all four source1/source2 proof samples refuse analysisCoverageAccepted. These are compatibility observations, not accepted-source positive cases. Two genuine profile packets plus six valid index repositionings do accept; six malformed index variants refuse.','scopeLimitations':['No new database execution; existing captured bytes only.','These JS scoped actual-output checks do not replace four-target regression or public package installation.','Legacy manifest mismatch is an existing baseline/reference divergence, not a candidate regression, and remains unresolved.']},'retainedFailures':{'initialProduct754of756':'Retained in author handoff; source correction preserves original748 unchanged; wrong newly added emoji fixture corrected only in new input.','firstCaptureHarness':'12 complete +partial13th/50calls: historical expectation inconclusive vs actual public+candidate ready; old manifest unchanged.','secondCaptureHarness':'176 complete +partial177th/1130calls: summary API omits Duplicate details; extra text assertion narrowed in continuation, every full-output equality requirement unchanged.','continuationResourceRefusal':'Preserved before actual parent-authorized execution at normal resource thresholds.','firstIndependentReadHelper':'Default GBK raw read failed before writes; explicit UTF8 fixed only reviewer read.','firstIndependentAuditStateAssumption':'Pending-state assertion stopped when parent concurrently completed19; retained own failure receipt then independently audited new actual originals. No SDK rerun.'},'reviewedSource':source,'reviewedPatch':patch,'baselineCompatibilityAggregate':agg_binding,'performanceStageReady':True,'performanceStageScope':'Eligible for separately frozen formal performance of the reviewed unchanged private JS candidate; no speedup, adoption, release or cross-target claim.','adoptionReady':False,'performanceClaim':None,'nextGate':'Freeze all source/runtime/input/output evidence and preserve original failed receipts; perform parent-authorized formal measurement once with controls. Adopt only after performance and remaining applicable release checks pass.'}
(OUT/'REVIEW.json').write_text(json.dumps(report,ensure_ascii=True,indent=2)+'\n','utf-8')
(OUT/'INPUT-BYTE-MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=True,indent=2)+'\n','utf-8')
print(json.dumps({'report':str(OUT/'REVIEW.json'),'reportSha256':hashlib.sha256((OUT/'REVIEW.json').read_bytes()).hexdigest(),'aggregate':str(OUT/'BASELINE-COMPATIBILITY-AGGREGATE.json'),'aggregateSha256':agg_binding['sha256'],'checks':checks,'completeCases':195,'uniqueCompleteCalls':unique_calls,'allRecordedCallsAcrossThreeAttempts':observed_calls,'historicalManifestMatched':False,'performanceStageReady':True,'adoptionReady':False},indent=2))
