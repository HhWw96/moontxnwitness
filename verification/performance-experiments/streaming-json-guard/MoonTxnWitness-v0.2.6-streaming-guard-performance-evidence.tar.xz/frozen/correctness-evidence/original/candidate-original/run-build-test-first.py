from pathlib import Path
import ctypes,os,json,shutil,hashlib,subprocess,sys,datetime
OUT=Path(__file__).resolve().parent;SOURCE=OUT/'candidate-source'
BASE=Path(r'D:\CodexScratch\MoonTxnWitness-model-empty-interval-graph-reuse-20261024-a/baseline-source')
ROOT=Path(r'D:\CodexScratch\MoonTxnWitness-release-20261023')
class M(ctypes.Structure):
 _fields_=[('length',ctypes.c_ulong),('load',ctypes.c_ulong),('totalPhys',ctypes.c_ulonglong),('availPhys',ctypes.c_ulonglong),('totalPage',ctypes.c_ulonglong),('availPage',ctypes.c_ulonglong),('totalVirtual',ctypes.c_ulonglong),('availVirtual',ctypes.c_ulonglong),('availExtended',ctypes.c_ulonglong)]
def resources():
 m=M();m.length=ctypes.sizeof(m)
 if not ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m)):raise ctypes.WinError()
 r={'cFreeBytes':shutil.disk_usage('C:\\').free,'dFreeBytes':shutil.disk_usage('D:\\').free,'availablePhysicalMemoryBytes':m.availPhys,'memoryLoadPercent':m.load};r['gatePassed']=r['cFreeBytes']>=1073741824 and r['dFreeBytes']>=1073741824 and r['availablePhysicalMemoryBytes']>=int(1.2*1073741824);return r
def binding(p):
 b=p.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def save(n,v):
 p=OUT/n;p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('x',encoding='utf8',newline='\n') as f:f.write(json.dumps(v,indent=2)+'\n');f.flush();os.fsync(f.fileno())
prep=json.loads((OUT/'PREPARATION.json').read_text(encoding='utf8'))
r={'format':'moontxnwitness-streaming-guard-first-build-tests/v1','startedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'running','formatterInvocations':0,'compilerBuildInvocations':0,'fullJSTestInvocations':0,'existingCoreTestsRequired':748,'addedTests':8,'performanceMeasured':False,'rootWrites':False,'failures':[],'stages':[]}
try:
 tmp=OUT/'tmp';tmp.mkdir()
 home=Path(json.loads((ROOT/'.local-toolchain.json').read_text(encoding='utf8'))['moonHome']);moon=home/'bin/moon.exe'
 env={**os.environ,'MOON_HOME':str(home),'TEMP':str(tmp),'TMP':str(tmp),'PYTHONDONTWRITEBYTECODE':'1'}
 env['PATH']=str(home/'bin')+os.pathsep+r'D:\nodejs'+os.pathsep+env.get('PATH',env.get('Path',''))
 for name,expected in prep['baseFiles'].items():
  if name!='src/json_guard.mbt':assert binding(SOURCE/name)==expected,name
 before_files={str(p.relative_to(SOURCE)).replace('\\','/'):binding(p) for p in SOURCE.rglob('*') if p.is_file()}
 save('SOURCE-BEFORE-FORMAT.json',before_files)
 snap=OUT/'before-format';snap.mkdir()
 for name in ['json_guard.mbt','streaming_json_guard_wbtest.mbt']:shutil.copyfile(SOURCE/'src'/name,snap/name)
 for label,args in [('format-first',['fmt']),('build-first',['build','--target','js','--release','--deny-warn','--jobs','1']),('test-js-first',['test','--target','js','--deny-warn','--jobs','1'])]:
  resource=resources();save(label+'-resources.json',resource);print(json.dumps({'phase':label+'-preflight',**resource}),flush=True)
  if not resource['gatePassed']:r['status']='resource-blocked-not-retried';raise RuntimeError('Resource gate failed before '+label)
  if label=='format-first':r['formatterInvocations']+=1
  elif label=='build-first':r['compilerBuildInvocations']+=1
  else:r['fullJSTestInvocations']+=1
  outlog=OUT/(label+'.stdout.log');errlog=OUT/(label+'.stderr.log')
  with outlog.open('xb') as a,errlog.open('xb') as b:p=subprocess.run([str(moon),*args],cwd=SOURCE,env=env,stdout=a,stderr=b,timeout=600)
  stage={'stage':label,'exitCode':p.returncode,'stdout':binding(outlog),'stderr':binding(errlog)};r['stages'].append(stage);save(label+'-process.json',stage)
  print(json.dumps(stage),flush=True)
  if p.returncode:raise RuntimeError(label+' failed; original output retained')
  if label=='format-first':
   after={str(p.relative_to(SOURCE)).replace('\\','/'):binding(p) for p in SOURCE.rglob('*') if p.is_file() and '_build' not in p.parts}
   changed=[name for name,expected in prep['baseFiles'].items() if binding(SOURCE/name)!=expected]
   assert changed==['src/json_guard.mbt'],changed
   save('SOURCE-AFTER-FORMAT.json',after)
  if label=='test-js-first':
   text=outlog.read_text(encoding='utf8',errors='replace')+errlog.read_text(encoding='utf8',errors='replace')
   assert 'Total tests: 756, passed: 756, failed: 0' in text,text[-3000:]
   r['existing748PlusNew8Passed']=True
 r['status']='passed'
except BaseException as e:
 r['failures'].append({'type':type(e).__name__,'message':str(e)})
 if r['status']!='resource-blocked-not-retried':r['status']='failed-first-retained'
finally:
 r['completedUtc']=datetime.datetime.now(datetime.timezone.utc).isoformat();r['driver']=binding(Path(__file__));save('BUILD-TEST-FIRST.json',r);print(json.dumps({'status':r['status'],'receipt':str(OUT/'BUILD-TEST-FIRST.json'),'binding':binding(OUT/'BUILD-TEST-FIRST.json'),'stages':r['stages'],'failures':r['failures']}),flush=True)
if r['status']!='passed':sys.exit(2)