from pathlib import Path
import ctypes,shutil,json,hashlib,os,subprocess,sys
OUT=Path(__file__).resolve().parent;BASE=OUT.parent;SOURCE=BASE/'candidate-source'
ROOT=Path(r'D:\CodexScratch\MoonTxnWitness-release-20261023')
def binding(p):
 b=p.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def save(n,v):
 with (OUT/n).open('x',encoding='utf8',newline='\n') as f:f.write(json.dumps(v,indent=2)+'\n');f.flush();os.fsync(f.fileno())
class M(ctypes.Structure):
 _fields_=[('length',ctypes.c_ulong),('load',ctypes.c_ulong),('totalPhys',ctypes.c_ulonglong),('availPhys',ctypes.c_ulonglong),('totalPage',ctypes.c_ulonglong),('availPage',ctypes.c_ulonglong),('totalVirtual',ctypes.c_ulonglong),('availVirtual',ctypes.c_ulonglong),('availExtended',ctypes.c_ulonglong)]
m=M();m.length=ctypes.sizeof(m)
if not ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m)):raise ctypes.WinError()
r={'cFreeBytes':shutil.disk_usage('C:\\').free,'dFreeBytes':shutil.disk_usage('D:\\').free,'availablePhysicalMemoryBytes':m.availPhys,'memoryLoadPercent':m.load};r['gatePassed']=r['cFreeBytes']>=1073741824 and r['dFreeBytes']>=1073741824 and r['availablePhysicalMemoryBytes']>=int(1.2*1073741824)
save('RESOURCES-FIRST.json',r);print(json.dumps({'phase':'test-js-new-state-preflight',**r}),flush=True)
if not r['gatePassed']:save('PROCESS-FIRST.json',{'status':'resource-blocked-not-run','testInvocations':0,'newState':'Parent public receipt verifier93932 exited0'});sys.exit(2)
after=json.loads((BASE/'SOURCE-AFTER-FORMAT.json').read_text(encoding='utf8'))
for name,expected in after.items():assert binding(SOURCE/name)==expected,name
home=Path(json.loads((ROOT/'.local-toolchain.json').read_text(encoding='utf8'))['moonHome']);env={**os.environ,'MOON_HOME':str(home),'TEMP':str(BASE/'tmp'),'TMP':str(BASE/'tmp'),'PYTHONDONTWRITEBYTECODE':'1'};env['PATH']=str(home/'bin')+os.pathsep+r'D:\nodejs'+os.pathsep+env.get('PATH',env.get('Path',''))
args=[str(home/'bin/moon.exe'),'test','--target','js','--deny-warn','--jobs','1']
stdout=OUT/'first.stdout.log';stderr=OUT/'first.stderr.log'
with stdout.open('xb') as a,stderr.open('xb') as b:p=subprocess.run(args,cwd=SOURCE,env=env,stdout=a,stderr=b,timeout=600)
text=stdout.read_text(encoding='utf8',errors='replace')+stderr.read_text(encoding='utf8',errors='replace')
passed=p.returncode==0 and 'Total tests: 756, passed: 756, failed: 0' in text
receipt={'status':'passed' if passed else 'failed-first-retained','exitCode':p.returncode,'compilerReleaseBuildRepeated':False,'testInvocations':1,'originalCoreTests':748,'newMeaningfulTests':8,'expectedTotal':756,'all756Passed':passed,'stdout':binding(stdout),'stderr':binding(stderr),'newState':'Parent public receipt verifier93932 exited0','rootWrites':False,'performanceMeasured':False}
for name,expected in after.items():assert binding(SOURCE/name)==expected,name
save('PROCESS-FIRST.json',receipt);print(json.dumps({'receipt':str(OUT/'PROCESS-FIRST.json'),'binding':binding(OUT/'PROCESS-FIRST.json'),'result':receipt,'tail':text[-2500:]}),flush=True)
if not passed:sys.exit(2)