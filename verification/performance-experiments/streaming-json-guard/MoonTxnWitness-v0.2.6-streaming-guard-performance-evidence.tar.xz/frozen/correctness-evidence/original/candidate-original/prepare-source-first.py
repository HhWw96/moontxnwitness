from pathlib import Path
import json,hashlib,difflib
BASE=Path(r'D:\CodexScratch\MoonTxnWitness-model-empty-interval-graph-reuse-20261024-a')
OUT=Path(r'D:\CodexScratch\MoonTxnWitness-streaming-json-guard-candidate-20261024-f')
def binding(p):
 b=p.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
prepared=json.loads((BASE/'SOURCE-PREPARATION-MANIFEST.json').read_text(encoding='utf8'))
source=OUT/'candidate-source';files={}
for name,expected in prepared['files'].items():
 if not name.startswith('baseline-source/'):continue
 src=BASE/name;assert binding(src)==expected,name
 rel=name[len('baseline-source/'):];dest=source/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(src.read_bytes());files[rel]=expected
old=(BASE/'baseline-source/src/json_guard.mbt').read_text(encoding='utf8')
start=old.index('fn JsonScan::skip_string(');end=old.index('fn guarded_json(')
methods=old[start:end]
methods=methods.replace('JsonScan::','StreamingJsonScan::').replace('self : JsonScan','self : StreamingJsonScan')
methods=methods.replace('self.pos < self.chars.length()','self.current != None').replace('self.pos >= self.chars.length()','self.current == None')
methods=methods.replace('self.chars[self.pos]','self.current.unwrap()').replace('self.pos += 1','self.advance()')
assert 'self.chars' not in methods
stream='''\n///|\n// The original JsonScan remains the exact scalar-indexed raw-index checksum\n// scanner. Large guarded_json inputs only need forward traversal and use one\n// Unicode Char iterator plus one current element instead of a full Char array.\npriv struct StreamingJsonScan {\n  chars : Iter[Char]\n  decoded_keys : Map[String, String]\n  mut current : Char?\n  mut pos : Int\n  mut depth : Int\n}\n\n///|\nfn StreamingJsonScan::new(text : String) -> StreamingJsonScan {\n  let chars = text.iter()\n  { chars, decoded_keys: Map([]), current: chars.next(), pos: 0, depth: 0 }\n}\n\n///|\nfn StreamingJsonScan::advance(self : StreamingJsonScan) -> Unit {\n  if self.current != None {\n    self.pos += 1\n    self.current = self.chars.next()\n  }\n}\n\n///|\n'''+methods
constructor='''  let scan : JsonScan = {\n    chars: text.iter().collect(),\n    decoded_keys: Map([]),\n    pos: 0,\n    depth: 0,\n  }'''
assert old.count(constructor)==1
new=old.replace(constructor,'  let scan = StreamingJsonScan::new(text)').replace('if scan.pos != scan.chars.length() {','if scan.current != None {')+stream
file=source/'src/json_guard.mbt';file.write_text(new,encoding='utf8',newline='\n')
patch=''.join(difflib.unified_diff(old.splitlines(keepends=True),new.splitlines(keepends=True),fromfile='a/src/json_guard.mbt',tofile='b/src/json_guard.mbt'))
(OUT/'streaming-json-guard-source-only.patch').write_text(patch,encoding='utf8',newline='\n')
changes=[name for name,expected in files.items() if binding(source/name)!=expected]
assert changes==['src/json_guard.mbt']
manifest={'format':'moontxnwitness-streaming-json-guard-source-preparation/v1','status':'source-only-not-compiled','frozenBaseSource':'4c74fd29f45c2e6756a20881fefb03677fa9bf52','baseSourcePreparationManifestSha256':binding(BASE/'SOURCE-PREPARATION-MANIFEST.json')['sha256'],'baseFiles':files,'candidateChanges':{name:binding(source/name) for name in changes},'patch':binding(OUT/'streaming-json-guard-source-only.patch'),'oldGraphAliasPatchIncluded':False,'onlyProductionFileChanged':'src/json_guard.mbt','importantProductionDependency':'orm_profile_lifecycle_v3.mbt:336-403 constructs original JsonScan and requires random scalar indexing for byte-preserving index digest. Original JsonScan and its methods are retained unchanged; only guarded_json uses the new forward iterator.','newScanner':'One original text.iter(), one current Char?, forward advance with scalar pos; old UTF16 text.length limit, depth64, official decoded-key parser and StringBuilder retained.','compilerExecuted':False,'SDKExecuted':False,'testsExecuted':False,'performanceMeasured':False,'rootModified':False,'state':'Needs parent review of retained legacy index scanner and source-only patch before build.'}
(OUT/'PREPARATION.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf8',newline='\n')
print(json.dumps({'prepared':True,'candidate':str(source),'sourceFilesCopied':len(files),'changedFiles':changes,'patch':binding(OUT/'streaming-json-guard-source-only.patch'),'manifest':binding(OUT/'PREPARATION.json'),'newProductionFile':binding(file),'compiled':False,'testsExecuted':False}))