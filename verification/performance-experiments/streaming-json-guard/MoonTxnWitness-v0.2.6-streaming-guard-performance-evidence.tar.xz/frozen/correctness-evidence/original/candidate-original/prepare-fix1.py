from pathlib import Path
import json,hashlib,difflib,shutil
OUT=Path(r'D:\CodexScratch\MoonTxnWitness-streaming-json-guard-candidate-20261024-f');SRC=OUT/'candidate-source';BASE=Path(r'D:\CodexScratch\MoonTxnWitness-model-empty-interval-graph-reuse-20261024-a/baseline-source')
fix=OUT/'fix1';fix.mkdir()
def binding(p):
 b=p.read_bytes();return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
for name in ['json_guard.mbt','streaming_json_guard_wbtest.mbt']:shutil.copyfile(SRC/'src'/name,fix/('before-'+name))
for name,sub in [('core.mjs','bridge/bridge.js'),('capture-core.mjs','capture_bridge/capture_bridge.js')]:shutil.copyfile(SRC/'_build/js/release/build'/sub,fix/('first-compiled-'+name))
old=(BASE/'src/json_guard.mbt').read_text(encoding='utf8');current=(SRC/'src/json_guard.mbt').read_text(encoding='utf8')
marker='///|\n// The original JsonScan remains the exact scalar-indexed raw-index checksum'
assert current.count(marker)==1
stream=current[current.index(marker):]
assert old.count('fn guarded_json(')==1
preserved=old.replace('fn guarded_json(','fn guarded_base(')
assert len('guarded_json')==len('guarded_base')
wrapper='''\n///|\n// Valid large inputs avoid a materialized character array. When structural\n// scanning rejects an input, the original scanner reproduces the exact public\n// diagnostic, including its original source coordinate used by old evidence.\nfn guarded_json(text : String, limit? : Int = 1048576) -> Json raise {\n  if text.length() > limit {\n    return guarded_base(text, limit=limit)\n  }\n  let scan = StreamingJsonScan::new(text)\n  let structure_ok = try {\n    scan.value()\n    scan.white()\n    scan.current == None\n  } catch {\n    _ => false\n  }\n  if structure_ok {\n    @json.parse(text)\n  } else {\n    guarded_base(text, limit=limit)\n  }\n}\n'''
new=preserved+'\n'+stream+wrapper
(SRC/'src/json_guard.mbt').write_text(new,encoding='utf8',newline='\n')
p=SRC/'src/streaming_json_guard_wbtest.mbt';tests=p.read_text(encoding='utf8');bad='"{\\\"🙂\\\":0,\\\"\\\\ud83d\\\\ude00\\\":1}"';good=bad.replace('ude00','ude42');assert tests.count(bad)==1
tests=tests.replace(bad,good);p.write_text(tests,encoding='utf8',newline='\n')
patch=''.join(difflib.unified_diff(old.splitlines(keepends=True),new.splitlines(keepends=True),fromfile='a/src/json_guard.mbt',tofile='b/src/json_guard.mbt'))
(fix/'streaming-json-guard-fix1.patch').write_text(patch,encoding='utf8',newline='\n')
record={'format':'moontxnwitness-streaming-guard-fix1/v1','firstTests':{'path':str(OUT/'test-js-after-resource-change-20261024-g/PROCESS-FIRST.json'),**binding(OUT/'test-js-after-resource-change-20261024-g/PROCESS-FIRST.json')},'firstResults':{'total':756,'passed':754,'failed':2},'implementationCorrection':'Original guard body and all original JsonScan methods retain their original file coordinates under equal-length private name guarded_base. Streaming structural success returns official JSON parse without collecting chars. Structural/limit/trailing rejection executes original guard to retain exact released error bytes.','newFixtureCorrection':'Original newly authored 🙂 plus escaped D83D DE00 were different keys; corrected escape DE42 for the already specified equivalent-key rejection. Both distinct and equivalent cases will be retained in independent baseline differential.','oldExpectedResultsModified':False,'existing748Modified':False,'rootModified':False,'previousCompiledRuntimesRetained':{n:binding(fix/n) for n in ['first-compiled-core.mjs','first-compiled-capture-core.mjs']},'patch':binding(fix/'streaming-json-guard-fix1.patch'),'source':binding(SRC/'src/json_guard.mbt'),'testSource':binding(p),'newImplementationNotYetBuilt':True}
(fix/'DECISION.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf8',newline='\n')
print(json.dumps({'fix':str(fix),'patch':record['patch'],'decision':binding(fix/'DECISION.json'),'source':record['source'],'newTest':record['testSource']}))