// Formal worker only. Every raw complete report is retained after the timed SDK call.
import {readFileSync,writeFileSync} from 'node:fs';
import {resolve,dirname} from 'node:path';
import {pathToFileURL} from 'node:url';
import {performance} from 'node:perf_hooks';
import {gzipSync} from 'node:zlib';
import {sha,immutable,stats,safeFile,verifyBindings,validateProtocol,validateOutput,comparableBytes,validateCallSequence} from './common.mjs';
const [mode,planArg,planSha,role,id,batchText,outArg]=process.argv.slice(2);
if(mode!=='--execute-frozen-worker'||process.argv.length!==9||!['baseline','candidate'].includes(role)||!(/^[a-f0-9]{64}$/).test(planSha??''))throw Error('Frozen worker protocol arguments required');
const path=resolve(planArg),root=dirname(path),raw=readFileSync(path);if(sha(raw)!==planSha)throw Error('Worker plan SHA differs');
const p=validateProtocol(JSON.parse(raw),{frozen:true}),f=p.fixtures.find(x=>x.id===id),batch=Number(batchText),out=resolve(outArg),rt=p.runtimes[role];
if(!f||![1,2,3].includes(batch)||process.version!==p.node.version||process.env.NODE_OPTIONS||process.env.NODE_PATH||process.execArgv.length)throw Error('Worker input, batch or runtime differs');
verifyBindings(resolve(root,rt.directory),rt.files,{exact:true});
const input=readFileSync(safeFile(root,f.file));if(input.length!==f.bytes||sha(input)!==f.sha256)throw Error('Exact original input bytes differ');
const decoded=input.toString('utf8');if(!Buffer.from(decoded).equals(input))throw Error('Malformed UTF-8 input');
const source=f.inputEncoding==='original-utf8-capture-text'?decoded:JSON.stringify(JSON.parse(decoded).input),options=Object.freeze({...f.options}),calls=[];let archiveRawBytes=0;
function archive(report,label,durationMs){
 validateOutput(report,f,p,rt);const original=Buffer.from(JSON.stringify(report)+'\n'),comparable=comparableBytes(report,f,p,rt);archiveRawBytes+=original.length;
 if(original.length>p.retainedSingleOutputLimitBytes||archiveRawBytes>p.workerOutputArchiveLimitBytes)throw Error('Explicit complete-output archive budget exhausted');
 const compressed=gzipSync(original),name=label+'.json.gz';writeFileSync(resolve(out,name),compressed,{flag:'wx'});
 calls.push({label,durationMs,comparisonSha256:sha(comparable),output:{file:name,bytes:original.length,sha256:sha(original),gzipBytes:compressed.length,gzipSha256:sha(compressed)}});
}
try{
 const startedAtProcessMs=process.uptime()*1000,loadStart=performance.now(),sdk=await import(pathToFileURL(safeFile(root,rt.directory+'/sdk.mjs')).href),coldLoadMs=performance.now()-loadStart;
 if(typeof sdk[f.method]!=='function'||sdk.version()!==p.version)throw Error('Complete SDK method/version unavailable');
 const t=performance.now();let report=sdk[f.method](source,options);const firstCallMs=performance.now()-t,processElapsedAtFirstCallMs=process.uptime()*1000;archive(report,'cold',firstCallMs);report=null;
 for(let i=0;i<5;i++){const before=performance.now();report=sdk[f.method](source,options);const duration=performance.now()-before;archive(report,`warmup-${i+1}`,duration);report=null;}
 const samples=[];let usage;
 for(let i=0;i<30;i++){const before=performance.now();report=sdk[f.method](source,options);const duration=performance.now()-before;samples.push(duration);if(i===29)usage=process.resourceUsage();archive(report,`sample-${i+1}`,duration);report=null;}
 if(!Number.isSafeInteger(usage.maxRSS)||usage.maxRSS<=0)throw Error('Peak RSS unavailable');validateCallSequence(calls);if(new Set(calls.map(c=>c.comparisonSha256)).size!==1)throw Error('Complete output changed across calls in one worker');
 verifyBindings(resolve(root,rt.directory),rt.files,{exact:true});
 const result={format:'moontxnwitness-six-model-paired-worker/v1',passed:true,planSha256:planSha,role,id,batch,method:f.method,group:f.group,node:process.version,platform:process.platform,arch:process.arch,processId:process.pid,startedAtProcessMs,coldLoadMs,firstCallMs,processElapsedAtFirstCallMs,sampleCount:30,warmupCount:5,calls,samplesMs:samples,sampleStatsMs:stats(samples),peakRssKiB:usage.maxRSS,resourceUsageBeforeLastArchival:usage,rssIncludesPreviousPerCallArchivalAllocations:true,fullOriginalOutputsRetained:36,totalOriginalOutputBytes:archiveRawBytes,callerArchivalIncludedInTimedSdkCall:false};
 immutable(resolve(out,'receipt.json'),result);console.log(JSON.stringify({passed:true,role,id,batch,samples:30,completeOriginalOutputs:36,peakRssKiB:usage.maxRSS}));
}catch(error){immutable(resolve(out,'failed.json'),{passed:false,role,id,batch,planSha256:planSha,completedCallArchives:calls,error:{name:error.name,message:error.message},at:new Date().toISOString()});throw error;}
