import {createHash} from 'node:crypto';
import {readFileSync,lstatSync,readdirSync,writeFileSync} from 'node:fs';
import {resolve,relative,sep} from 'node:path';
export const sha=b=>createHash('sha256').update(b).digest('hex');
export const canonical=x=>JSON.stringify(x,null,2)+'\n';
export const immutable=(path,value)=>writeFileSync(path,Buffer.isBuffer(value)||typeof value==='string'?value:canonical(value),{flag:'wx'});
export function stats(samples){if(!Array.isArray(samples)||!samples.length||samples.some(x=>typeof x!=='number'||!Number.isFinite(x)||x<0))throw Error('Nonempty finite nonnegative samples required');const a=samples.slice().sort((x,y)=>x-y);return {count:a.length,median:a[Math.floor(a.length/2)],p95:a[Math.ceil(.95*a.length)-1],min:a[0],max:a.at(-1)};}
export function geometricMean(values){if(!values.length||values.some(v=>!Number.isFinite(v)||v<=0))throw Error('Positive finite ratios required');return Math.exp(values.reduce((sum,v)=>sum+Math.log(v),0)/values.length);}
export function controlGate(baselineP95,candidateP95){if(![baselineP95,candidateP95].every(v=>typeof v==='number'&&Number.isFinite(v)&&v>=0))throw Error('Invalid latency for control gate');const allowanceMs=Math.max(.10*baselineP95,2);return {baselineP95Ms:baselineP95,candidateP95Ms:candidateP95,allowanceMs,maximumCandidateP95Ms:baselineP95+allowanceMs,passed:candidateP95<=baselineP95+allowanceMs};}
export function safeFile(root,name){if(typeof name!=='string'||!name||name.includes('\\')||name.includes(':')||name.startsWith('/')||name.split('/').some(x=>!x||x==='.'||x==='..'))throw Error('Unsafe relative file');let p=resolve(root);if(lstatSync(p).isSymbolicLink())throw Error('Symlink root refused');for(const part of name.split('/')){p=resolve(p,part);if(lstatSync(p).isSymbolicLink())throw Error('Symlink refused');}const rel=relative(resolve(root),p);if(rel==='..'||rel.startsWith('..'+sep)||!lstatSync(p).isFile())throw Error('Expected contained regular file');return p;}
export function binding(path){const b=readFileSync(path);return {bytes:b.length,sha256:sha(b)};}
export function walk(root){const result={};if(lstatSync(root).isSymbolicLink())throw Error('Symlink runtime root refused');function visit(dir,prefix=''){for(const e of readdirSync(dir,{withFileTypes:true})){const name=prefix+e.name;if(e.isSymbolicLink())throw Error('Symlink runtime refused');if(e.isDirectory())visit(resolve(dir,e.name),name+'/');else if(e.isFile())result[name]=binding(resolve(dir,e.name));else throw Error('Nonregular runtime refused');}}visit(root);return result;}
export function verifyBindings(root,files,{exact=false}={}){for(const[name,b]of Object.entries(files)){const a=binding(safeFile(root,name));if(a.bytes!==b.bytes||a.sha256!==b.sha256)throw Error('Frozen bytes differ: '+name);}if(exact&&Object.keys(walk(root)).sort().join('|')!==Object.keys(files).sort().join('|'))throw Error('Runtime file closure differs');}
export function schedule(p){if(p.batches!==3||p.fixtures.length!==10||p.concurrentWorkers!==1)throw Error('Schedule protocol differs');const list=[];for(let batch=1;batch<=3;batch++)for(let k=0;k<10;k++){const index=(k+3*(batch-1))%10,f=p.fixtures[index],roles=(batch+index)%2===1?['baseline','candidate']:['candidate','baseline'];for(const role of roles)list.push({batch,id:f.id,role});}return list;}
export function validateProtocol(p,{frozen=false}={}){
 if(p.format!=='moontxnwitness-six-model-paired-performance/v1'||p.version!=='0.2.6'||p.warmups!==5||p.samples!==30||p.batches!==3||p.concurrentWorkers!==1||p.workerCount!==60||p.formalSampleCount!==1800||p.totalCompleteSdkCalls!==2160)throw Error('Frozen protocol differs');
 if(p.fixtures.length!==10||new Set(p.fixtures.map(f=>f.id)).size!==10||p.fixtures.filter(f=>f.group==='six-models').length!==6||p.fixtures.filter(f=>f.group==='common-controls').length!==4)throw Error('Fixture matrix differs');
 if(p.runtimeFileCountEach!==47||p.large128Input?.bytes!==78800||p.large128Input?.sha256!=='fb2764c1f35f939b7ad6d46af26dc0de3c62b2abb6abc456606df35a6b37634d'||JSON.stringify(p.large128Input.options)!=='{}')throw Error('Actual runtime closure or fixed128 input differs');
 if(p.controlIds.length!==9||new Set(p.controlIds).size!==9||p.fixtures.some(f=>f.id!=='register-128-chain'&&!p.controlIds.includes(f.id)))throw Error('All non-target controls required');
 if(p.models.length!==6||new Set(p.models).size!==6||p.fixtures.some(f=>!['classifyModelsV3','analyzeV3'].includes(f.method)))throw Error('SDK methods or models differ');
 if(p.preRegisteredTarget?.fixtureId!=='register-128-chain'||p.preRegisteredTarget.speedupAtLeast!==1.15||p.preRegisteredTarget.rssRatioAtMost!==.85||p.preRegisteredTarget.acceptanceOperator!=='or'||p.preRegisteredTarget.registeredBeforeCandidateTiming!==true)throw Error('Pre-registered narrow target differs');
 if(p.comparisonAllowedFields['six-models'].join('|')!=='/engine/coreSha256'||p.comparisonAllowedFields['common-controls'].length)throw Error('Comparison exceptions differ');
 if(p.baselineCoreSha256!=='132774cb868bbd08c95f86577871bc326c59bd2fb3db5565b27a46883f68e5e1'||p.candidateCoreSha256!=='26fff6382e9bf76926bd29de24d98ae7802f1578184773169faa9f9856b2ff09')throw Error('Actual core pins differ');
 if(frozen&&(p.phase!=='frozen-paired-runtime-not-measured'||!p.runtimes?.baseline||!p.runtimes?.candidate||p.correctnessGate?.passed!==true))throw Error('Frozen runtimes and completed correctness gate required');
 return p;
}
export function validateOutput(report,f,p,runtime){
 if(!report||typeof report!=='object')throw Error('Missing complete SDK report');
 if(f.group==='common-controls'){if(report.version!==p.version||report.status!==f.expected.status)throw Error('Control version/status differs');return;}
 if(report.format!=='moontxnwitness-isolation-model-report/v1'||report.coreReportReplay?.valid!==true||report.engine?.version!==p.version||report.engine.coreSha256!==runtime.files['core.mjs'].sha256||report.engine.hostSha256!==runtime.files['classification-models.mjs'].sha256)throw Error('Six-model actual engine/report binding differs');
 if(Object.keys(report.result?.models??{}).sort().join('|')!==p.models.slice().sort().join('|'))throw Error('Missing exact six-model set');
 const e=f.expected;if(e.status&&report.status!==e.status)throw Error('Overall expected status differs');for(const[id,status]of Object.entries(e.models??{}))if(report.result.models[id]?.status!==status)throw Error('Expected model status differs');if(e.allModels&&p.models.some(id=>report.result.models[id]?.status!==e.allModels))throw Error('All-model status differs');if(e.noModelRefuted&&p.models.some(id=>report.result.models[id]?.status==='refuted'))throw Error('Acyclic input spuriously refuted');
}
export function comparableBytes(report,f,p,runtime){
 validateOutput(report,f,p,runtime);
 if(f.group==='common-controls')return Buffer.from(JSON.stringify(report)+'\n');
 const copy=structuredClone(report);copy.engine.coreSha256=p.baselineCoreSha256;
 return Buffer.from(JSON.stringify(copy)+'\n');
}
export function validateCallSequence(calls){const expected=['cold',...Array.from({length:5},(_,i)=>`warmup-${i+1}`),...Array.from({length:30},(_,i)=>`sample-${i+1}`)];if(!Array.isArray(calls)||calls.length!==36||calls.some((c,i)=>c.label!==expected[i]||typeof c.output?.sha256!=='string'||typeof c.comparisonSha256!=='string'))throw Error('All 36 original call outputs required in sequence');return true;}
export function targetMetrics(baseline,candidate){if(!(baseline.samples?.median>0&&candidate.samples?.median>0&&baseline.rss?.median>0&&candidate.rss?.median>0))throw Error('Positive target statistics required');const speedup=baseline.samples.median/candidate.samples.median,rssRatio=candidate.rss.median/baseline.rss.median;return {fixtureId:'register-128-chain',speedup,rssRatio,speedupAtLeast:1.15,rssRatioAtMost:.85,speedupPassed:speedup>=1.15,rssPassed:rssRatio<=.85,passed:speedup>=1.15||rssRatio<=.85,scope:'Only fixed128-chain full six-model SDK; no whole-six-group or old-v020 target implication'};}
