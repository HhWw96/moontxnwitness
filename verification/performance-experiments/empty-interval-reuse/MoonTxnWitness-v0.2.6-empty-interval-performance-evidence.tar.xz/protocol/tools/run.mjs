// Formal controller requires exact frozen plan and an explicitly exclusive local measurement window.
import {readFileSync,mkdirSync,statfsSync,writeFileSync} from 'node:fs';
import {resolve,dirname} from 'node:path';
import {spawnSync} from 'node:child_process';
import {performance} from 'node:perf_hooks';
import {gunzipSync} from 'node:zlib';
import os from 'node:os';
import {sha,canonical,immutable,stats,geometricMean,controlGate,binding,verifyBindings,safeFile,schedule,validateProtocol,validateOutput,comparableBytes,validateCallSequence,targetMetrics} from './common.mjs';
const [mode,planArg,approvedSha,outArg]=process.argv.slice(2);
if(mode!=='--execute-root-approved-exclusive'||process.argv.length!==6||!(/^[a-f0-9]{64}$/).test(approvedSha??''))throw Error('Usage: run.mjs --execute-root-approved-exclusive PLAN EXACT_APPROVED_SHA NEW_RESULT_DIR');
if(process.env.NODE_OPTIONS||process.env.NODE_PATH||process.execArgv.length)throw Error('Node runtime injection refused');
const path=resolve(planArg),root=dirname(path),raw=readFileSync(path);if(sha(raw)!==approvedSha)throw Error('Approved exact plan SHA differs');
const p=validateProtocol(JSON.parse(raw),{frozen:true}),out=resolve(outArg);
if(process.version!==p.node.version||binding(process.execPath).sha256!==p.node.sha256)throw Error('Pinned Node binary/version differs');
function recheck(){for(const role of ['baseline','candidate'])verifyBindings(resolve(root,p.runtimes[role].directory),p.runtimes[role].files,{exact:true});verifyBindings(resolve(root,'tools'),p.toolFiles,{exact:true});}
recheck();verifyBindings(root,Object.fromEntries(p.fixtures.map(f=>[f.file,{bytes:f.bytes,sha256:f.sha256}])));verifyBindings(root,p.preparationEvidence);
for(const [name,b]of Object.entries(p.correctnessGate.receipts))verifyBindings(root,{[name]:b});
if(sha(readFileSync(safeFile(root,p.correctnessGate.gateFile)))!==p.correctnessGate.gateSha256||sha(readFileSync(safeFile(root,p.correctnessGate.runtimeBindingsFile)))!==p.correctnessGate.runtimeBindingsSha256)throw Error('Actual correctness evidence differs');
const fs=statfsSync(dirname(out));if(Number(fs.bavail)*Number(fs.bsize)<p.minimumFreeBytes)throw Error('Insufficient formal free-space reserve');
mkdirSync(out);const jobs=schedule(p),receipt={format:'moontxnwitness-six-model-paired-run/v1',phase:'formal-private-candidate-performance',planSha256:approvedSha,startedAt:new Date().toISOString(),node:{version:process.version,binary:binding(process.execPath)},machine:{platform:os.platform(),release:os.release(),arch:os.arch(),cpu:os.cpus()[0]?.model,logicalCpus:os.cpus().length,totalMemory:os.totalmem()},exclusiveMachineAssertedByInvoker:true,backgroundOsActivityControlled:false,concurrentWorkers:1,plannedWorkers:60,plannedFormalSamples:1800,plannedOriginalCompleteOutputs:2160,originalOutputsRetained:true,comparisonAllowedFields:p.comparisonAllowedFields,rssIncludesPreviousPerCallArchivalAllocations:true,preRegisteredTarget:p.preRegisteredTarget,workers:[],completed:false,outputsEquivalent:false,controlsPassed:false,narrowTargetPassed:false,performanceTargetsPassed:false,candidateAdopted:false,adoptionDecision:'not made by measurement harness',oldV020FailureUnchanged:true};
immutable(resolve(out,'started.json'),receipt);
function verifyWorker(row,f){
 const dir=resolve(out,row.name),r=JSON.parse(readFileSync(resolve(dir,'receipt.json')));
 if(r.format!=='moontxnwitness-six-model-paired-worker/v1'||r.passed!==true||r.planSha256!==approvedSha||r.role!==row.role||r.id!==row.id||r.batch!==row.batch||r.sampleCount!==30||r.warmupCount!==5||r.samplesMs.length!==30||r.fullOriginalOutputsRetained!==36||r.node!==p.node.version||r.rssIncludesPreviousPerCallArchivalAllocations!==true)throw Error('Worker receipt identity/protocol differs');
 validateCallSequence(r.calls);const rt=p.runtimes[row.role];
 for(const call of r.calls){const packed=readFileSync(safeFile(dir,call.output.file));if(packed.length!==call.output.gzipBytes||sha(packed)!==call.output.gzipSha256)throw Error('Original gzip output bytes differ');const raw=gunzipSync(packed,{maxOutputLength:p.retainedSingleOutputLimitBytes});if(raw.length!==call.output.bytes||sha(raw)!==call.output.sha256)throw Error('Original full SDK output bytes differ');const report=JSON.parse(raw.toString('utf8'));if(!Buffer.from(JSON.stringify(report)+'\n').equals(raw))throw Error('Original output serialization is not exact');validateOutput(report,f,p,rt);if(sha(comparableBytes(report,f,p,rt))!==call.comparisonSha256)throw Error('Only allowed exact core-header comparison differs');}
 if(new Set(r.calls.map(c=>c.comparisonSha256)).size!==1)throw Error('All36 complete outputs must remain deterministic');
 if(JSON.stringify(stats(r.samplesMs))!==JSON.stringify(r.sampleStatsMs)||!Number.isSafeInteger(r.peakRssKiB)||r.peakRssKiB<=0)throw Error('Worker sample statistics or memory differs');
 return r;
}
function comparePair(a,b,f){
 if(!a?.passed||!b?.passed)return;
 for(let i=0;i<36;i++){const ac=a.receipt.calls[i],bc=b.receipt.calls[i],araw=gunzipSync(readFileSync(resolve(out,a.name,ac.output.file)),{maxOutputLength:p.retainedSingleOutputLimitBytes}),braw=gunzipSync(readFileSync(resolve(out,b.name,bc.output.file)),{maxOutputLength:p.retainedSingleOutputLimitBytes});if(f.group==='common-controls'){if(!araw.equals(braw))throw Error('Common-control original full output differs');}else{const ap=JSON.parse(araw.toString('utf8')),bp=JSON.parse(braw.toString('utf8'));validateOutput(ap,f,p,p.runtimes.baseline);validateOutput(bp,f,p,p.runtimes.candidate);const expected=structuredClone(ap);expected.engine.coreSha256=p.candidateCoreSha256;if(!Buffer.from(JSON.stringify(expected)+'\n').equals(braw))throw Error('Full SDK output differs beyond the one exact engine/core source hash');}}
}
try{
 for(const job of jobs){
  const f=p.fixtures.find(x=>x.id===job.id),name=`batch-${job.batch}-${job.id}-${job.role}`,workerOut=resolve(out,name);mkdirSync(workerOut);const row={...job,name,passed:false};
  try{recheck();const before=performance.now(),child=spawnSync(process.execPath,[safeFile(root,'tools/worker.mjs'),'--execute-frozen-worker',path,approvedSha,job.role,job.id,String(job.batch),workerOut],{encoding:'utf8',timeout:p.workerTimeoutMs,maxBuffer:p.workerOutputLimitBytes,windowsHide:true,env:process.env});row.workerWallMs=performance.now()-before;immutable(resolve(workerOut,'stdout.log'),child.stdout??'');immutable(resolve(workerOut,'stderr.log'),child.stderr??'');row.exitCode=child.status;row.signal=child.signal;row.error=child.error?{name:child.error.name,message:child.error.message,code:child.error.code}:null;recheck();if(child.error||child.status!==0||child.signal)throw Error('Worker did not complete; no automatic retry');row.receipt=verifyWorker(row,f);row.passed=true;}
  catch(error){row.failure=error.message;}
  receipt.workers.push(row);writeFileSync(resolve(out,'progress.json'),canonical(receipt));console.log(JSON.stringify({completedWorkers:receipt.workers.length,totalWorkers:60,name,passed:row.passed}));
  if(!row.passed)throw Error('First failed worker retained; campaign stopped without retries');
  const same=receipt.workers.filter(r=>r.batch===job.batch&&r.id===job.id);if(same.length===2)comparePair(same.find(r=>r.role==='baseline'),same.find(r=>r.role==='candidate'),f);
 }
 receipt.groups={};let allControlPass=true;
 for(const f of p.fixtures){const by={};for(const role of ['baseline','candidate']){const rows=receipt.workers.filter(r=>r.id===f.id&&r.role===role).map(r=>r.receipt);if(rows.length!==3)throw Error('Incomplete independent batch matrix');by[role]={samples:stats(rows.flatMap(r=>r.samplesMs)),rss:stats(rows.map(r=>r.peakRssKiB)),coldLoad:stats(rows.map(r=>r.coldLoadMs)),firstCall:stats(rows.map(r=>r.firstCallMs)),processElapsedAtFirstCall:stats(rows.map(r=>r.processElapsedAtFirstCallMs)),outputBytes:stats(rows.flatMap(r=>r.calls.map(c=>c.output.bytes))),perBatch:rows.map(r=>({batch:r.batch,samples:r.sampleStatsMs,peakRssKiB:r.peakRssKiB,coldLoadMs:r.coldLoadMs,firstCallMs:r.firstCallMs,processElapsedAtFirstCallMs:r.processElapsedAtFirstCallMs,rawOutputSha256:r.calls.at(-1).output.sha256,comparisonSha256:r.calls.at(-1).comparisonSha256}))};}
  const values=receipt.workers.filter(r=>r.id===f.id).flatMap(r=>r.receipt.calls.map(c=>c.comparisonSha256));if(new Set(values).size!==1)throw Error('Full output equality across every call/batch failed');
  const perBatch=[1,2,3].map(batch=>{const a=by.baseline.perBatch.find(r=>r.batch===batch),b=by.candidate.perBatch.find(r=>r.batch===batch);return {batch,speedup:a.samples.median/b.samples.median,rssRatio:b.peakRssKiB/a.peakRssKiB,controlGate:controlGate(a.samples.p95,b.samples.p95)};});
  const pooledControl=controlGate(by.baseline.samples.p95,by.candidate.samples.p95),isControl=p.controlIds.includes(f.id),controlPassed=!isControl||(pooledControl.passed&&perBatch.every(v=>v.controlGate.passed));if(!controlPassed)allControlPass=false;
  receipt.groups[f.id]={group:f.group,baseline:by.baseline,candidate:by.candidate,speedup:by.baseline.samples.median/by.candidate.samples.median,rssRatio:by.candidate.rss.median/by.baseline.rss.median,perBatch,allOriginalFullOutputsEquivalent:true,controlRequired:isControl,pooledControl,controlPassed};
 }
 receipt.completed=true;receipt.outputsEquivalent=true;receipt.controlsPassed=allControlPass;const target=receipt.groups['register-128-chain'];receipt.narrowTarget=targetMetrics(target.baseline,target.candidate);receipt.narrowTargetPassed=receipt.narrowTarget.passed;
 const modelGroups=p.fixtures.filter(f=>f.group==='six-models').map(f=>receipt.groups[f.id]);receipt.sixModelAggregate={geometricMeanSpeedup:geometricMean(modelGroups.map(g=>g.speedup)),geometricMeanRssRatio:geometricMean(modelGroups.map(g=>g.rssRatio)),caseCount:6,noWholeGroupTargetClaim:true};receipt.performanceTargetsPassed=receipt.outputsEquivalent&&receipt.controlsPassed&&receipt.narrowTargetPassed;
}catch(error){receipt.failure={name:error.name,message:error.message};}
receipt.finishedAt=new Date().toISOString();immutable(resolve(out,'receipt.json'),receipt);console.log(JSON.stringify({completed:receipt.completed,workers:receipt.workers.length,outputsEquivalent:receipt.outputsEquivalent,controlsPassed:receipt.controlsPassed,narrowTarget:receipt.narrowTarget??null,sixModelAggregate:receipt.sixModelAggregate??null,performanceTargetsPassed:receipt.performanceTargetsPassed,candidateAdopted:false,failure:receipt.failure??null}));process.exitCode=!receipt.completed?1:receipt.performanceTargetsPassed?0:2;
