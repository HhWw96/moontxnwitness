// Preparation only: verify completed correctness evidence and copy actual runtimes; never import SDK/core.
import {readFileSync,mkdirSync,copyFileSync,existsSync} from 'node:fs';
import {resolve,dirname,isAbsolute} from 'node:path';
import {fileURLToPath} from 'node:url';
import {sha,canonical,immutable,walk,verifyBindings,safeFile,validateProtocol,binding} from './common.mjs';
const here=resolve(dirname(fileURLToPath(import.meta.url)),'..');
const [bindingsArg,bindingsSha,gateArg,gateSha,outArg]=process.argv.slice(2);
if(process.argv.length!==7||![bindingsSha,gateSha].every(s=>/^[a-f0-9]{64}$/.test(s??'')))throw Error('Usage: freeze.mjs RUNTIME_BINDINGS EXACT_SHA COMPLETED_CORRECTNESS_GATE EXACT_SHA NEW_BUNDLE');
if(process.env.NODE_OPTIONS||process.env.NODE_PATH||process.execArgv.length)throw Error('Runtime injection flags refused');
const p=validateProtocol(JSON.parse(readFileSync(resolve(here,'protocol.json'))));
const braw=readFileSync(resolve(bindingsArg)),graw=readFileSync(resolve(gateArg));if(sha(braw)!==bindingsSha||sha(graw)!==gateSha)throw Error('External runtime/correctness SHA differs');
const b=JSON.parse(braw),g=JSON.parse(graw),out=resolve(outArg);
if(existsSync(out))throw Error('New frozen bundle only');
if(b.format!=='empty-interval-correctness-runtime-bindings/v1')throw Error('Actual correctness runtime bindings required');
if(g.format!==p.correctnessFreezeGate.format||g.passed!==true||g.baselineCoreSha256!==p.baselineCoreSha256||g.candidateCoreSha256!==p.candidateCoreSha256||p.correctnessFreezeGate.requiredAssertions.some(a=>g[a]!==true))throw Error('All actual small/legacy/128 core and SDK correctness assertions must pass before freeze');
if(!Array.isArray(g.sourceReceipts)||p.correctnessFreezeGate.requiredAssertions.some(a=>!g.sourceReceipts.some(r=>r.assertion===a)))throw Error('Each correctness assertion requires an actual receipt binding');
if(g.priorFirstHarnessFailureRetained!==true||!Array.isArray(g.evidenceFiles)||!g.evidenceFiles.length)throw Error('First failure, repair and original correctness outputs must remain bound');
for(const e of g.evidenceFiles){if(!isAbsolute(e.path)||!(/^[A-Za-z0-9][A-Za-z0-9._/-]*$/).test(e.name)||e.name.split('/').some(v=>!v||v==='.'||v==='..'))throw Error('Unsafe original evidence path');const raw=readFileSync(e.path);if(raw.length!==e.bytes||sha(raw)!==e.sha256)throw Error('Original correctness/failure evidence differs');}
for(const r of g.sourceReceipts){if(!isAbsolute(r.path)||!p.correctnessFreezeGate.requiredAssertions.includes(r.assertion))throw Error('Invalid correctness receipt path/assertion');const raw=readFileSync(r.path);if(raw.length!==r.bytes||sha(raw)!==r.sha256)throw Error('Actual correctness source receipt bytes differ');const body=JSON.parse(raw);if(body.status!=='passed'&&body.passed!==true)throw Error('A correctness source receipt is not passed');}
const runtimes={};
for(const role of ['baseline','candidate']){
 const c=b[role];if(!c||c.build?.exitCode!==0||!Array.isArray(c.files)||c.files.length!==p.runtimeFileCountEach||c.buildManifest?.version!==p.version)throw Error('Actual completed build required');
 const files={};for(const f of c.files){if(Object.hasOwn(files,f.path))throw Error('Duplicate runtime binding');files[f.path]={bytes:f.bytes,sha256:f.sha256};}
 verifyBindings(c.directory,files,{exact:true});
 const manifest=JSON.parse(readFileSync(safeFile(c.directory,'build-manifest.json')));if(JSON.stringify(manifest)!==JSON.stringify(c.buildManifest))throw Error('Actual build manifest differs from completed build binding');
 const expected=role==='baseline'?p.baselineCoreSha256:p.candidateCoreSha256;
 if(files['core.mjs']?.sha256!==expected||manifest.coreSha256!==expected||files['capture-core.mjs']?.sha256!==manifest.captureCoreSha256||!files['sdk.mjs']||!files['classification-models.mjs'])throw Error('Complete runtime/core binding differs');
 if(Object.values(files).reduce((n,v)=>n+v.bytes,0)>p.maximumCopiedRuntimeBytesEach)throw Error('Runtime byte budget exceeded');
 runtimes[role]={directory:role+'-runtime',sourceDirectory:c.directory,files,buildManifest:manifest};
}
if(g.large128Input?.sha256!==p.large128Input.sha256||g.large128Input.bytes!==p.large128Input.bytes||JSON.stringify(g.large128Input.options)!=='{}')throw Error('Actual 128 correctness input/options do not match formal fixture');
if(!Array.isArray(g.large128OriginalOutputs)||g.large128OriginalOutputs.length!==4)throw Error('All four original 128 core/SDK outputs must remain bound');
for(const r of g.large128OriginalOutputs){const raw=readFileSync(r.path);if(raw.length!==r.bytes||sha(raw)!==r.sha256||!g.evidenceFiles.some(e=>e.path===r.path&&e.sha256===r.sha256))throw Error('Original 128 output evidence differs');}
const a=runtimes.baseline,z=runtimes.candidate;
if(JSON.stringify(a.buildManifest.toolchain)!==JSON.stringify(z.buildManifest.toolchain)||Object.keys(a.files).sort().join('|')!==Object.keys(z.files).sort().join('|'))throw Error('Toolchain or closure set differs');
let unchanged=0;
for(const name of Object.keys(a.files)){
 const approved=p.approvedBuildDifferences[name];
 if(approved){if(a.files[name].sha256!==approved.baseline||z.files[name].sha256!==approved.candidate)throw Error('Explicit actual build difference SHA pair changed: '+name);}
 else{if(a.files[name].sha256!==z.files[name].sha256||a.files[name].bytes!==z.files[name].bytes)throw Error('Unexpected runtime difference beyond three exact approved files: '+name);unchanged++;}
}
if(unchanged!==44||a.buildManifest.captureCoreSha256!==p.approvedBuildDifferences['capture-core.mjs'].baseline||z.buildManifest.captureCoreSha256!==p.approvedBuildDifferences['capture-core.mjs'].candidate)throw Error('44 unchanged files or actual capture manifest pins differ');
const tools=walk(resolve(here,'tools'));mkdirSync(out);
for(const role of ['baseline','candidate']){mkdirSync(resolve(out,runtimes[role].directory));for(const name of Object.keys(runtimes[role].files)){const target=resolve(out,runtimes[role].directory,name);mkdirSync(dirname(target),{recursive:true});copyFileSync(safeFile(runtimes[role].sourceDirectory,name),target);}verifyBindings(resolve(out,runtimes[role].directory),runtimes[role].files,{exact:true});}
mkdirSync(resolve(out,'fixtures'));for(const f of p.fixtures){const source=safeFile(here,f.file),raw=readFileSync(source);if(raw.length!==f.bytes||sha(raw)!==f.sha256)throw Error('Original fixed input differs');copyFileSync(source,resolve(out,f.file));}
mkdirSync(resolve(out,'tools'));for(const name of Object.keys(tools))copyFileSync(safeFile(resolve(here,'tools'),name),resolve(out,'tools',name));
mkdirSync(resolve(out,'correctness-evidence'));immutable(resolve(out,'correctness-evidence/runtime-bindings.json'),braw);immutable(resolve(out,'correctness-evidence/gate.json'),graw);
const evidence={};for(let i=0;i<g.sourceReceipts.length;i++){const r=g.sourceReceipts[i],name=`correctness-evidence/receipt-${String(i+1).padStart(2,'0')}.json`;immutable(resolve(out,name),readFileSync(r.path));evidence[name]={bytes:r.bytes,sha256:r.sha256,assertion:r.assertion};}
for(const e of g.evidenceFiles){const name='correctness-evidence/original/'+e.name,target=resolve(out,name);mkdirSync(dirname(target),{recursive:true});immutable(target,readFileSync(e.path));evidence[name]={bytes:e.bytes,sha256:e.sha256};}
const preparationEvidence={};
for(const name of ['protocol.json','INPUTS.json','README.md','SCHEDULE-FIRST-FAILURE.json','schedule-control-first-failure.stdout.log','schedule-control-first-failure.stderr.log','INPUT-BINDING-FIRST-FAILURE.json','FREEZE-FIRST.json','freeze-first.stdout.log','freeze-first.stderr.log','CAPTURE-CORE-DIFFERENCE.json','CAPTURE-DIAGNOSTIC-FIRST-FAILURE.json','inspect-capture-byte-difference.py','protocol-before-explicit-capture-build-difference.json','freeze-before-explicit-capture-difference.mjs']){const source=safeFile(here,name);immutable(resolve(out,name),readFileSync(source));preparationEvidence[name]=binding(source);}
for(const [name,bound]of Object.entries(walk(resolve(here,'first-98-pure-control-snapshot')))){const target='first-98-pure-control-snapshot/'+name;mkdirSync(dirname(resolve(out,target)),{recursive:true});immutable(resolve(out,target),readFileSync(safeFile(resolve(here,'first-98-pure-control-snapshot'),name)));preparationEvidence[target]=bound;}
const plan={...p,preparationEvidence,phase:'frozen-paired-runtime-not-measured',runtimes,toolFiles:tools,correctnessGate:{passed:true,format:g.format,gateFile:'correctness-evidence/gate.json',gateSha256:gateSha,runtimeBindingsFile:'correctness-evidence/runtime-bindings.json',runtimeBindingsSha256:bindingsSha,receipts:evidence},node:{...p.node,binary:binding(process.execPath)},frozenAt:new Date().toISOString()};validateProtocol(plan,{frozen:true});
if(process.version!==p.node.version||plan.node.binary.sha256!==p.node.sha256)throw Error('Same pinned Node binary/version required');
immutable(resolve(out,'plan.json'),plan);verifyBindings(resolve(out,'tools'),tools,{exact:true});
console.log(JSON.stringify({prepared:true,sdkImported:false,formalExecuted:false,planSha256:sha(readFileSync(resolve(out,'plan.json'))),runtimeFilesEach:Object.keys(a.files).length,workers:60,formalSamples:1800,totalCompleteCalls:2160}));
