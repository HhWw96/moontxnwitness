from threading import Event, Timer

import pytest

import dislock.core as core
from dislock.core import (
    LEASE_LOST_EXIT_CODE,
    LeaseLock,
    LeaseLossPolicy,
    LeaseRenewer,
    LockContext,
    ScheduleLock,
    acquire_locks,
    build_locks,
    execute_command,
    normalize_lock_strategies,
    parse_table_name,
    resolve_jitter_delay,
    resolve_lease_lost_event,
    resolve_retry_delay,
)
from dislock.exceptions import LeaseLostError


@pytest.mark.parametrize(
    ("raw", "expected"),
    [
        ("", ["key_value"]),
        ("locks.dislock", ["locks", "dislock"]),
    ],
)
def test_parse_table_name(raw, expected):
    assert parse_table_name(raw) == expected


def test_normalize_lock_strategies_puts_schedule_before_lease():
    assert normalize_lock_strategies(["lease", "schedule"]) == ("schedule", "lease")


@pytest.mark.parametrize(
    ("max_seconds", "sample", "expected"),
    [
        (0.0, 0.5, 0.0),
        (-1.0, 0.5, 0.0),
        (30.0, 0.0, 0.0),
        (30.0, 0.5, 15.0),
        (30.0, 0.999, 29.97),
    ],
)
def test_resolve_jitter_delay__maps_sample_into_window(max_seconds, sample, expected):
    assert resolve_jitter_delay(max_seconds, sample) == pytest.approx(expected)


def test_acquire_locks__jitters_before_entering_locks(monkeypatch):
    order = []

    monkeypatch.setattr(core, "apply_startup_jitter", lambda max_seconds: order.append(("jitter", max_seconds)))
    monkeypatch.setattr(core, "build_locks", lambda context, strategies: [])

    context = LockContext(
        url="postgresql://example",
        table_parts=["key_value"],
        lock_key="demo",
        owner="host:1",
        jitter_max_seconds=12.0,
    )

    with acquire_locks(context, ["schedule"]):
        order.append(("body", None))

    assert order == [("jitter", 12.0), ("body", None)]


def test_apply_startup_jitter__sleeps_resolved_delay(monkeypatch):
    slept = []

    monkeypatch.setattr(core.random, "random", lambda: 0.5)
    monkeypatch.setattr(core, "sleep", slept.append)

    assert core.apply_startup_jitter(10.0) == 5.0
    assert slept == [5.0]


def test_apply_startup_jitter__zero_max_does_not_sleep(monkeypatch):
    slept = []

    monkeypatch.setattr(core.random, "random", lambda: 0.5)
    monkeypatch.setattr(core, "sleep", slept.append)

    assert core.apply_startup_jitter(0.0) == 0.0
    assert slept == []


def test_build_locks_puts_schedule_lock_before_lease_lock():
    context = LockContext(
        url="postgresql://example",
        table_parts=["key_value"],
        lock_key="demo",
        owner="host:1",
        run_ttl_seconds=60.0,
        lease_interval_seconds=10.0,
    )

    locks = build_locks(context, ["lease", "schedule"])

    assert [type(lock) for lock in locks] == [ScheduleLock, LeaseLock]


def test_lease_renewer_reuses_single_connection(monkeypatch):
    class FakeConnection:
        def __init__(self, autocommit):
            self.autocommit = autocommit
            self.commit_calls = 0
            self.rollback_calls = 0
            self.closed = False

        def commit(self):
            self.commit_calls += 1

        def rollback(self):
            self.rollback_calls += 1

        def close(self):
            self.closed = True

    class FakeStopEvent:
        def __init__(self, waits):
            self._waits = iter(waits)

        def is_set(self) -> bool:
            return False

        def wait(self, _timeout):
            return next(self._waits)

    connections = []
    renewed_connections = []

    def fake_connect(dsn, autocommit):
        assert dsn == "postgresql://example"
        conn = FakeConnection(autocommit)
        connections.append(conn)
        return conn

    def fake_renew_lease(conn, table_parts, key, ttl_seconds, owner_value):
        renewed_connections.append(conn)
        assert table_parts == ["key_value"]
        assert key == "lease-key"
        assert ttl_seconds == 30.0
        assert owner_value == "owner-1"
        return True

    monkeypatch.setattr("dislock.core.psycopg", type("FakePsycopg", (), {"connect": staticmethod(fake_connect)}))
    monkeypatch.setattr("dislock.core.renew_lease", fake_renew_lease)

    renewer = LeaseRenewer(
        dsn="postgresql://example",
        table_parts=["key_value"],
        run_key="lease-key",
        ttl_seconds=30.0,
        owner_value="owner-1",
        interval_seconds=1.0,
        stop_event=FakeStopEvent([False, False, True]),
        lost_event=Event(),
    )

    renewer.run()

    assert renewer.ok is True
    assert len(connections) == 1
    assert renewed_connections == [connections[0], connections[0]]
    assert connections[0].autocommit is False
    assert connections[0].commit_calls == 2
    assert connections[0].rollback_calls == 1
    assert connections[0].closed is True


def test_lease_renewer_marks_not_ok_when_monotonic_deadline_is_missed(monkeypatch):
    class FakeConnection:
        def __init__(self, autocommit):
            self.autocommit = autocommit
            self.commit_calls = 0
            self.rollback_calls = 0
            self.closed = False

        def commit(self):
            self.commit_calls += 1

        def rollback(self):
            self.rollback_calls += 1

        def close(self):
            self.closed = True

    class FakeStopEvent:
        def is_set(self) -> bool:
            return False

        def wait(self, _timeout):
            return False

    def fake_connect(_dsn, autocommit):
        return FakeConnection(autocommit)

    def fake_renew_lease(**_kwargs):
        return True

    clock_values = iter([100.0, 100.2, 101.4])
    lost_event = Event()

    monkeypatch.setattr("dislock.core.psycopg", type("FakePsycopg", (), {"connect": staticmethod(fake_connect)}))
    monkeypatch.setattr("dislock.core.renew_lease", fake_renew_lease)

    renewer = LeaseRenewer(
        dsn="postgresql://example",
        table_parts=["key_value"],
        run_key="lease-key",
        ttl_seconds=1.0,
        owner_value="owner-1",
        interval_seconds=0.2,
        stop_event=FakeStopEvent(),
        lost_event=lost_event,
    )
    renewer._clock = lambda: next(clock_values)

    renewer.run()

    assert renewer.ok is False
    assert lost_event.is_set() is True


@pytest.mark.parametrize(
    ("attempt", "remaining", "expected"),
    [
        (0, 60.0, 0.1),
        (1, 60.0, 0.2),
        (4, 60.0, 1.6),
        (10, 60.0, 2.0),
        (3, 0.05, 0.05),
        (0, 0.0, None),
        (0, -1.0, None),
    ],
)
def test_resolve_retry_delay(attempt, remaining, expected):
    assert resolve_retry_delay(attempt, remaining) == expected


class _FakeConnection:
    def __init__(self, autocommit):
        self.autocommit = autocommit
        self.commit_calls = 0
        self.rollback_calls = 0
        self.closed = False

    def commit(self):
        self.commit_calls += 1

    def rollback(self):
        self.rollback_calls += 1

    def close(self):
        self.closed = True


class _FakeStopEvent:
    def __init__(self, waits):
        self._waits = iter(waits)
        self.delays = []

    def is_set(self) -> bool:
        return False

    def wait(self, timeout):
        self.delays.append(timeout)
        return next(self._waits)


def _make_renewer(monkeypatch, *, renew, stop_event, ttl_seconds=30.0, connections=None):
    def fake_connect(_dsn, autocommit):
        conn = _FakeConnection(autocommit)
        if connections is not None:
            connections.append(conn)
        return conn

    monkeypatch.setattr(
        "dislock.core.psycopg",
        type("FakePsycopg", (), {"connect": staticmethod(fake_connect)}),
    )
    monkeypatch.setattr("dislock.core.renew_lease", renew)

    return LeaseRenewer(
        dsn="postgresql://example",
        table_parts=["key_value"],
        run_key="lease-key",
        ttl_seconds=ttl_seconds,
        owner_value="owner-1",
        interval_seconds=1.0,
        stop_event=stop_event,
        lost_event=Event(),
    )


def test_lease_renewer__transient_error_then_success__stays_ok(monkeypatch):
    attempts = []

    def flaky_renew(**_kwargs):
        attempts.append(1)
        if len(attempts) == 1:
            raise OSError("connection reset by peer")
        return True

    connections = []
    stop_event = _FakeStopEvent([False, False, True])
    renewer = _make_renewer(
        monkeypatch, renew=flaky_renew, stop_event=stop_event, connections=connections
    )

    renewer.run()

    assert renewer.ok is True
    assert renewer.lost_event.is_set() is False
    assert len(attempts) == 2
    # Initial dial plus a redial after the failed statement poisoned the connection.
    assert len(connections) == 2
    assert connections[0].closed is True
    assert stop_event.delays[1] == core.LEASE_RETRY_BASE_DELAY_SECONDS


def test_lease_renewer__ownership_rejected__does_not_retry(monkeypatch):
    attempts = []

    def rejecting_renew(**_kwargs):
        attempts.append(1)
        return False

    stop_event = _FakeStopEvent([False, True])
    renewer = _make_renewer(monkeypatch, renew=rejecting_renew, stop_event=stop_event)

    renewer.run()

    assert renewer.ok is False
    assert renewer.lost_event.is_set() is True
    assert len(attempts) == 1


def test_lease_renewer__errors_past_deadline__gives_up(monkeypatch):
    attempts = []

    def failing_renew(**_kwargs):
        attempts.append(1)
        raise OSError("connection reset by peer")

    stop_event = _FakeStopEvent([False] * 200)
    renewer = _make_renewer(
        monkeypatch, renew=failing_renew, stop_event=stop_event, ttl_seconds=5.0
    )

    ticks = iter(range(1000))
    renewer._clock = lambda: float(next(ticks)) * 0.5

    renewer.run()

    assert renewer.ok is False
    assert renewer.lost_event.is_set() is True
    assert len(attempts) > 1


def test_resolve_lease_lost_event__continue_policy__returns_none():
    context = LockContext(
        url="postgresql://example",
        table_parts=["key_value"],
        lock_key="demo",
        owner="host:1",
        run_ttl_seconds=60.0,
        lease_interval_seconds=10.0,
    )
    locks = build_locks(context, ["schedule", "lease"])

    assert resolve_lease_lost_event(locks, LeaseLossPolicy.CONTINUE) is None


def test_resolve_lease_lost_event__terminate_policy__returns_lease_lock_event():
    context = LockContext(
        url="postgresql://example",
        table_parts=["key_value"],
        lock_key="demo",
        owner="host:1",
        run_ttl_seconds=60.0,
        lease_interval_seconds=10.0,
    )
    locks = build_locks(context, ["schedule", "lease"])

    assert resolve_lease_lost_event(locks, LeaseLossPolicy.TERMINATE) is locks[1].lease_lost


def test_resolve_lease_lost_event__no_lease_lock__returns_none():
    context = LockContext(
        url="postgresql://example",
        table_parts=["key_value"],
        lock_key="demo",
        owner="host:1",
    )
    locks = build_locks(context, ["schedule"])

    assert resolve_lease_lost_event(locks, LeaseLossPolicy.TERMINATE) is None


def test_execute_command__abort_set_while_running__terminates_and_returns_lease_lost_code():
    lease_lost = Event()
    Timer(0.2, lease_lost.set).start()

    assert execute_command(["sleep", "30"], lease_lost) == LEASE_LOST_EXIT_CODE


def test_execute_command__command_exits_first__propagates_its_return_code():
    assert execute_command(["sh", "-c", "exit 3"], Event()) == 3


def test_execute_command__without_abort__propagates_return_code():
    assert execute_command(["sh", "-c", "exit 0"]) == 0


class FakeRenewer:
    def __init__(self, ok):
        self.ok = ok

    def join(self, timeout):
        return None


def _lease_lock_with_lost_lease(monkeypatch, policy):
    class FakeConnection:
        def commit(self):
            return None

        def rollback(self):
            return None

        def close(self):
            return None

    monkeypatch.setattr(
        core,
        "psycopg",
        type("FakePsycopg", (), {"connect": staticmethod(lambda *_a, **_k: FakeConnection())}),
    )

    context = LockContext(
        url="postgresql://example",
        table_parts=["key_value"],
        lock_key="demo",
        owner="host:1",
        run_ttl_seconds=60.0,
        lease_interval_seconds=10.0,
        lease_loss_policy=policy,
    )
    lock = LeaseLock(context)
    lock.lease_renewer = FakeRenewer(ok=False)
    lock.lease_lost.set()
    return lock


def test_lease_lock_exit__lease_lost_and_block_succeeded__raises(monkeypatch):
    lock = _lease_lock_with_lost_lease(monkeypatch, LeaseLossPolicy.TERMINATE)

    with pytest.raises(LeaseLostError):
        lock.__exit__(None, None, None)


def test_lease_lock_exit__continue_policy__does_not_raise(monkeypatch):
    lock = _lease_lock_with_lost_lease(monkeypatch, LeaseLossPolicy.CONTINUE)

    assert lock.__exit__(None, None, None) is False


def test_lease_lock_exit__block_already_failing__does_not_mask_exception(monkeypatch):
    lock = _lease_lock_with_lost_lease(monkeypatch, LeaseLossPolicy.TERMINATE)

    assert lock.__exit__(ValueError, ValueError("boom"), None) is False


def test_lease_lock_exit__lease_held__does_not_raise(monkeypatch):
    lock = _lease_lock_with_lost_lease(monkeypatch, LeaseLossPolicy.TERMINATE)
    lock.lease_renewer = FakeRenewer(ok=True)
    lock.lease_lost.clear()

    assert lock.__exit__(None, None, None) is False


def test_run_with_locks__lease_lost_on_exit__returns_lease_lost_code(monkeypatch):
    from contextlib import contextmanager

    @contextmanager
    def fake_acquire_locks(_context, _strategies):
        yield core.LockSession(lease_lost=Event())
        raise LeaseLostError("lease gone")

    monkeypatch.setattr(core, "acquire_locks", fake_acquire_locks)

    context = LockContext(
        url="postgresql://example",
        table_parts=["key_value"],
        lock_key="demo",
        owner="host:1",
    )

    assert core.run_with_locks(["sh", "-c", "exit 0"], context, ["lease"]) == LEASE_LOST_EXIT_CODE


def _demo_context():
    return LockContext(
        url="postgresql://example",
        table_parts=["key_value"],
        lock_key="demo",
        owner="host:1",
    )


def test_with_locks__runs_body_inside_acquired_locks(monkeypatch):
    from contextlib import contextmanager

    order = []

    @contextmanager
    def fake_acquire_locks(_context, strategies):
        order.append(("enter", tuple(strategies)))
        yield core.LockSession(lease_lost=None)
        order.append(("exit", None))

    monkeypatch.setattr(core, "acquire_locks", fake_acquire_locks)

    @core.with_locks(_demo_context(), ["schedule"])
    def guarded(value):
        order.append(("body", value))
        return value * 2

    assert guarded(21) == 42
    assert order == [("enter", ("schedule",)), ("body", 21), ("exit", None)]


def test_with_locks__lock_not_acquired__propagates(monkeypatch):
    from contextlib import contextmanager

    @contextmanager
    def fake_acquire_locks(_context, _strategies):
        raise core.LockNotAcquiredError("taken")
        yield  # pragma: no cover

    monkeypatch.setattr(core, "acquire_locks", fake_acquire_locks)

    @core.with_locks(_demo_context(), ["schedule"])
    def guarded():
        pytest.fail("body must not run when the lock is not acquired")

    with pytest.raises(core.LockNotAcquiredError):
        guarded()


def test_with_locks__preserves_function_metadata(monkeypatch):
    @core.with_locks(_demo_context(), ["schedule"])
    def guarded():
        """Guarded docstring."""

    assert guarded.__name__ == "guarded"
    assert guarded.__doc__ == "Guarded docstring."
