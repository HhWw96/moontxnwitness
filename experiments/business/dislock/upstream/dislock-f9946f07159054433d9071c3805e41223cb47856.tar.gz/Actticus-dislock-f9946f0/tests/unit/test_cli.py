from unittest.mock import Mock

import pytest

import dislock.cli as cli
import dislock.core as core
from dislock.exceptions import ConfigurationError


def test_parse_lock_strategies_defaults_to_schedule():
    assert cli.parse_lock_strategies(None) == ("schedule",)


def test_parse_lock_strategies_supports_multiple_values():
    assert cli.parse_lock_strategies("lease,schedule") == ("schedule", "lease")


def test_parse_lock_strategies_rejects_invalid_value():
    import pytest

    with pytest.raises(ConfigurationError):
        cli.parse_lock_strategies("schedule,unknown")


def test_parse_jitter_seconds_defaults_to_zero():
    assert cli.parse_jitter_seconds(None) == 0.0
    assert cli.parse_jitter_seconds("  ") == 0.0


def test_parse_jitter_seconds_parses_value():
    assert cli.parse_jitter_seconds("30") == 30.0


def test_parse_jitter_seconds_rejects_non_numeric():
    import pytest

    with pytest.raises(ConfigurationError):
        cli.parse_jitter_seconds("soon")


def test_parse_jitter_seconds_rejects_negative():
    import pytest

    with pytest.raises(ConfigurationError):
        cli.parse_jitter_seconds("-1")


def test_main_returns_usage_code_for_missing_args():
    assert cli.main([]) == 2


def test_main_runs_command(monkeypatch):
    run_with_locks = Mock(return_value=7)

    monkeypatch.setattr(cli, "build_context_from_env", Mock(return_value=(("schedule",), object())))
    monkeypatch.setattr(cli, "run_with_locks", run_with_locks)

    assert cli.main(["DATABASE_URL", "python3", "-V"]) == 7
    run_with_locks.assert_called_once()


def test_build_context_from_env_builds_schedule_context(monkeypatch):
    monkeypatch.setenv("DATABASE_URL", "postgresql://example")
    monkeypatch.setenv("LOCK_KEY", "demo")
    monkeypatch.setenv("CRON_SCHEDULE", "*/5 * * * *")
    monkeypatch.setenv("LOCK_JITTER_SECONDS", "30")

    fake_psycopg = Mock()
    fake_croniter_module = Mock()
    fake_cron = fake_croniter_module.croniter.return_value
    fake_cron.get_next.return_value = "next-run"

    monkeypatch.setattr(cli, "psycopg", fake_psycopg)
    monkeypatch.setattr(cli, "croniter", fake_croniter_module)
    monkeypatch.setattr(cli, "get_db_time", Mock(return_value="db-now"))

    strategies, context = cli.build_context_from_env("DATABASE_URL")

    assert strategies == ("schedule",)
    assert context.lock_key == "demo"
    assert context.next_run_time == "next-run"
    assert context.jitter_max_seconds == 30.0


def test_parse_lease_loss_policy_defaults_to_terminate():
    assert cli.parse_lease_loss_policy(None) is core.LeaseLossPolicy.TERMINATE
    assert cli.parse_lease_loss_policy("  ") is core.LeaseLossPolicy.TERMINATE


def test_parse_lease_loss_policy_parses_continue():
    assert cli.parse_lease_loss_policy(" CONTINUE ") is core.LeaseLossPolicy.CONTINUE


def test_parse_lease_loss_policy_rejects_unknown_value():
    with pytest.raises(ConfigurationError):
        cli.parse_lease_loss_policy("ignore")
