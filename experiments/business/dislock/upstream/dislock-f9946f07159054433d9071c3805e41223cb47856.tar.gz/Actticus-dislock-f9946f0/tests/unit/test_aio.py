import asyncio
from contextlib import asynccontextmanager

import pytest

import dislock.aio as aio
from dislock.aio import LockSession, with_locks
from dislock.core import LockContext
from dislock.exceptions import LeaseLostError, LockNotAcquiredError


def _demo_context():
    return LockContext(
        url="postgresql://example",
        table_parts=["key_value"],
        lock_key="demo",
        owner="host:1",
    )


def _patch_acquire_locks(monkeypatch, lease_lost, order=None):
    @asynccontextmanager
    async def fake_acquire_locks(_context, strategies):
        if order is not None:
            order.append(("enter", tuple(strategies)))
        yield LockSession(lease_lost=lease_lost)
        if order is not None:
            order.append(("exit", None))

    monkeypatch.setattr(aio, "acquire_locks", fake_acquire_locks)


def test_with_locks__runs_body_inside_acquired_locks(monkeypatch):
    order = []
    _patch_acquire_locks(monkeypatch, lease_lost=None, order=order)

    @with_locks(_demo_context(), ["schedule"])
    async def guarded(value):
        order.append(("body", value))
        return value * 2

    assert asyncio.run(guarded(21)) == 42
    assert order == [("enter", ("schedule",)), ("body", 21), ("exit", None)]


def test_with_locks__lock_not_acquired__propagates(monkeypatch):
    @asynccontextmanager
    async def fake_acquire_locks(_context, _strategies):
        raise LockNotAcquiredError("taken")
        yield  # pragma: no cover

    monkeypatch.setattr(aio, "acquire_locks", fake_acquire_locks)

    @with_locks(_demo_context(), ["schedule"])
    async def guarded():
        pytest.fail("body must not run when the lock is not acquired")

    with pytest.raises(LockNotAcquiredError):
        asyncio.run(guarded())


def test_with_locks__lease_lost__cancels_body_and_raises(monkeypatch):
    lease_lost = None
    cancelled = asyncio.Event()

    async def scenario():
        nonlocal lease_lost
        lease_lost = asyncio.Event()
        _patch_acquire_locks(monkeypatch, lease_lost=lease_lost)

        @with_locks(_demo_context(), ["lease"])
        async def guarded():
            try:
                lease_lost.set()
                await asyncio.sleep(60)
            except asyncio.CancelledError:
                cancelled.set()
                raise

        with pytest.raises(LeaseLostError):
            await guarded()

    asyncio.run(scenario())
    assert cancelled.is_set()


def test_with_locks__preserves_function_metadata(monkeypatch):
    _patch_acquire_locks(monkeypatch, lease_lost=None)

    @with_locks(_demo_context(), ["schedule"])
    async def guarded():
        """Guarded docstring."""

    assert guarded.__name__ == "guarded"
    assert guarded.__doc__ == "Guarded docstring."
