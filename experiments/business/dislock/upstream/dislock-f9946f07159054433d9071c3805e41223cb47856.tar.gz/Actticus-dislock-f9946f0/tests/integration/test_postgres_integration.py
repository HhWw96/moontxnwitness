import os
import time
import uuid
from datetime import timedelta

import pytest
import psycopg

from dislock import LeaseLock, LockContext, LockNotAcquiredError, ScheduleLock
from dislock.core import get_db_time

pytestmark = pytest.mark.integration


def _create_table(conn, table_name: str) -> None:
    with conn.cursor() as cur:
        cur.execute(
            f"""
            CREATE TABLE {table_name} (
                key text PRIMARY KEY,
                value text NOT NULL,
                expire_at timestamptz NOT NULL
            );
            """
        )
    conn.commit()


@pytest.fixture
def db_url():
    return os.environ.get("TEST_DATABASE_URL", "postgresql://postgres:postgres@localhost:5432/dislock_test")


@pytest.fixture
def connection(db_url):
    conn = psycopg.connect(db_url, autocommit=False)
    try:
        yield conn
    finally:
        conn.rollback()
        conn.close()


@pytest.fixture
def lock_context_factory(db_url, connection):
    created_tables: list[str] = []

    def factory(**overrides):
        table_name = f"lock_table_{uuid.uuid4().hex[:8]}"
        _create_table(connection, table_name)
        created_tables.append(table_name)
        now = get_db_time(connection)
        connection.rollback()

        context = LockContext(
            url=db_url,
            table_parts=[table_name],
            lock_key=overrides.pop("lock_key", f"job-{uuid.uuid4().hex[:6]}"),
            owner=overrides.pop("owner", f"owner-{uuid.uuid4().hex[:6]}"),
            next_run_time=overrides.pop("next_run_time", now + timedelta(minutes=5)),
            run_ttl_seconds=overrides.pop("run_ttl_seconds", 2.0),
            lease_interval_seconds=overrides.pop("lease_interval_seconds", 0.5),
            **overrides,
        )
        return context

    yield factory

    for table_name in created_tables:
        with connection.cursor() as cur:
            cur.execute(f"DROP TABLE IF EXISTS {table_name};")
        connection.commit()


def _fetch_expire_at(db_url: str, table_name: str, key: str):
    conn = psycopg.connect(db_url, autocommit=False)
    try:
        with conn.cursor() as cur:
            cur.execute(f"SELECT expire_at FROM {table_name} WHERE key = %s;", (key,))
            row = cur.fetchone()
            return row[0] if row else None
    finally:
        conn.close()


def test_schedule_lock_blocks_second_owner(lock_context_factory):
    context = lock_context_factory()

    with ScheduleLock(context):
        with pytest.raises(LockNotAcquiredError):
            with ScheduleLock(
                LockContext(
                    url=context.url,
                    table_parts=context.table_parts,
                    lock_key=context.lock_key,
                    owner="other-owner",
                    next_run_time=context.next_run_time,
                )
            ):
                pass


def test_lease_lock_renews_and_releases(lock_context_factory):
    context = lock_context_factory()

    with LeaseLock(context):
        first_expire_at = _fetch_expire_at(context.url, context.table_parts[0], context.lease_key)
        time.sleep(1.2)
        second_expire_at = _fetch_expire_at(context.url, context.table_parts[0], context.lease_key)

    reacquire_context = LockContext(
        url=context.url,
        table_parts=context.table_parts,
        lock_key=context.lock_key,
        owner="reacquired-owner",
        run_ttl_seconds=context.run_ttl_seconds,
        lease_interval_seconds=context.lease_interval_seconds,
    )

    assert second_expire_at > first_expire_at

    with LeaseLock(reacquire_context):
        reacquired_expire_at = _fetch_expire_at(
            reacquire_context.url,
            reacquire_context.table_parts[0],
            reacquire_context.lease_key,
        )

    assert reacquired_expire_at is not None
